#!/usr/bin/env python3
"""Project the final product witness into the exact symmetric-polynomial space.

This is a numerical gate, not a certificate.  A projected polynomial is worth
an exact rational I/J run only if independent importance-QMC retains a clear
k=48 crossing.
"""

from __future__ import annotations

import argparse
import importlib.util
from pathlib import Path
import sys

import numpy as np
from scipy import linalg
from scipy.special import logsumexp
from scipy.stats import qmc


HERE = Path(__file__).resolve().parent
REPO = HERE.parent / "tmp" / "primegaps_exact"
sys.path.insert(0, str(REPO / "src"))


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


g = load_module(
    "geometry_screen",
    REPO / "reproduction" / "240" / "numerical" / "geometry_screen.py",
)
from primegaps.support import SupportParameters


K = 48
RADIUS = .258
DELTA_U = .014 / RADIUS
SPLIT_U = .253 / RADIUS
LOWER_U = np.array([0, .156, .156, .170, .184, .190, .202]) / RADIUS
UPPER_U = np.array([0, .153, .153, .167, .181, .190, .190]) / RADIUS
PROFILES = np.array([[4.5, .8], [3.5, 1.], [2.8, 1.25]])
COEFFICIENTS = np.array([.0006, -.1032, 1.])


def support_parameters():
    width = int(1 / .014)
    lower = tuple([.156, .156, .170, .184, .190] + [.202] * (width - 5))
    upper = tuple([.153, .153, .167, .181] + [.190] * (width - 4))
    result = SupportParameters(.014, 0., (0., .253, .258), (lower, upper))
    result.validate()
    return result


def normalizers():
    out = []
    for alpha, power in PROFILES:
        exponent = 1 - 2 * power
        out.append(((1 + alpha * K) ** exponent - 1) / (alpha * K * exponent))
    return np.asarray(out)


def inverse_cdf(values, alpha, power):
    exponent = 1 - 2 * power
    endpoint = (1 + alpha * K) ** exponent
    return ((1 + values * (endpoint - 1)) ** (1 / exponent) - 1) / (alpha * K)


def sample(dimension, power, seed):
    sampler = qmc.Sobol(d=dimension + 1, scramble=True, seed=seed)
    uniforms = sampler.random_base2(power)
    component = np.minimum((uniforms[:, 0] * 3).astype(int), 2)
    points = np.empty((len(uniforms), dimension))
    for i, (alpha, profile_power) in enumerate(PROFILES):
        selected = component == i
        points[selected] = inverse_cdf(uniforms[selected, 1:], alpha, profile_power)
    logs = np.stack(
        [-p * np.log1p(a * K * points).sum(axis=1) for a, p in PROFILES],
        axis=1,
    )
    norms = normalizers()
    log_density = logsumexp(
        -np.log(3.) + 2 * logs - dimension * np.log(norms), axis=1
    )
    return points, logs, log_density


def support_mask(points):
    total = points.sum(axis=1)
    large = points > DELTA_U
    count = large.sum(axis=1)
    large_sum = np.where(large, points, 0.).sum(axis=1)
    lo = LOWER_U[np.minimum(count, 6)]
    hi = UPPER_U[np.minimum(count, 6)]
    return ((total <= SPLIT_U) & (large_sum <= lo)) | (
        (total > SPLIT_U) & (total <= 1) & (large_sum <= hi)
    )


def target_values(logs):
    scale = logs.max(axis=1)
    return np.exp(scale) * (np.exp(logs - scale[:, None]) @ COEFFICIENTS)


def primitive(x, alpha, power):
    exponent = 1 - power
    if abs(exponent) < 1e-14:
        return np.log1p(alpha * K * x) / (alpha * K)
    return ((1 + alpha * K * x) ** exponent - 1) / (alpha * K * exponent)


def target_marginal(points):
    total = points.sum(axis=1)
    large = points > DELTA_U
    count = large.sum(axis=1)
    large_sum = np.where(large, points, 0.).sum(axis=1)
    logs = np.stack(
        [-p * np.log1p(a * K * points).sum(axis=1) for a, p in PROFILES], axis=1
    )
    integrals = np.zeros((len(points), 3))
    for slice_lo, slice_hi, caps in ((0., SPLIT_U, LOWER_U), (SPLIT_U, 1., UPPER_U)):
        x_lo = np.maximum(0., slice_lo - total)
        x_hi = np.maximum(0., slice_hi - total)
        same_cap = caps[np.minimum(count, 6)]
        small_hi = np.minimum(x_hi, DELTA_U)
        small_ok = large_sum <= same_cap
        next_cap = caps[np.minimum(count + 1, 6)]
        large_lo = np.maximum(x_lo, DELTA_U)
        large_hi = np.minimum(x_hi, np.maximum(0., next_cap - large_sum))
        for j, (alpha, power) in enumerate(PROFILES):
            integrals[:, j] += np.where(
                small_ok & (small_hi > x_lo),
                primitive(small_hi, alpha, power) - primitive(x_lo, alpha, power),
                0.,
            )
            integrals[:, j] += np.where(
                large_hi > large_lo,
                primitive(large_hi, alpha, power) - primitive(large_lo, alpha, power),
                0.,
            )
    return np.sum(COEFFICIENTS * np.exp(logs) * integrals, axis=1)


def feature_matrix(points_u, basis, parts, degree):
    return g.q.features(
        RADIUS * points_u,
        basis,
        parts,
        degree,
        K,
        K / RADIUS**2,
    )


def fit(max_degree, fit_power, seed, rcond):
    points, logs, log_q = sample(K, fit_power, seed)
    accepted = support_mask(points)
    points, logs, log_q = points[accepted], logs[accepted], log_q[accepted]
    basis = g.q.basis_indices(max_degree)
    parts = g.q.all_partitions(max_degree // 2)
    x = feature_matrix(points, basis, parts, max_degree)
    y = target_values(logs)
    # Global scaling changes neither the quotient nor the projection residual.
    y_scale = np.sqrt(np.mean(np.exp(-log_q) * y * y))
    y = y / y_scale
    row_scale = np.exp(-.5 * log_q)
    x *= row_scale[:, None]
    y *= row_scale
    coefficients, _, rank, singular = linalg.lstsq(
        x, y, cond=rcond, lapack_driver="gelsd"
    )
    residual = np.linalg.norm(x @ coefficients - y) / np.linalg.norm(y)
    print(
        f"fit accepted={len(y)} basis={len(basis)} rank={rank} "
        f"weighted_relative_L2={residual:.6g} cond={singular[0]/singular[-1]:.3g}",
        flush=True,
    )
    return basis, parts, coefficients


def validate(basis, parts, coefficients, power, seed, batch_power=12):
    support = support_parameters()
    g.q.U = RADIUS
    g.q.R = RADIUS
    g.q.DELTA = .014
    i_points, i_logs, i_log_q = sample(K, power, seed)
    j_points, _, j_log_q = sample(K - 1, power, seed + 1_000_003)
    batch = 1 << batch_power
    i_poly = i_target = j_poly = j_target = 0.
    n = len(i_points)
    for start in range(0, n, batch):
        sl = slice(start, min(start + batch, n))
        mask = support_mask(i_points[sl])
        if np.any(mask):
            values = feature_matrix(i_points[sl][mask], basis, parts, max(2 * sum(x) + b for x, b in basis)) @ coefficients
            weights = np.exp(-i_log_q[sl][mask])
            i_poly += np.sum(weights * values * values)
            target = target_values(i_logs[sl][mask])
            i_target += np.sum(weights * target * target)

        physical = RADIUS * j_points[sl]
        marginal = g.marginal_features(
            physical,
            basis,
            parts,
            max(2 * sum(x) + b for x, b in basis),
            K,
            K / RADIUS**2,
            support,
        ) @ coefficients
        marginal /= RADIUS
        weights_j = np.exp(-j_log_q[sl])
        j_poly += np.sum(weights_j * marginal * marginal)
        target_h = target_marginal(j_points[sl])
        j_target += np.sum(weights_j * target_h * target_h)
    i_poly /= n
    i_target /= n
    j_poly /= n
    j_target /= n
    print(f"validation poly_q={RADIUS*K*j_poly/i_poly:.9f}")
    print(f"validation target_q={RADIUS*K*j_target/i_target:.9f}")
    print(f"I_poly/target={i_poly/i_target:.6g} J_poly/target={j_poly/j_target:.6g}")
    return RADIUS * K * j_poly / i_poly


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--degree", type=int, default=16)
    parser.add_argument("--fit-power", type=int, default=15)
    parser.add_argument("--validation-power", type=int, default=16)
    parser.add_argument("--seed", type=int, default=7101)
    parser.add_argument("--rcond", type=float, default=1e-7)
    parser.add_argument("--save")
    args = parser.parse_args()
    basis, parts, coefficients = fit(
        args.degree, args.fit_power, args.seed, args.rcond
    )
    quotient = validate(
        basis, parts, coefficients, args.validation_power, args.seed + 17,
    )
    if args.save:
        np.savez(
            args.save,
            degree=args.degree,
            basis=np.asarray([(tuple(lam), b) for lam, b in basis], dtype=object),
            coefficients=coefficients,
            quotient=quotient,
        )


if __name__ == "__main__":
    main()
