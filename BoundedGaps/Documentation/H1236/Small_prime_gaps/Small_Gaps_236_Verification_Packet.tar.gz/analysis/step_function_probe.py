#!/usr/bin/env python3
"""Finite-cell trial-function probe with exact support containment logic.

The arithmetic in this exploratory version is floating point, but the function
being integrated is genuinely piecewise constant.  Consequently its I and J
integrals are finite sums; a crossing witness can later be replayed with
rational cell values and exact polynomial/NTT convolution.
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.linalg import eigh
from scipy.signal import fftconvolve


K = 48
RADIUS = .258
DELTA = .014
SPLIT = .253
LOWER = [0, .156, .156, .170, .184, .190, .202]
UPPER = [0, .153, .153, .167, .181, .190, .190]
PROFILES = [(4.5, .8), (3.5, 1.), (2.8, 1.25)]


def index(value, h):
    answer = round(value / h)
    if abs(answer * h - value) > 1e-12:
        raise ValueError(f"{value} is not aligned to h={h}")
    return answer


def range_sum(prefix, lo, hi):
    """Vectorized inclusive integer-range sums with clipping."""
    lo = np.maximum(lo, 0)
    hi = np.minimum(hi, len(prefix) - 2)
    valid = hi >= lo
    safe_lo = np.where(valid, lo, 0).astype(np.int64)
    safe_hi = np.where(valid, hi + 1, 0).astype(np.int64)
    return np.where(valid, prefix[safe_hi] - prefix[safe_lo], 0.0)


def allowed_profile_sum(total_lo, big_lo, count, values, h):
    """Sum one profile over last-coordinate bins giving contained k-cells."""
    radius_i = index(RADIUS, h)
    delta_i = index(DELTA, h)
    split_i = index(SPLIT, h)
    lower_i = [index(x, h) for x in LOWER]
    upper_i = [index(x, h) for x in UPPER]
    prefix = np.concatenate(([0.0], np.cumsum(values)))
    answer = np.zeros_like(total_lo, dtype=float)

    for large, domain_lo, domain_hi in (
        (False, 0, delta_i - 1),
        (True, delta_i, radius_i - 1),
    ):
        new_count = count + int(large)
        cap_l = lower_i[min(new_count, len(lower_i) - 1)]
        cap_u = upper_i[min(new_count, len(upper_i) - 1)]
        if large:
            big_hi_offset = big_lo + new_count
            cap_l_hi = cap_l - big_hi_offset
            cap_u_hi = cap_u - big_hi_offset
        else:
            big_hi = big_lo + count
            lower_ok = big_hi <= cap_l
            upper_ok = big_hi <= cap_u
            cap_l_hi = np.where(lower_ok, domain_hi, domain_lo - 1)
            cap_u_hi = np.where(upper_ok, domain_hi, domain_lo - 1)

        lower_lo = np.full_like(total_lo, domain_lo)
        lower_hi = np.minimum(split_i - total_lo - K, cap_l_hi)

        upper_lo = np.maximum(split_i - total_lo, domain_lo)
        upper_hi = np.minimum(
            np.minimum(np.full_like(total_lo, domain_hi), radius_i - total_lo - K),
            cap_u_hi,
        )

        cross_lo = np.maximum(split_i - total_lo - K + 1, domain_lo)
        cross_hi = np.minimum(
            np.minimum(
                np.minimum(
                    np.full_like(total_lo, domain_hi),
                    split_i - total_lo - 1,
                ),
                radius_i - total_lo - K,
            ),
            np.minimum(cap_l_hi, cap_u_hi),
        )
        answer += range_sum(prefix, lower_lo, lower_hi)
        answer += range_sum(prefix, cross_lo, cross_hi)
        answer += range_sum(prefix, upper_lo, upper_hi)
    return h * answer


def cross_entry(left, right, h):
    radius_i = index(RADIUS, h)
    delta_i = index(DELTA, h)
    split_i = index(SPLIT, h)
    lower_i = np.array([index(x, h) for x in LOWER])
    upper_i = np.array([index(x, h) for x in UPPER])
    max_cap_i = max(lower_i[-1], upper_i[-1])

    # Midpoints are merely the chosen cell constants, not quadrature nodes.
    points = (np.arange(radius_i) + .5) * h
    profile_values = []
    for alpha, power in (left, right):
        profile_values.append((1 + alpha * K * points / RADIUS) ** (-power))
    raw = h * profile_values[0] * profile_values[1]
    small = raw.copy()
    small[delta_i:] = 0
    big = raw[:max_cap_i].copy()
    big[:delta_i] = 0

    nr, nb = radius_i + 1, max_cap_i + 1
    max_count = min(K, max_cap_i // delta_i)
    state = np.zeros((nr, nb, max_count + 1))
    state[0, 0, 0] = 1
    before_last = None
    r_grid = np.arange(nr)[:, None]
    b_grid = np.arange(nb)[None, :]
    for step in range(1, K + 1):
        small_part = fftconvolve(state, small[:, None, None], axes=0)[:nr]
        big_part = fftconvolve(state, big[None, :, None], axes=1)[:, :nb]
        new = small_part
        new[:, :, 1:] += big_part[:, :, :-1]
        new[new < 0] = 0
        new *= ((r_grid + b_grid + K) <= radius_i)[:, :, None]
        state = new
        if step == K - 1:
            before_last = state.copy()
    assert before_last is not None

    total_lo = r_grid + b_grid
    i_value = 0.0
    for count in range(max_count + 1):
        big_hi = b_grid + count
        cap_l = lower_i[min(count, len(lower_i) - 1)]
        cap_u = upper_i[min(count, len(upper_i) - 1)]
        total_hi = total_lo + K
        lower = (total_hi <= split_i) & (big_hi <= cap_l)
        upper = (
            (total_lo >= split_i) & (total_hi <= radius_i) & (big_hi <= cap_u)
        )
        crossing = (
            (total_lo < split_i) & (total_hi > split_i)
            & (total_hi <= radius_i) & (big_hi <= min(cap_l, cap_u))
        )
        i_value += float(np.sum(state[:, :, count] * (lower | crossing | upper)))

    j_value = 0.0
    for count in range(max_count + 1):
        outer = before_last[:, :, count]
        h_left = allowed_profile_sum(total_lo, b_grid, count, profile_values[0], h)
        h_right = allowed_profile_sum(total_lo, b_grid, count, profile_values[1], h)
        j_value += float(np.sum(outer * h_left * h_right))
    return i_value, j_value


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--h", type=float, default=.00025)
    parser.add_argument("--save")
    args = parser.parse_args()
    imat = np.empty((3, 3))
    jmat = np.empty((3, 3))
    for row, left in enumerate(PROFILES):
        for col in range(row + 1):
            imat[row, col], jmat[row, col] = cross_entry(left, PROFILES[col], args.h)
            imat[col, row], jmat[col, row] = imat[row, col], jmat[row, col]
        print(f"completed row {row + 1}/3", flush=True)
    scale = 1 / np.sqrt(np.diag(imat))
    si = scale[:, None] * imat * scale[None, :]
    sj = scale[:, None] * jmat * scale[None, :]
    vals, vecs = eigh(si)
    white = vecs / np.sqrt(vals)[None, :]
    qvals, qvecs = eigh(white.T @ sj @ white)
    coefficients = scale * (white @ qvecs[:, -1])
    coefficients /= np.max(np.abs(coefficients))
    optimized = K * qvals[-1]
    fixed = np.array([.0006, -.1032, 1.])
    fixed_q = K * (fixed @ jmat @ fixed) / (fixed @ imat @ fixed)
    print(f"optimized_q={optimized:.12f}")
    print(f"fixed_q={fixed_q:.12f}")
    print(f"coefficients={coefficients}")
    print(f"I_correlation_eigenvalues={vals}")
    if args.save:
        np.savez(args.save, imat=imat, jmat=jmat, h=args.h, profiles=PROFILES)


if __name__ == "__main__":
    main()
