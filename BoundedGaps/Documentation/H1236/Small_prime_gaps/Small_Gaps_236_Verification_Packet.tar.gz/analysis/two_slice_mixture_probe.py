#!/usr/bin/env python3
"""Mixed-product variational probe for a two-slice factorization support."""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.linalg import eigh
from scipy.signal import fftconvolve


Profile = tuple[float, float, float]


def primitive(v: np.ndarray, k: int, profile: Profile) -> np.ndarray:
    alpha, power, cutoff = profile
    v = np.minimum(np.maximum(v, 0.0), cutoff / k)
    if alpha == 0:
        return v
    if power == 1:
        return np.log1p(alpha * k * v) / (alpha * k)
    return ((1 + alpha * k * v) ** (1 - power) - 1) / (alpha * k * (1 - power))


def cross_entry(
    k: int,
    radius: float,
    delta: float,
    split_radius: float,
    lower_caps: list[float],
    upper_caps: list[float],
    left_profile: Profile,
    right_profile: Profile,
    dx: float,
) -> tuple[float, float]:
    scaled_delta = delta / radius
    split = split_radius / radius
    scaled_lower = np.array(lower_caps) / radius
    scaled_upper = np.array(upper_caps) / radius
    max_cap = max(scaled_lower[-1], scaled_upper[-1])
    max_count = min(k, int(math.floor(max_cap / scaled_delta)))
    nr = int(math.floor(1 / dx)) + 1
    nb = int(math.floor(max_cap / dx)) + 1
    x = np.arange(nr) * dx
    a1, p1, t1 = left_profile
    a2, p2, t2 = right_profile
    left = np.where(k * x <= t1, (1 + a1 * k * x) ** (-p1), 0.0)
    right = np.where(k * x <= t2, (1 + a2 * k * x) ** (-p2), 0.0)
    raw = left * right * dx
    raw[0] *= 0.5
    z = float(raw.sum())
    probability = raw / z
    cutoff_index = int(math.floor(scaled_delta / dx))
    small = probability.copy()
    small[cutoff_index + 1 :] = 0
    big = probability[:nb].copy()
    big[: cutoff_index + 1] = 0

    state = np.zeros((nr, nb, max_count + 1))
    state[0, 0, 0] = 1.0
    before_last = None
    r_index = np.arange(nr)[:, None]
    b_index = np.arange(nb)[None, :]
    total_ok = (r_index + b_index) * dx <= 1 + 1e-12
    for step in range(1, k + 1):
        small_part = fftconvolve(state, small[:, None, None], mode="full", axes=0)[:nr]
        big_part = fftconvolve(state, big[None, :, None], mode="full", axes=1)[:, :nb]
        new = small_part
        new[:, :, 1:] += big_part[:, :, :-1]
        new[new < 0] = 0
        new *= total_ok[:, :, None]
        state = new
        if step == k - 1:
            before_last = state.copy()
    assert before_last is not None

    total = (r_index + b_index) * dx
    big_sum = b_index * dx
    i_probability = 0.0
    for count in range(max_count + 1):
        lower_cap = scaled_lower[min(count, len(scaled_lower) - 1)]
        upper_cap = scaled_upper[min(count, len(scaled_upper) - 1)]
        lower_mask = (total <= split + 1e-12) & (big_sum <= lower_cap + 1e-12)
        upper_mask = (total > split + 1e-12) & (big_sum <= upper_cap + 1e-12)
        i_probability += float(np.sum(state[:, :, count] * (lower_mask | upper_mask)))

    def interval_integral(lo: np.ndarray, hi: np.ndarray, profile: Profile) -> np.ndarray:
        return np.where(hi > lo, primitive(hi, k, profile) - primitive(lo, k, profile), 0.0)

    e_j = 0.0
    slice_data = [
        (0.0, split, scaled_lower),
        (split, 1.0, scaled_upper),
    ]
    for count in range(max_count + 1):
        outer = before_last[:, :, count]
        h_left = np.zeros_like(total)
        h_right = np.zeros_like(total)
        for slice_lo, slice_hi, slice_caps in slice_data:
            x_lo = np.maximum(0.0, slice_lo - total)
            x_hi = np.maximum(0.0, slice_hi - total)

            cap_same = slice_caps[min(count, len(slice_caps) - 1)]
            small_lo = x_lo
            small_hi = np.minimum(x_hi, scaled_delta)
            small_allowed = big_sum <= cap_same + 1e-12

            cap_next = slice_caps[min(count + 1, len(slice_caps) - 1)]
            large_lo = np.maximum(x_lo, scaled_delta)
            large_hi = np.minimum(x_hi, np.maximum(0.0, cap_next - big_sum))

            h_left += np.where(
                small_allowed,
                interval_integral(small_lo, small_hi, left_profile),
                0.0,
            )
            h_left += interval_integral(large_lo, large_hi, left_profile)
            h_right += np.where(
                small_allowed,
                interval_integral(small_lo, small_hi, right_profile),
                0.0,
            )
            h_right += interval_integral(large_lo, large_hi, right_profile)
        e_j += float(np.sum(outer * h_left * h_right))
    return math.exp(k * math.log(z)) * i_probability, math.exp((k - 1) * math.log(z)) * e_j


def solve(
    k: int,
    radius: float,
    delta: float,
    split_radius: float,
    lower_caps: list[float],
    upper_caps: list[float],
    profiles: list[Profile],
    dx: float,
    save_matrices: str | None,
) -> None:
    n = len(profiles)
    imat = np.empty((n, n))
    jmat = np.empty((n, n))
    for row, left in enumerate(profiles):
        for col in range(row + 1):
            i_entry, j_entry = cross_entry(
                k, radius, delta, split_radius, lower_caps, upper_caps, left, profiles[col], dx
            )
            imat[row, col] = imat[col, row] = i_entry
            jmat[row, col] = jmat[col, row] = j_entry
        print(f"completed row {row + 1}/{n}", flush=True)
    if save_matrices:
        np.savez(
            save_matrices,
            imat=imat,
            jmat=jmat,
            profiles=np.asarray(profiles),
            radius=radius,
            k=k,
            dx=dx,
            delta=delta,
            split_radius=split_radius,
            lower_caps=np.asarray(lower_caps),
            upper_caps=np.asarray(upper_caps),
        )
    scale = 1 / np.sqrt(np.diag(imat))
    si = scale[:, None] * imat * scale[None, :]
    sj = scale[:, None] * jmat * scale[None, :]
    vals, vecs = eigh(si)
    keep = vals > max(vals[-1] * 1e-10, 1e-12)
    whitening = vecs[:, keep] / np.sqrt(vals[keep])[None, :]
    reduced_vals, reduced_vecs = eigh(whitening.T @ sj @ whitening)
    unit_m = k * float(reduced_vals[-1])
    scaled_vector = whitening @ reduced_vecs[:, -1]
    coefficients = scale * scaled_vector
    coefficients /= np.max(np.abs(coefficients))
    print(f"basis_size={n} effective_rank={int(keep.sum())}")
    print(f"unit_M={unit_m:.12f}")
    print(f"radius_times_M={radius * unit_m:.12f}")
    print(f"normalized_coefficients={coefficients}")
    print(f"I_correlation_eigenvalues={vals}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--k", type=int, default=48)
    parser.add_argument("--radius", type=float, default=0.258)
    parser.add_argument("--delta", type=float, default=0.014)
    parser.add_argument("--split-radius", type=float, default=0.253)
    parser.add_argument("--lower-caps", default="0,.156,.156,.170,.184,.198,.212")
    parser.add_argument("--upper-caps", default="0,.153,.153,.167,.181,.195,.198")
    parser.add_argument("--profiles", default="4:.5:48,6:.5:48,8:.5:48,3:.75:48,4.67:.75:48,6:.75:48,2.5:1:48,3.5:1:48,4.5:1:48,2:1.5:48,2.33:1.5:48,3:1.5:48,1.75:2:48")
    parser.add_argument("--dx", type=float, default=0.004)
    parser.add_argument("--save-matrices")
    args = parser.parse_args()
    lower = [float(value) for value in args.lower_caps.split(",")]
    upper = [float(value) for value in args.upper_caps.split(",")]
    profiles = [tuple(float(part) for part in value.split(":")) for value in args.profiles.split(",")]
    solve(
        args.k,
        args.radius,
        args.delta,
        args.split_radius,
        lower,
        upper,
        profiles,
        args.dx,
        args.save_matrices,
    )


if __name__ == "__main__":
    main()
