#!/usr/bin/env python3
"""Freeze the two-piece Chebyshev product profiles as exact decimals.

The discovery calculation uses NumPy's Chebyshev interpolant.  This script
records every binary64 coefficient with 17 significant digits, interpreted as
an exact decimal rational.  It also converts the recorded Chebyshev series to
the ordinary power basis over the physical coordinate t; the latter is the
input needed by the exact convolution engine.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
import json
from pathlib import Path

import numpy as np
from numpy.polynomial import Chebyshev


K = 48
RADIUS = Fraction(258, 1000)
DELTA = Fraction(14, 1000)
LIMIT = Fraction(202, 1000)
PROFILES = ((Fraction(9, 2), Fraction(4, 5)),
            (Fraction(7, 2), Fraction(1, 1)),
            (Fraction(14, 5), Fraction(5, 4)))


def exact_decimal(value: float) -> Fraction:
    return Fraction(format(float(value), ".17g"))


def add(left: list[Fraction], right: list[Fraction]) -> list[Fraction]:
    answer = [Fraction(0)] * max(len(left), len(right))
    for index, value in enumerate(left):
        answer[index] += value
    for index, value in enumerate(right):
        answer[index] += value
    while len(answer) > 1 and answer[-1] == 0:
        answer.pop()
    return answer


def scale(poly: list[Fraction], scalar: Fraction) -> list[Fraction]:
    return [scalar * value for value in poly]


def multiply(left: list[Fraction], right: list[Fraction]) -> list[Fraction]:
    answer = [Fraction(0)] * (len(left) + len(right) - 1)
    for i, a in enumerate(left):
        for j, b in enumerate(right):
            answer[i + j] += a * b
    return answer


def chebyshev_to_physical(
    coefficients: list[Fraction], lower: Fraction, upper: Fraction
) -> list[Fraction]:
    """Return sum c_n T_n((2t-a-b)/(b-a)) in the power basis t^e."""
    affine = [-(lower + upper) / (upper - lower), Fraction(2) / (upper - lower)]
    terms = [[Fraction(1)]]
    if len(coefficients) > 1:
        terms.append(affine)
    for _ in range(2, len(coefficients)):
        terms.append(add(scale(multiply(affine, terms[-1]), 2), scale(terms[-2], -1)))
    answer = [Fraction(0)]
    for coefficient, term in zip(coefficients, terms):
        answer = add(answer, scale(term, coefficient))
    return answer


def rational_record(value: Fraction) -> list[str]:
    return [str(value.numerator), str(value.denominator)]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--degrees", default="12,24")
    parser.add_argument("--vector", default=".000571087,-.102436968,1")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    degrees = tuple(map(int, args.degrees.split(",")))
    records = []
    maximum_error = 0.0
    for profile_index, (alpha_q, power_q) in enumerate(PROFILES):
        alpha, power = float(alpha_q), float(power_q)
        function_u = lambda u, a=alpha, p=power: (1 + a * K * u) ** (-p)
        pieces = []
        for degree, lower_t, upper_t in (
            (degrees[0], Fraction(0), DELTA),
            (degrees[1], DELTA, LIMIT),
        ):
            lower_u, upper_u = float(lower_t / RADIUS), float(upper_t / RADIUS)
            interpolant = Chebyshev.interpolate(
                function_u, degree, domain=[lower_u, upper_u]
            )
            coefficients = [exact_decimal(value) for value in interpolant.coef]
            physical = chebyshev_to_physical(coefficients, lower_t, upper_t)
            grid_t = np.linspace(float(lower_t), float(upper_t), 2001)
            x = (2 * grid_t - float(lower_t + upper_t)) / float(upper_t - lower_t)
            frozen = np.polynomial.chebyshev.chebval(
                x, np.asarray([float(value) for value in coefficients])
            )
            reference = interpolant(grid_t / float(RADIUS))
            maximum_error = max(maximum_error, float(np.max(np.abs(frozen - reference))))
            pieces.append({
                "degree": degree,
                "physical_interval": [rational_record(lower_t), rational_record(upper_t)],
                "chebyshev_coefficients": [rational_record(value) for value in coefficients],
                "physical_power_coefficients": [rational_record(value) for value in physical],
            })
        records.append({
            "profile_index": profile_index,
            "alpha": rational_record(alpha_q),
            "power": rational_record(power_q),
            "pieces": pieces,
        })
    payload = {
        "schema": "small-gaps-two-piece-chebyshev-v1",
        "k": K,
        "physical_radius": rational_record(RADIUS),
        "breakpoint": rational_record(DELTA),
        "support_limit": rational_record(LIMIT),
        "rounding": ".17g binary64 coefficients interpreted as exact decimal rationals",
        "degrees": list(degrees),
        "mixture_coefficients": [
            rational_record(Fraction(value)) for value in args.vector.split(",")
        ],
        "profiles": records,
    }
    args.output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    print(f"profiles={len(records)} degrees={degrees} max_freeze_error={maximum_error:.3e}")


if __name__ == "__main__":
    main()
