#!/usr/bin/env python3
"""Evaluate the fixed rational k=48,D=21 candidate on alternative supports.

The candidate is chosen independently of these samples.  This avoids the
near-null eigendirection overfitting seen in direct QMC matrix optimization.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from fractions import Fraction
import importlib.util
import json
import math
from math import comb
from pathlib import Path
import sys

import numpy as np
from scipy import special


HERE = Path(__file__).resolve().parent
REPO = HERE.parent / "tmp" / "primegaps_exact"
sys.path.insert(0, str(REPO / "src"))


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


q = load_module(
    "qmc_fixed_candidate",
    REPO / "reproduction" / "240" / "numerical" / "qmc_verifier.py",
)
from primegaps.support import SupportParameters


K = 48
POLYNOMIAL_U = 521 / 2000
CANDIDATE = (
    REPO / "reproduction" / "240" / "independent-reproducer"
    / "candidate-k48-d21.json"
)


def final_support():
    width = int(1 / .014)
    lower = tuple([.156, .156, .170, .184, .190] + [.202] * (width - 5))
    upper = tuple([.153, .153, .167, .181] + [.190] * (width - 4))
    return SupportParameters(.014, 0., (0., .253, .258), (lower, upper))


def published_support():
    width = int(1 / .028)
    row = tuple([.15, .15] + [.17] * (width - 2))
    return SupportParameters(.028, .0075, (-.0075, .253), (row,))


def support_radii(support):
    outer = support.A[-1] + support.epsilon
    marginal = support.A[-1] - support.epsilon
    return outer, marginal


def jacobi_q_coefficients(degree, beta):
    answer = [0] * (degree + 1)
    for m in range(degree + 1):
        base = comb(degree, m) * comb(degree + beta, degree - m) * (-1) ** (degree - m)
        for h in range(m + 1):
            answer[degree - m + h] += base * comb(m, h) * (-1) ** h
    return answer


def load_candidate():
    payload = json.loads(CANDIDATE.read_text())
    monomial = defaultdict(dict)
    parts = {()}
    for term in payload["terms"]:
        actual = tuple(term["signature"])
        signature = tuple(value // 2 for value in actual)
        assert all(2 * a == b for a, b in zip(signature, actual))
        coefficient = Fraction(term["numerator"], term["denominator"])
        slack = int(term["slack_power"])
        monomial[actual][slack] = coefficient
        parts.add(signature)
        for value in set(signature):
            reduced = list(signature)
            reduced.remove(value)
            parts.add(tuple(reduced))
    groups = []
    exact_u = Fraction(521, 2000)
    for actual, coefficients in sorted(monomial.items()):
        maximum = max(coefficients)
        beta = K - 1 + 2 * sum(actual)
        transform = [
            [Fraction(0) for _ in range(maximum + 1)]
            for _ in range(maximum + 1)
        ]
        for degree in range(maximum + 1):
            for slack, coefficient in enumerate(jacobi_q_coefficients(degree, beta)):
                transform[slack][degree] = Fraction(coefficient) / exact_u**slack
        residual = [coefficients.get(slack, Fraction(0)) for slack in range(maximum + 1)]
        vector = [Fraction(0)] * (maximum + 1)
        for degree in range(maximum, -1, -1):
            vector[degree] = residual[degree] / transform[degree][degree]
            residual[degree] = 0
            for slack in range(degree):
                residual[slack] -= vector[degree] * transform[slack][degree]
        assert all(value == 0 for value in residual)
        groups.append((
            tuple(value // 2 for value in actual), actual, beta,
            np.asarray([float(value) for value in vector]),
        ))
    return groups, sorted(parts, key=lambda x: (len(x), sum(x), x))


def accept(points, support):
    total = points.sum(axis=1)
    big = points > support.delta
    count = big.sum(axis=1)
    big_sum = np.where(big, points, 0.).sum(axis=1)
    result = np.zeros(len(points), dtype=bool)
    for band, caps in enumerate(support.B):
        lo = support.A[band] + support.epsilon
        hi = support.A[band + 1] + support.epsilon
        in_band = (total >= lo) & (total <= hi)
        cap = np.asarray(caps)
        okay = count == 0
        active = (count > 0) & (count <= len(cap))
        where = np.flatnonzero(active)
        okay[where] = big_sum[where] <= cap[count[where] - 1]
        result |= in_band & okay
    return result


def monomial_values(points, parts):
    return q.monomial_symmetric_values(points, parts, 1.)


def values(points, groups, parts):
    mvals = monomial_values(points, parts)
    x = 1 - 2 * (POLYNOMIAL_U - points.sum(axis=1)) / POLYNOMIAL_U
    answer = np.zeros(len(points))
    for signature, _actual, beta, vector in groups:
        radial = np.zeros(len(points))
        for degree, coefficient in enumerate(vector):
            radial += coefficient * special.eval_jacobi(degree, 0, beta, x)
        answer += mvals[signature] * radial
    return answer


def allowed_intervals(points, support):
    total = points.sum(axis=1)
    big = points > support.delta
    count = big.sum(axis=1)
    big_sum = np.where(big, points, 0.).sum(axis=1)
    outer, _ = support_radii(support)
    answer = []
    for band, caps_tuple in enumerate(support.B):
        caps = np.asarray(caps_tuple)
        band_lo = support.A[band] + support.epsilon - total
        band_hi = support.A[band + 1] + support.epsilon - total
        same_ok = count == 0
        active = (count > 0) & (count <= len(caps))
        where = np.flatnonzero(active)
        same_ok[where] = big_sum[where] <= caps[count[where] - 1]
        small_lo = np.maximum(0., band_lo)
        small_hi = np.where(
            same_ok,
            np.minimum.reduce((
                np.full(len(points), support.delta),
                outer - total,
                band_hi,
            )),
            small_lo,
        )
        small_hi = np.maximum(small_hi, small_lo)

        new_count = count + 1
        large_lo = np.maximum(support.delta, band_lo)
        large_hi = np.array(large_lo, copy=True)
        active = new_count <= len(caps)
        where = np.flatnonzero(active)
        large_hi[where] = np.minimum.reduce((
            outer - total[where],
            band_hi[where],
            caps[new_count[where] - 1] - big_sum[where],
        ))
        large_hi = np.maximum(large_hi, large_lo)
        answer.extend(((small_lo, small_hi), (large_lo, large_hi)))
    return answer


def integrated_moments(points, support, max_r, max_b):
    room = np.asarray(POLYNOMIAL_U - points.sum(axis=1), dtype=np.longdouble)
    result = np.zeros((max_r + 1, max_b + 1, len(points)), dtype=np.longdouble)
    nodes, weights = np.polynomial.legendre.leggauss(24)
    for lo_float, hi_float in allowed_intervals(points, support):
        lo = np.asarray(lo_float, dtype=np.longdouble)
        hi = np.asarray(hi_float, dtype=np.longdouble)
        half = (hi - lo) / 2
        middle = (hi + lo) / 2
        for node, weight in zip(nodes, weights):
            t = middle + half * np.longdouble(node)
            tp = np.vstack([t ** (2 * r) for r in range(max_r + 1)])
            sp = np.vstack([(room - t) ** b for b in range(max_b + 1)])
            result += np.einsum(
                "rn,bn,n->rbn", tp, sp, half * np.longdouble(weight),
                optimize=True,
            )
    return result


def marginal(points, groups, parts, support):
    mvals = monomial_values(points, parts)
    room = POLYNOMIAL_U - points.sum(axis=1)
    answer = np.zeros(len(points))
    nodes, weights = np.polynomial.legendre.leggauss(24)
    for lo, hi in allowed_intervals(points, support):
        half = (hi - lo) / 2
        middle = (hi + lo) / 2
        for node, weight in zip(nodes, weights):
            t = middle + half * node
            x = 1 - 2 * (room - t) / POLYNOMIAL_U
            value = np.zeros(len(points))
            for signature, actual, beta, vector in groups:
                radial = np.zeros(len(points))
                for degree, coefficient in enumerate(vector):
                    radial += coefficient * special.eval_jacobi(degree, 0, beta, x)
                angular = mvals[signature].copy()
                for exponent in set(actual):
                    reduced_actual = list(actual)
                    reduced_actual.remove(exponent)
                    reduced = tuple(value // 2 for value in reduced_actual)
                    angular += t**exponent * mvals[reduced]
                value += angular * radial
            answer += half * weight * value
    return answer


def one_replicate(groups, parts, support, power, seed, batch_power):
    outer, marginal_radius = support_radii(support)
    component_count = len(q.IMPORTANCE_COMPONENTS)
    component_power = power - int(math.log2(component_count))
    batch = 1 << min(batch_power, component_power)
    denominator = np.longdouble(0)
    numerator = np.longdouble(0)
    for component_index, component in enumerate(q.IMPORTANCE_COMPONENTS):
        component_seed = seed + 10_007 * component_index
        x = q.importance_simplex_points(K, outer, component_power, component_seed, component)
        u = q.importance_simplex_points(
            K - 1, marginal_radius, component_power,
            component_seed + 1_000_003, component,
        )
        wx = q.importance_weights(x, outer)
        wu = q.importance_weights(u, marginal_radius)
        for start in range(0, len(x), batch):
            sl = slice(start, min(start + batch, len(x)))
            mask = accept(x[sl], support)
            if np.any(mask):
                f = values(x[sl][mask], groups, parts)
                denominator += np.dot(np.asarray(wx[sl][mask], dtype=np.longdouble), f * f)
            h = marginal(u[sl], groups, parts, support)
            numerator += np.dot(np.asarray(wu[sl], dtype=np.longdouble), h * h)
    scale = K * K * marginal_radius ** (K - 1) / outer**K
    return float(scale * numerator / denominator)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--support", choices=("final", "published"), default="final")
    parser.add_argument("--power", type=int, default=16)
    parser.add_argument("--replicates", type=int, default=4)
    parser.add_argument("--seed", type=int, default=9101)
    parser.add_argument("--batch-power", type=int, default=10)
    args = parser.parse_args()
    groups, parts = load_candidate()
    support = final_support() if args.support == "final" else published_support()
    support.validate()
    results = []
    for replicate in range(args.replicates):
        value = one_replicate(
            groups, parts, support, args.power, args.seed + replicate,
            args.batch_power,
        )
        results.append(value)
        print(f"rep={replicate} q={value:.12f}", flush=True)
    values_array = np.asarray(results)
    print(
        f"mean={values_array.mean():.12f} "
        f"se={values_array.std(ddof=1)/np.sqrt(len(values_array)):.3e}",
    )


if __name__ == "__main__":
    main()
