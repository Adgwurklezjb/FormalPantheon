#!/usr/bin/env python3
"""Check one mixed Type-IIc cell using slice labels as well as global ranks."""

from __future__ import annotations

import argparse
import itertools

from typeiic_coupled_rank_lp import (
    CASES,
    PAPER_EPSILON,
    XI2,
    add_group_bounds,
    conditional_polytope,
    find_partition,
    load_margins,
)


GROUP_CASES = {
    "mixed66": (6, 0.212, 6, 0.198, 0.0055),
    "mixed44": (4, 0.184, 4, 0.181, 0.0055),
    "upper66": (6, 0.198, 6, 0.198, 0.008),
    "upper1010": (10, 0.198, 10, 0.198, 0.008),
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", choices=GROUP_CASES, default="mixed66")
    parser.add_argument("--segments", type=int, default=16)
    parser.add_argument("--iw", type=int, required=True)
    parser.add_argument("--ig", type=int, required=True)
    parser.add_argument("--j", type=int, default=3)
    args = parser.parse_args()

    n1, b1, n2, b2, omega = GROUP_CASES[args.case]
    n = n1 + n2
    _, total_bound, _ = CASES[args.case]
    gamma_low = XI2 - PAPER_EPSILON
    gamma_high = 1 / 3 + 8 * omega + 7 * 0.014 / 3 + 3 * PAPER_EPSILON
    w_bounds = (
        omega * args.iw / args.segments,
        omega * (args.iw + 1) / args.segments,
    )
    g_bounds = (
        gamma_low + (gamma_high - gamma_low) * args.ig / args.segments,
        gamma_low + (gamma_high - gamma_low) * (args.ig + 1) / args.segments,
    )
    base = conditional_polytope(n, args.j, total_bound, w_bounds, g_bounds)
    if base is None:
        print("conditional cell empty")
        return

    active = 0
    certified = 0
    failures = []
    witnesses: dict[tuple[int, int, int, int], int] = {}
    for group_one in itertools.combinations(range(n), n1):
        polytope = add_group_bounds(base, n, group_one, b1, b2)
        # load_margins also performs an LP; infeasible rank/group patterns can
        # be detected cheaply by asking for the empty-subset primary margin.
        try:
            margins = load_margins(n, args.j, polytope)
        except RuntimeError as exc:
            if "infeasible" in str(exc).lower():
                continue
            raise
        active += 1
        witness = find_partition(margins)
        if witness is None:
            failures.append(group_one)
        else:
            certified += 1
            witnesses[witness] = witnesses.get(witness, 0) + 1
    print(
        f"case={args.case} cell=({args.iw},{args.ig}) j={args.j} "
        f"active_patterns={active} certified={certified} failed={len(failures)}"
    )
    print("witness_counts", sorted(witnesses.items(), key=lambda item: -item[1])[:10])
    for failure in failures[:20]:
        print("FAIL", failure)


if __name__ == "__main__":
    main()
