#!/usr/bin/env python3
"""Robustness diagnostics for a saved variational matrix witness."""

from __future__ import annotations

import argparse
import itertools

import numpy as np
from scipy.linalg import eigh


def quotient(vector: np.ndarray, imat: np.ndarray, jmat: np.ndarray, radius: float, k: int) -> float:
    return radius * k * float(vector @ jmat @ vector) / float(vector @ imat @ vector)


def optimizer(imat: np.ndarray, jmat: np.ndarray) -> tuple[float, np.ndarray]:
    values, vectors = eigh(jmat, imat)
    return float(values[-1]), vectors[:, -1]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("matrix_file")
    args = parser.parse_args()

    data = np.load(args.matrix_file)
    imat = data["imat"]
    jmat = data["jmat"]
    radius = float(data["radius"])
    k = int(data["k"])
    profiles = data["profiles"]

    _, vector = optimizer(imat, jmat)
    vector /= np.max(np.abs(vector))
    print(f"optimal quotient={quotient(vector, imat, jmat, radius, k):.12f}")
    print("raw-basis coefficients:")
    print(np.array2string(vector, precision=14, separator=", "))
    for digits in range(4, 13):
        rounded = np.round(vector, digits)
        value = quotient(rounded, imat, jmat, radius, k)
        print(f"round_digits={digits:2d} quotient={value:.12f} loss={quotient(vector, imat, jmat, radius, k)-value:.3e}")

    print("single-profile deletion quotients:")
    for deleted in range(len(vector)):
        keep = np.arange(len(vector)) != deleted
        value, _ = optimizer(imat[np.ix_(keep, keep)], jmat[np.ix_(keep, keep)])
        scaled = radius * k * value
        alpha, power, cutoff = profiles[deleted]
        print(
            f"deleted={deleted:2d} profile=({alpha:g},{power:g},{cutoff:g}) "
            f"quotient={scaled:.12f}"
        )

    print("best subspace by size:")
    for size in range(1, len(vector) + 1):
        best_value = -np.inf
        best_subset: tuple[int, ...] | None = None
        best_floor = np.nan
        for subset in itertools.combinations(range(len(vector)), size):
            sub_i = imat[np.ix_(subset, subset)]
            sub_j = jmat[np.ix_(subset, subset)]
            try:
                value, _ = optimizer(sub_i, sub_j)
            except np.linalg.LinAlgError:
                continue
            scaled = radius * k * value
            if scaled > best_value:
                diagonal_scale = 1 / np.sqrt(np.diag(sub_i))
                correlation = diagonal_scale[:, None] * sub_i * diagonal_scale[None, :]
                best_value = scaled
                best_subset = subset
                best_floor = float(np.linalg.eigvalsh(correlation)[0])
        print(
            f"size={size:2d} quotient={best_value:.12f} "
            f"min_corr_eig={best_floor:.3e} subset={best_subset}"
        )


if __name__ == "__main__":
    main()
