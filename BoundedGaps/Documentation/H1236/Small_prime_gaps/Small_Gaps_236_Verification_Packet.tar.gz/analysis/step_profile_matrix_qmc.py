#!/usr/bin/env python3
"""Three-by-three QMC matrices for rationalizable step-profile witnesses."""

from __future__ import annotations

import argparse
import importlib.util
import math
from pathlib import Path

import numpy as np
from scipy import linalg
from scipy.special import logsumexp
from scipy.stats import qmc


HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("mix", HERE / "mixture_qmc_validation.py")
mix = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(mix)


def configure_step(physical_step):
    mix.PROFILE_STEP = physical_step / mix.RADIUS
    count = int(math.ceil(1 / mix.PROFILE_STEP)) + 1
    midpoints = (np.arange(count) + .5) * mix.PROFILE_STEP
    heights = np.vstack([
        (1 + alpha * mix.K * midpoints) ** (-power)
        for alpha, power in mix.PROFILES
    ])
    mix.STEP_PREFIXES = np.concatenate(
        (np.zeros((len(mix.PROFILES), 1)),
         np.cumsum(heights * mix.PROFILE_STEP, axis=1)), axis=1,
    )


def sample(dimension, power, seed):
    sampler = qmc.Sobol(d=dimension + 1, scramble=True, seed=seed)
    uniforms = sampler.random_base2(power)
    component = np.minimum((uniforms[:, 0] * 3).astype(int), 2)
    points = np.empty((len(uniforms), dimension))
    for index, (alpha, profile_power) in enumerate(mix.PROFILES):
        selected = component == index
        points[selected] = mix.inverse_squared_cdf(
            uniforms[selected, 1:], alpha, profile_power
        )
    continuous_logs = mix.log_profiles(points)
    norms = np.array([
        mix.normalizer(alpha, profile_power)
        for alpha, profile_power in mix.PROFILES
    ])
    log_density = logsumexp(
        -math.log(3) + 2 * continuous_logs
        - dimension * np.log(norms), axis=1,
    )
    return points, log_density


def one_matrix(power, seed):
    x, log_q_i = sample(mix.K, power, 1000 + seed)
    u, log_q_j = sample(mix.K - 1, power, 2000 + seed)
    fi = np.exp(mix.step_log_profiles(x))
    fi *= mix.support_mask(x)[:, None]
    hi = np.exp(mix.step_log_profiles(u)) * mix.last_integrals(u)
    wi = np.exp(-log_q_i)
    wj = np.exp(-log_q_j)
    imat = fi.T @ (fi * wi[:, None]) / len(x)
    jmat = hi.T @ (hi * wj[:, None]) / len(u)
    return imat, jmat


def solve(imat, jmat):
    scale = 1 / np.sqrt(np.diag(imat))
    si = scale[:, None] * imat * scale[None, :]
    sj = scale[:, None] * jmat * scale[None, :]
    vals, vecs = linalg.eigh(si)
    white = vecs / np.sqrt(vals)[None, :]
    qvals, qvecs = linalg.eigh(white.T @ sj @ white)
    vector = scale * (white @ qvecs[:, -1])
    vector /= np.max(np.abs(vector))
    return mix.RADIUS * mix.K * qvals[-1], vector, vals


def evaluate(vector, imat, jmat):
    return mix.RADIUS * mix.K * (vector @ jmat @ vector) / (vector @ imat @ vector)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--step", type=float, default=.00025)
    parser.add_argument("--power", type=int, default=19)
    parser.add_argument("--replicates", type=int, default=8)
    parser.add_argument("--seed", type=int, default=1300)
    parser.add_argument("--validation-seed", type=int, default=1500)
    parser.add_argument("--save")
    args = parser.parse_args()
    mix.LOWER[5] = .190 / mix.RADIUS
    mix.LOWER[6:] = .202 / mix.RADIUS
    mix.UPPER[5:] = .190 / mix.RADIUS
    configure_step(args.step)
    discovery = [
        one_matrix(args.power, args.seed + i) for i in range(args.replicates)
    ]
    imat = np.mean([pair[0] for pair in discovery], axis=0)
    jmat = np.mean([pair[1] for pair in discovery], axis=0)
    quotient, vector, eigs = solve(imat, jmat)
    print(f"discovery_q={quotient:.12f}")
    print(f"vector={vector}")
    print(f"I_correlation_eigenvalues={eigs}")
    validation = []
    for i in range(args.replicates):
        vi, vj = one_matrix(args.power, args.validation_seed + i)
        value = evaluate(vector, vi, vj)
        validation.append(value)
        print(f"validation rep={i} q={value:.12f}", flush=True)
    array = np.asarray(validation)
    print(f"validation_mean={array.mean():.12f} se={array.std(ddof=1)/np.sqrt(len(array)):.3e}")
    if args.save:
        np.savez(
            args.save, step=args.step, imat=imat, jmat=jmat, vector=vector,
            discovery_q=quotient, validation_q=array,
        )


if __name__ == "__main__":
    main()
