#!/usr/bin/env python3
"""Verify the finite support bookkeeping for the conditional H_1 <= 236 proof.

The default mode checks the exact-rational Proposition 2/3 oracle, the complete
list of Type-IIc exceptions, the hand-lemma split, and the correspondence
between every remaining exception and a saved exact-dual replay job.

With ``--full-dual-replay`` it also reruns every exact-dual job and compares the
canonical SHA-256 digest printed by the replayer.  This is deliberately not the
default because the 27 jobs are computationally expensive.
"""

from __future__ import annotations

import argparse
from fractions import Fraction as Q
from pathlib import Path
import re
import subprocess
import sys


HERE = Path(__file__).resolve().parent
REPOSITORY = HERE.parent / "tmp" / "primegaps_exact"
sys.path.insert(0, str(REPOSITORY / "src"))

from primegaps.distribution import (  # noqa: E402
    Minorant,
    RegionCell,
    _local_conditions,
    _partition_witness,
    _proposition_2_checks,
    _proposition_3_global_checks,
)


DELTA = Q(7, 500)
LOWER_A = Q(253, 1000)
UPPER_A = Q(129, 500)
LOWER_CAPS = tuple(map(Q, ("0", ".156", ".156", ".170", ".184", ".190", ".202")))
UPPER_CAPS = tuple(map(Q, ("0", ".153", ".153", ".167", ".181", ".190", ".190")))
MINORANT = Minorant(Q(759, 2000), Q(4021, 10000), Q(4021, 10000))


HAND = {
    ("L", 3, "U", 4),
    ("L", 4, "U", 3),
    ("U", 1, "U", 3),
    ("U", 1, "U", 4),
    ("U", 1, "U", 5),
    ("U", 2, "U", 3),
    ("U", 2, "U", 4),
    ("U", 2, "U", 5),
}


# Each replay works on the larger universe y_i >= delta, sum y_i <= total.
# Consequently total is allowed to exceed the sum of the two actual caps.
REPLAY = {
    ("L", 3, "U", 5): "exact_m35_N8.log",
    ("L", 3, "U", 6): "exact_m36_N8.log",
    ("L", 4, "U", 4): "exact_m44_N8.log",
    ("L", 4, "U", 5): "exact_surgery2_m45_N16.log",
    ("L", 4, "U", 6): "exact_m46_N8.log",
    ("L", 5, "U", 4): "exact_surgery3_m54_N16.log",
    ("L", 5, "U", 5): "exact_surgery2_m55_N16.log",
    ("L", 5, "U", 6): "exact_m56_N8.log",
    ("L", 6, "U", 3): "exact_m63_N8.log",
    ("L", 6, "U", 4): "exact_m64_N8.log",
    ("L", 6, "U", 5): "exact_m65_N8.log",
    ("L", 6, "U", 6): "typeiic_exact_dual_N32.log",
    ("U", 1, "U", 6): "exact_u16_N8.log",
    ("U", 2, "U", 6): "exact_u26_N8.log",
    ("U", 3, "U", 3): "exact_u33_N8.log",
    ("U", 3, "U", 4): "exact_u34_N8.log",
    ("U", 3, "U", 5): "exact_u35_N8.log",
    ("U", 3, "U", 6): "exact_u36_N8.log",
    ("U", 4, "U", 4): "exact_u44_N8.log",
    ("U", 4, "U", 5): "exact_u45_N32.log",
    ("U", 4, "U", 6): "exact_u46_N8.log",
    ("U", 5, "U", 5): "exact_surgery2_u55_N16.log",
    ("U", 5, "U", 6): "exact_surgery2_u56_N16.log",
    ("U", 6, "U", 6): "exact_surgery2_u66_N16.log",
}


def parse_job(path: Path) -> dict[str, object]:
    text = path.read_text()
    totals = re.search(r"active_conditions\s+(\d+)\s+exact_duals\s+(\d+)", text)
    digest = re.search(r"sha256\s+([0-9a-f]{64})", text)
    parameters = re.search(
        r"parameters \{'n': (\d+), 'total': '([^']+)', 'omega': '([^']+)', 'segments': (\d+)\}",
        text,
    )
    assert totals and digest, path
    if parameters:
        n, total, omega, segments = parameters.groups()
        parsed = {
            "n": int(n),
            "total": Q(total),
            "omega": Q(omega),
            "segments": int(segments),
        }
    else:
        assert path.name == "typeiic_exact_dual_N32.log"
        parsed = {"n": 12, "total": Q(2, 5), "omega": Q(11, 2000), "segments": 32}
    parsed.update(
        active=int(totals.group(1)),
        duals=int(totals.group(2)),
        digest=digest.group(1),
    )
    return parsed


def band_data(name: str):
    if name == "L":
        return LOWER_A, LOWER_CAPS
    if name == "U":
        return UPPER_A, UPPER_CAPS
    raise ValueError(name)


def exact_oracle_check() -> set[tuple[str, int, str, int]]:
    bands = (("L", LOWER_A, LOWER_CAPS), ("U", UPPER_A, UPPER_CAPS))
    assert all(check.passed for check in _proposition_2_checks(MINORANT))
    assert all(check.passed for check in _proposition_3_global_checks(DELTA, UPPER_A, MINORANT))
    typeiic_failures = set()
    pairs = 0
    for left_index, (left_name, left_a, left_caps) in enumerate(bands):
        for right_index, (right_name, right_a, right_caps) in enumerate(bands):
            if right_index < left_index:
                continue
            for m in range(7):
                for n in range(7):
                    if left_index == right_index and n < m:
                        continue
                    left = RegionCell(left_a, m, left_caps[m], DELTA, UPPER_A, f"{left_name}{m}")
                    right = RegionCell(right_a, n, right_caps[n], DELTA, UPPER_A, f"{right_name}{n}")
                    if left.is_empty or right.is_empty:
                        continue
                    pairs += 1
                    omega = (left_a + right_a) / 2 - Q(1, 4)
                    for condition, capacities in _local_conditions(left, right, MINORANT, omega):
                        witness = _partition_witness(condition, capacities, left, right)
                        if condition.startswith("D /"):
                            if witness is None:
                                typeiic_failures.add((left_name, m, right_name, n))
                        else:
                            assert witness is not None, (condition, left.label, right.label)
    assert pairs == 105
    assert len(typeiic_failures) == 32
    assert typeiic_failures == HAND | set(REPLAY)
    return typeiic_failures


def replay_manifest_check() -> tuple[int, int]:
    used = set()
    for pair, filename in REPLAY.items():
        assert filename not in used
        used.add(filename)
        job = parse_job(HERE / filename)
        left_name, m, right_name, n = pair
        left_a, left_caps = band_data(left_name)
        right_a, right_caps = band_data(right_name)
        actual_total = left_caps[m] + right_caps[n]
        omega = (left_a + right_a) / 2 - Q(1, 4)
        assert job["n"] == m + n
        assert job["total"] >= actual_total
        assert job["omega"] == omega
        assert job["duals"] == 4 * job["active"]

    # Three older mixed jobs are stronger supersets but no longer needed.
    redundant = {"exact_m51_N8.log", "exact_m52_N8.log", "exact_m53_N8.log"}
    all_logs = {path.name for path in HERE.glob("exact*.log")} | {"typeiic_exact_dual_N32.log"}
    assert all_logs == used | redundant
    jobs = [parse_job(HERE / name) for name in sorted(all_logs)]
    conditions = sum(int(job["active"]) for job in jobs)
    duals = sum(int(job["duals"]) for job in jobs)
    assert (len(jobs), conditions, duals) == (27, 11_359, 45_436)
    return conditions, duals


def full_dual_replay() -> None:
    logs = [HERE / "typeiic_exact_dual_N32.log", *sorted(HERE.glob("exact*.log"))]
    for index, path in enumerate(logs, 1):
        job = parse_job(path)
        command = [
            sys.executable,
            str(HERE / "typeiic_exact_dual_replay.py"),
            "--n", str(job["n"]),
            "--total", str(job["total"]),
            "--omega", str(job["omega"]),
            "--segments", str(job["segments"]),
        ]
        print(f"[{index}/{len(logs)}] replaying {path.name}", flush=True)
        result = subprocess.run(command, check=True, capture_output=True, text=True, cwd=HERE)
        digest = re.search(r"sha256\s+([0-9a-f]{64})", result.stdout)
        assert digest and digest.group(1) == job["digest"], path.name


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--full-dual-replay", action="store_true")
    args = parser.parse_args()
    failures = exact_oracle_check()
    conditions, duals = replay_manifest_check()
    print(
        "PASS: 105 frontier pairs; all Type-I/IIa/IIb/III witnesses pass; "
        f"Type-IIc splits as 73 oracle + {len(HAND)} hand + {len(REPLAY)} exact-LP"
    )
    print(f"PASS: replay manifest covers {conditions:,} conditional polytopes and {duals:,} exact dual inequalities")
    assert len(failures) == 32
    if args.full_dual_replay:
        full_dual_replay()
        print("PASS: all exact-dual record digests reproduced")
    else:
        print("NOTE: pass --full-dual-replay to regenerate all 27 expensive exact-dual jobs")


if __name__ == "__main__":
    main()
