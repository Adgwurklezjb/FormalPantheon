#!/usr/bin/env python3
"""Run the coupled rank screen over the reduced mixed/upper count frontier."""

from __future__ import annotations

import argparse
import subprocess
import sys


LOWER = [0.0, 0.156, 0.156, 0.170, 0.184, 0.198, 0.202]
UPPER = [0.0, 0.153, 0.153, 0.167, 0.181, 0.195, 0.198]


def run_pair(n: int, total: float, omega: float, segments: int) -> bool:
    command = [
        sys.executable,
        "analysis/typeiic_coupled_rank_lp.py",
        "--case", "mixed66",
        "--segments", str(segments),
        "--n", str(n),
        "--omega", str(omega),
        "--total-bound", str(total),
    ]
    result = subprocess.run(command, check=True, capture_output=True, text=True)
    summary = next(line for line in result.stdout.splitlines() if line.startswith("case="))
    return "failed_cells=0" in summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--segments", type=int, default=8)
    args = parser.parse_args()
    failures = []
    for left_count in range(1, 7):
        for right_count in range(1, 7):
            total = LOWER[left_count] + UPPER[right_count]
            ok = run_pair(left_count + right_count, total, 0.0055, args.segments)
            print("mixed", left_count, right_count, total, "PASS" if ok else "FAIL", flush=True)
            if not ok:
                failures.append(("mixed", left_count, right_count, total))
    for first_count in range(1, 7):
        for second_count in range(first_count, 7):
            total = UPPER[first_count] + UPPER[second_count]
            ok = run_pair(first_count + second_count, total, 0.008, args.segments)
            print("upper", first_count, second_count, total, "PASS" if ok else "FAIL", flush=True)
            if not ok:
                failures.append(("upper", first_count, second_count, total))
    print("failures", failures)


if __name__ == "__main__":
    main()
