#!/usr/bin/env python3
"""Heuristic adversarial test of Proposition 3's partition conditions.

This is a counterexample finder, not a proof.  It probes extreme and random
points of Xi(B_m,B_m',m,m',delta) and solves each finite bin-packing instance
by backtracking.
"""

from __future__ import annotations

import argparse
import functools

import numpy as np


def packable(items: tuple[float, ...], capacities: tuple[float, ...], tol: float = 2e-9) -> bool:
    items = tuple(sorted(items, reverse=True))
    capacities = tuple(sorted(capacities, reverse=True))

    @functools.cache
    def visit(index: int, caps_key: tuple[int, ...]) -> bool:
        if index == len(items):
            return True
        caps = [value / 10**8 for value in caps_key]
        item = items[index]
        tried = set()
        for bin_index, cap in enumerate(caps):
            rounded = round(cap, 8)
            if rounded in tried or item > cap + tol:
                continue
            tried.add(rounded)
            next_caps = caps.copy()
            next_caps[bin_index] -= item
            next_key = tuple(sorted((round(value * 10**8) for value in next_caps), reverse=True))
            if visit(index + 1, next_key):
                return True
        return False

    key = tuple(sorted((round(value * 10**8) for value in capacities), reverse=True))
    return visit(0, key)


def samples(m: int, cap: float, delta: float, rng: np.random.Generator, random_count: int) -> list[tuple[float, ...]]:
    if m == 0:
        return [()]
    if m * delta > cap + 1e-12:
        return []
    extra = cap - m * delta
    result = [
        tuple([delta + extra] + [delta] * (m - 1)),
        tuple([cap / m] * m),
    ]
    for _ in range(random_count):
        weights = rng.dirichlet(np.full(m, rng.choice([0.15, 0.4, 1.0, 3.0])))
        total_fraction = rng.choice([1.0, rng.uniform(0, 1)])
        result.append(tuple(delta + extra * total_fraction * weights))
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--A", type=float, default=0.25775)
    parser.add_argument("--A-left", type=float)
    parser.add_argument("--A-right", type=float)
    parser.add_argument("--delta", type=float, default=0.014)
    parser.add_argument("--xi1", type=float, default=0.379)
    parser.add_argument("--xi2", type=float, default=0.4)
    parser.add_argument("--xi3", type=float, default=0.4)
    parser.add_argument("--caps", default="0,0.155,0.169,0.183,0.19")
    parser.add_argument("--caps-left")
    parser.add_argument("--caps-right")
    parser.add_argument("--random-count", type=int, default=20)
    args = parser.parse_args()
    caps = [float(value) for value in args.caps.split(",")]
    caps_left = [float(value) for value in (args.caps_left or args.caps).split(",")]
    caps_right = [float(value) for value in (args.caps_right or args.caps).split(",")]
    a_left = args.A if args.A_left is None else args.A_left
    a_right = args.A if args.A_right is None else args.A_right
    omega = (a_left + a_right) / 2 - 0.25
    gamma_max = 1 / 3 + 8 * omega + 7 * args.delta / 3
    condition_caps: list[tuple[str, tuple[float, ...]]] = [
        ("I", (args.xi1, 1 / 6 - 4 * omega)),
        ("IIa", (2 / 5 + 24 * omega / 5 + 7 * args.delta / 5, 1 / 14 - 24 * omega / 7)),
        ("IIb", (1 / 3 + 8 * omega + 7 * args.delta / 3, 1 / 10 - 34 * omega / 5 - 7 * args.delta / 5, 1 / 35 + 22 * omega / 35 + 21 * args.delta / 35)),
        ("III", (1 - 6 * omega - 3 * args.xi3 / 2, 5 * omega / 2 + 3 * args.xi3 / 8)),
    ]
    if gamma_max >= args.xi2:
        for omega0 in np.linspace(0, omega, 7):
            for gamma in np.linspace(args.xi2, gamma_max, 9):
                condition_caps.append(
                    (
                        f"IIc(w={omega0:.5f},g={gamma:.5f})",
                        (gamma - 2 * args.delta - 8 * omega0, 0.5 - gamma - 2 * omega0, 4 * omega0 + args.delta, 8 * omega0),
                    )
                )

    rng = np.random.default_rng(20260902)
    max_m = int(max(caps_left[-1], caps_right[-1]) // args.delta)
    tested = 0
    for m1 in range(max_m + 1):
        cap1 = caps_left[min(m1, len(caps_left) - 1)]
        left_samples = samples(m1, cap1, args.delta, rng, args.random_count)
        if not left_samples:
            continue
        for m2 in range(max_m + 1):
            if m1 + m2 == 0:
                continue
            cap2 = caps_right[min(m2, len(caps_right) - 1)]
            right_samples = samples(m2, cap2, args.delta, rng, args.random_count)
            for left in left_samples:
                for right in right_samples:
                    items = left + right
                    for name, bins in condition_caps:
                        tested += 1
                        if not packable(items, bins):
                            print("COUNTEREXAMPLE")
                            print(f"m1={m1} m2={m2} condition={name}")
                            print(f"items={items}")
                            print(f"bins={bins} total_items={sum(items):.9f}")
                            return
    print(f"No counterexample in {tested} tested packing instances.")


if __name__ == "__main__":
    main()
