#!/usr/bin/env python3
"""Positive-mass cell enclosure diagnostic for the step-profile J matrix.

The convolution is arranged probabilistically: a step-density coordinate is a
mixture of an integer bin and an independent U[0,1] displacement.  This avoids
the catastrophic cancellation of truncated-power coefficients.  Arithmetic is
floating point in this diagnostic; the reported inner/outer gap is geometric.
"""

from __future__ import annotations

import math

import numpy as np
from scipy.signal import fftconvolve
from scipy.stats import irwinhall


K = 48
H = .00025
RADIUS = .258
DELTA = .014
SPLIT = .253
LOWER = np.array([0, .156, .156, .170, .184, .190, .202])
UPPER = np.array([0, .153, .153, .167, .181, .190, .190])
PROFILES = [(4.5, .8), (3.5, 1.), (2.8, 1.25)]


def profile_heights(profile):
    bins = int(round(RADIUS / H))
    points = (np.arange(bins) + .5) * H / RADIUS
    alpha, power = profile
    return (1 + alpha * K * points) ** (-power)


HEIGHTS = np.asarray([profile_heights(profile) for profile in PROFILES])
PREFIX = np.concatenate((np.zeros((3, 1)), np.cumsum(HEIGHTS * H, axis=1)), axis=1)


def primitive(x, profile):
    x = np.clip(x, 0., RADIUS)
    index = np.minimum(np.floor(x / H).astype(int), HEIGHTS.shape[1] - 1)
    return PREFIX[profile, index] + (x - index * H) * HEIGHTS[profile, index]


def marginal(total, big_sum, count, profile):
    result = np.zeros(np.broadcast_shapes(np.shape(total), np.shape(big_sum)))
    for lo, hi, caps in ((0., SPLIT, LOWER), (SPLIT, RADIUS, UPPER)):
        xlo = np.maximum(0., lo - total)
        xhi = np.maximum(0., hi - total)
        current_cap = caps[min(count, 6)]
        if count == 0:
            current_ok = np.ones_like(result, dtype=bool)
        else:
            current_ok = big_sum <= current_cap
        small_hi = np.minimum(xhi, DELTA)
        result += np.where(
            current_ok & (small_hi > xlo),
            primitive(small_hi, profile) - primitive(xlo, profile), 0.,
        )
        next_cap = caps[min(count + 1, 6)]
        large_lo = np.maximum(xlo, DELTA)
        large_hi = np.minimum(xhi, np.maximum(0., next_cap - big_sum))
        result += np.where(
            large_hi > large_lo,
            primitive(large_hi, profile) - primitive(large_lo, profile), 0.,
        )
    return result


def positive_power(base, exponent):
    result = np.ones(1)
    for _ in range(exponent):
        result = fftconvolve(result, base)
        result[result < 0] = 0
    return result


def sum_cell_masses(one_coordinate, count):
    if count == 0:
        return np.ones(1)
    discrete = positive_power(one_coordinate * H, count)
    distribution = irwinhall(count)
    boundaries = np.arange(count + 1)
    uniform_cells = np.diff(distribution.cdf(boundaries))
    uniform_cells[uniform_cells < 0] = 0
    masses = fftconvolve(discrete, uniform_cells)
    masses[masses < 0] = 0
    return masses


def entry_bounds(left, right):
    cross = HEIGHTS[left] * HEIGHTS[right]
    delta_index = int(round(DELTA / H))
    small_one = cross[:delta_index]
    big_one = np.zeros(len(cross))
    big_one[delta_index:] = cross[delta_index:]
    lower = upper = 0.
    for count in range(15):
        nsmall = K - 1 - count
        small_mass = sum_cell_masses(small_one, nsmall)
        big_mass = sum_cell_masses(big_one, count)
        subtotal_lower = subtotal_upper = 0.
        small_indices = np.arange(len(small_mass))
        small_lo = small_indices * H
        small_hi = small_lo + (H if nsmall else 0.)
        for big_index, bmass in enumerate(big_mass):
            if bmass <= 0:
                continue
            big_lo = big_index * H
            big_hi = big_lo + (H if count else 0.)
            total_lo = small_lo + big_lo
            total_hi = small_hi + big_hi
            h_left_hi = marginal(total_lo, big_lo, count, left)
            h_right_hi = marginal(total_lo, big_lo, count, right)
            h_left_lo = marginal(total_hi, big_hi, count, left)
            h_right_lo = marginal(total_hi, big_hi, count, right)
            if np.any(h_left_lo > h_left_hi + 1e-14) or np.any(h_right_lo > h_right_hi + 1e-14):
                raise AssertionError("marginal monotonicity failed")
            subtotal_lower += bmass * np.dot(small_mass, h_left_lo * h_right_lo)
            subtotal_upper += bmass * np.dot(small_mass, h_left_hi * h_right_hi)
        choose = math.comb(K - 1, count)
        lower += choose * subtotal_lower
        upper += choose * subtotal_upper
    return lower, upper


def main():
    lower = np.empty((3, 3))
    upper = np.empty((3, 3))
    for row in range(3):
        for col in range(row + 1):
            lo, hi = entry_bounds(row, col)
            lower[row, col] = lower[col, row] = lo
            upper[row, col] = upper[col, row] = hi
            print(
                f"pair={row},{col} lower={lo/RADIUS**49:.12e} "
                f"upper={hi/RADIUS**49:.12e} "
                f"relative_gap={(hi-lo)/((hi+lo)/2):.6g}", flush=True,
            )
    np.savez("step_j_cell_bounds_h00025.npz", lower=lower, upper=upper, h=H)


if __name__ == "__main__":
    main()
