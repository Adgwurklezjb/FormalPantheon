#!/usr/bin/env python3
"""Discover rank-subset Type-IIc certificates via conditional linear programs.

This is a floating-point discovery tool. A positive screen still needs exact
rational LP dual certificates before it becomes a proof.
"""

from __future__ import annotations

import argparse
import itertools

import numpy as np
from scipy.optimize import linprog


DELTA = 0.014
XI2 = 0.4021
PAPER_EPSILON = 1e-10
CASES = {
    "mixed66": (12, 0.410, 0.0055),
    "mixed44": (8, 0.365, 0.0055),
    "upper66": (12, 0.396, 0.008),
    "upper1010": (20, 0.396, 0.008),
}


def base_inequalities(n: int, total_bound: float) -> tuple[np.ndarray, np.ndarray]:
    rows = []
    rhs = []
    # Sorted coordinates y_1 <= ... <= y_n.
    for index in range(n - 1):
        row = np.zeros(n)
        row[index] = 1
        row[index + 1] = -1
        rows.append(row)
        rhs.append(0.0)
    rows.append(np.ones(n))
    rhs.append(total_bound)
    return np.asarray(rows), np.asarray(rhs)


def subset_maxima(
    n: int,
    j: int,
    total_bound: float,
    first_capacity_low: float,
    first_capacity_high: float,
) -> np.ndarray | None:
    base_a, base_b = base_inequalities(n, total_bound)
    rows = [*base_a]
    rhs = [*base_b]

    # Previous prefix fails: total - P_{j-1} >= C1_low.
    row = np.zeros(n)
    row[j - 1 :] = -1
    rows.append(row)
    rhs.append(-first_capacity_low)

    # Current prefix succeeds: total - P_j <= C1_high.
    row = np.zeros(n)
    row[j:] = 1
    rows.append(row)
    rhs.append(first_capacity_high)
    a_ub = np.asarray(rows)
    b_ub = np.asarray(rhs)
    bounds = [(DELTA, None)] * n

    feasibility = linprog(np.zeros(n), A_ub=a_ub, b_ub=b_ub, bounds=bounds, method="highs")
    if not feasibility.success:
        return None
    maxima = np.empty(1 << j)
    for mask in range(1 << j):
        objective = np.zeros(n)
        for index in range(j):
            if mask >> index & 1:
                objective[index] = -1
        result = linprog(objective, A_ub=a_ub, b_ub=b_ub, bounds=bounds, method="highs")
        if not result.success:
            raise RuntimeError(result.message)
        maxima[mask] = -result.fun
    return maxima


def primary_maxima(
    n: int,
    j: int,
    total_bound: float,
    first_capacity_low: float,
    first_capacity_high: float,
) -> np.ndarray | None:
    """Max primary load when a chosen subset of the first j ranks is returned."""
    base_a, base_b = base_inequalities(n, total_bound)
    rows = [*base_a]
    rhs = [*base_b]
    row = np.zeros(n)
    row[j - 1 :] = -1
    rows.append(row)
    rhs.append(-first_capacity_low)
    row = np.zeros(n)
    row[j:] = 1
    rows.append(row)
    rhs.append(first_capacity_high)
    a_ub = np.asarray(rows)
    b_ub = np.asarray(rhs)
    bounds = [(DELTA, None)] * n
    feasibility = linprog(np.zeros(n), A_ub=a_ub, b_ub=b_ub, bounds=bounds, method="highs")
    if not feasibility.success:
        return None
    maxima = np.empty(1 << j)
    for mask in range(1 << j):
        objective = np.zeros(n)
        objective[j:] = -1
        for index in range(j):
            if mask >> index & 1:
                objective[index] = -1
        result = linprog(objective, A_ub=a_ub, b_ub=b_ub, bounds=bounds, method="highs")
        if not result.success:
            raise RuntimeError(result.message)
        maxima[mask] = -result.fun
    return maxima


def rank_partition(maxima: np.ndarray, capacities: tuple[float, float, float]) -> tuple[int, int, int] | None:
    full = len(maxima) - 1
    for first in range(full + 1):
        if maxima[first] > capacities[0] + 1e-9:
            continue
        remaining = full ^ first
        second = remaining
        while True:
            third = remaining ^ second
            if maxima[second] <= capacities[1] + 1e-9 and maxima[third] <= capacities[2] + 1e-9:
                return first, second, third
            if second == 0:
                break
            second = (second - 1) & remaining
    return None


def rank_partition_with_primary(
    side_maxima: np.ndarray,
    primary_loads: np.ndarray,
    primary_capacity: float,
    capacities: tuple[float, float, float],
) -> tuple[int, int, int, int] | None:
    full = len(side_maxima) - 1
    for primary in range(full + 1):
        if primary_loads[primary] > primary_capacity + 1e-9:
            continue
        side = full ^ primary
        first = side
        while True:
            if side_maxima[first] <= capacities[0] + 1e-9:
                remaining = side ^ first
                second = remaining
                while True:
                    third = remaining ^ second
                    if side_maxima[second] <= capacities[1] + 1e-9 and side_maxima[third] <= capacities[2] + 1e-9:
                        return primary, first, second, third
                    if second == 0:
                        break
                    second = (second - 1) & remaining
            if first == 0:
                break
            first = (first - 1) & side
    return None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", choices=CASES, default="mixed66")
    parser.add_argument("--segments", type=int, default=8)
    parser.add_argument("--total-bound", type=float)
    args = parser.parse_args()
    n, total_bound, omega = CASES[args.case]
    if args.total_bound is not None:
        total_bound = args.total_bound
    gamma_low = XI2 - PAPER_EPSILON
    gamma_high = 1 / 3 + 8 * omega + 7 * DELTA / 3 + 3 * PAPER_EPSILON
    failures = []
    certificates = 0
    for iw, ig in itertools.product(range(args.segments), repeat=2):
        w_lo = omega * iw / args.segments
        w_hi = omega * (iw + 1) / args.segments
        g_lo = gamma_low + (gamma_high - gamma_low) * ig / args.segments
        g_hi = gamma_low + (gamma_high - gamma_low) * (ig + 1) / args.segments
        c1_low = g_lo - 2 * DELTA - 8 * w_hi - PAPER_EPSILON
        c1_high = g_hi - 2 * DELTA - 8 * w_lo - PAPER_EPSILON
        side_caps = (
            0.5 - g_hi - 2 * w_hi - PAPER_EPSILON,
            4 * w_lo + DELTA - PAPER_EPSILON,
            8 * w_lo,
        )
        cell_ok = True
        active = 0
        for j in range(1, min(n, 8) + 1):
            maxima = subset_maxima(n, j, total_bound, c1_low, c1_high)
            primary_loads = primary_maxima(n, j, total_bound, c1_low, c1_high)
            if maxima is None or primary_loads is None:
                continue
            active += 1
            witness = rank_partition(maxima, side_caps)
            if witness is None:
                witness = rank_partition_with_primary(maxima, primary_loads, c1_low, side_caps)
            if witness is None:
                cell_ok = False
                failures.append((iw, ig, j, c1_low, c1_high, side_caps))
                break
        if cell_ok:
            certificates += 1
        # If no stopping index is feasible, the first bin already holds every
        # point in the relaxed cell, so the rectangle is certified trivially.
    print(
        f"case={args.case} segments={args.segments} certified_cells={certificates} "
        f"failed_cells={args.segments**2-certificates}"
    )
    for failure in failures[:20]:
        print("FAIL", failure)


if __name__ == "__main__":
    main()
