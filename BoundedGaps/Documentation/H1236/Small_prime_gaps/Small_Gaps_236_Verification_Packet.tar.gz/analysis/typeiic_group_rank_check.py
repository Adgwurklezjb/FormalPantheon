#!/usr/bin/env python3
"""Group-aware rank-LP check for one Type-IIc parameter rectangle."""

from __future__ import annotations

import argparse
import itertools

import numpy as np
from scipy.optimize import linprog

from typeiic_rank_lp_certificate import (
    DELTA,
    PAPER_EPSILON,
    XI2,
    base_inequalities,
    rank_partition,
)


CASES = {
    "mixed66": (6, 0.212, 6, 0.198, 0.0055),
    "upper66": (6, 0.198, 6, 0.198, 0.008),
}


def maxima_for_pattern(
    n1: int,
    b1: float,
    n2: int,
    b2: float,
    group_one: tuple[int, ...],
    j: int,
    c1_low: float,
    c1_high: float,
) -> np.ndarray | None:
    n = n1 + n2
    base_a, base_b = base_inequalities(n, b1 + b2)
    rows = [*base_a]
    rhs = [*base_b]
    row = np.zeros(n)
    row[list(group_one)] = 1
    rows.append(row)
    rhs.append(b1)
    rows.append(1 - row)
    rhs.append(b2)
    row = np.zeros(n)
    row[j - 1 :] = -1
    rows.append(row)
    rhs.append(-c1_low)
    row = np.zeros(n)
    row[j:] = 1
    rows.append(row)
    rhs.append(c1_high)
    a_ub = np.asarray(rows)
    b_ub = np.asarray(rhs)
    bounds = [(DELTA, None)] * n
    feasible = linprog(np.zeros(n), A_ub=a_ub, b_ub=b_ub, bounds=bounds, method="highs")
    if not feasible.success:
        return None
    maxima = np.empty(1 << j)
    for mask in range(1 << j):
        objective = np.zeros(n)
        for index in range(j):
            if mask >> index & 1:
                objective[index] = -1
        result = linprog(objective, A_ub=a_ub, b_ub=b_ub, bounds=bounds, method="highs")
        if not result.success:
            raise RuntimeError(result.message)
        maxima[mask] = -result.fun
    return maxima


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", choices=CASES, required=True)
    parser.add_argument("--segments", type=int, required=True)
    parser.add_argument("--iw", type=int, required=True)
    parser.add_argument("--ig", type=int, required=True)
    args = parser.parse_args()
    n1, b1, n2, b2, omega = CASES[args.case]
    gamma_low = XI2 - PAPER_EPSILON
    gamma_high = 1 / 3 + 8 * omega + 7 * DELTA / 3 + 3 * PAPER_EPSILON
    w_lo = omega * args.iw / args.segments
    w_hi = omega * (args.iw + 1) / args.segments
    g_lo = gamma_low + (gamma_high - gamma_low) * args.ig / args.segments
    g_hi = gamma_low + (gamma_high - gamma_low) * (args.ig + 1) / args.segments
    c1_low = g_lo - 2 * DELTA - 8 * w_hi - PAPER_EPSILON
    c1_high = g_hi - 2 * DELTA - 8 * w_lo - PAPER_EPSILON
    side_caps = (
        0.5 - g_hi - 2 * w_hi - PAPER_EPSILON,
        4 * w_lo + DELTA - PAPER_EPSILON,
        8 * w_lo,
    )
    failed = []
    feasible_patterns = 0
    n = n1 + n2
    for group_one in itertools.combinations(range(n), n1):
        pattern_ok = True
        active = 0
        for j in range(1, min(n, 8) + 1):
            maxima = maxima_for_pattern(n1, b1, n2, b2, group_one, j, c1_low, c1_high)
            if maxima is None:
                continue
            active += 1
            if rank_partition(maxima, side_caps) is None:
                pattern_ok = False
                failed.append((group_one, j))
                break
        if active:
            feasible_patterns += 1
        if not pattern_ok and len(failed) >= 20:
            break
    print(
        f"case={args.case} cell=({args.iw},{args.ig}) feasible_patterns={feasible_patterns} "
        f"failed_patterns={len(failed)} caps={side_caps}"
    )
    for item in failed:
        print("FAIL", item)


if __name__ == "__main__":
    main()
