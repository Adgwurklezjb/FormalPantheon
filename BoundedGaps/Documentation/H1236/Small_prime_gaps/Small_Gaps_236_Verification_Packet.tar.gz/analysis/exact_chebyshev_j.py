#!/usr/bin/env python3
"""Exact rational J entries for the two-piece Chebyshev witness.

The 47 common coordinates are compressed into their residual large and small
sums.  A global rational line arrangement makes the entire last-coordinate
marginal polynomial on every cell, including the essential cross-band terms.
The dense group density remains separable, so polygon integration is performed
by exact vertical antiderivatives rather than by expanding a dense Poly2.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from fractions import Fraction
import importlib.util
import json
from math import comb
from pathlib import Path
import sys

from flint import arb, arb_poly, ctx, fmpq, fmpq_poly

import exact_chebyshev_i as exact_i


HERE = Path(__file__).resolve().parent
REPOSITORY = HERE.parent / "tmp/primegaps_exact"
sys.path.insert(0, str(REPOSITORY / "src"))
VERIFIER = (
    REPOSITORY / "reproduction/240/independent-reproducer/"
    "exact_symmetric_verifier.py"
)
module_spec = importlib.util.spec_from_file_location("cheb_exact_verifier", VERIFIER)
verifier = importlib.util.module_from_spec(module_spec)
assert module_spec.loader is not None
sys.modules[module_spec.name] = verifier
module_spec.loader.exec_module(verifier)


N = 47
DELTA = exact_i.DELTA
SPLIT = exact_i.SPLIT
RADIUS = exact_i.RADIUS
LOWER = exact_i.LOWER
UPPER = exact_i.UPPER
BANDS = ((Fraction(0), SPLIT, LOWER), (SPLIT, RADIUS, UPPER))
verifier.R = RADIUS
verifier.DELTA = DELTA
BALL_BITS = 0


def as_fraction(value) -> Fraction:
    if isinstance(value, Fraction):
        return value
    numerator = value.numerator
    denominator = value.denominator
    if callable(numerator):
        numerator = numerator()
    if callable(denominator):
        denominator = denominator()
    return Fraction(int(numerator), int(denominator))


def cap(table, count):
    return table[min(count, len(table) - 1)]


def component_specs(large_count):
    answer = []
    for band_index, (lower, upper, caps) in enumerate(BANDS):
        for large in (False, True):
            status_count = large_count + int(large)
            answer.append((
                band_index,
                large,
                verifier.RadialSlice(
                    0, 0, large,
                    lower=lower,
                    upper=upper,
                    support_limit=cap(caps, status_count),
                ),
            ))
    return tuple(answer)


def with_power(spec, power):
    return verifier.RadialSlice(
        power, 0, spec.large,
        lower=spec.lower,
        upper=spec.upper,
        support_limit=spec.support_limit,
    )


def add_scaled(target, source, scalar):
    scalar_f = as_fraction(scalar)
    for exponent, coefficient in source.items():
        value = target.get(exponent, Fraction(0)) + scalar_f * coefficient
        if value:
            target[exponent] = value
        else:
            target.pop(exponent, None)


def marginal_polynomial(
    profile, specs, total_offset, large_offset, sample
):
    answer = {}
    for _band, large, spec in specs:
        coefficients = profile[int(large)]
        for power, coefficient in enumerate(coefficients):
            if coefficient:
                piece = verifier._slice_polynomial(
                    with_power(spec, power), total_offset, large_offset, sample
                )
                add_scaled(answer, piece, coefficient)
    return answer


def poly2_product(left, right):
    return verifier.kernel._poly_mul(left, right)


def scalar(value):
    rational = exact_i.fq(value)
    return arb(rational) if BALL_BITS else rational


def make_poly(coefficients):
    if BALL_BITS:
        return arb_poly([arb(value) for value in coefficients])
    return fmpq_poly(coefficients)


def interval_poly_from_terms(terms):
    maximum = max(terms, default=0)
    coefficients = [scalar(0)] * (maximum + 1)
    for power, coefficient in terms.items():
        coefficients[power] = scalar(coefficient)
    return make_poly(coefficients)


def convert_density(source):
    if not BALL_BITS:
        return source
    return arb_poly([arb(coefficient) for coefficient in source.coeffs()])


def interval_integral(small_density, polynomial, start, end):
    terms = defaultdict(Fraction)
    for (x_power, z_power), coefficient in polynomial.items():
        if x_power == 0:
            terms[z_power] += coefficient
    profile_poly = interval_poly_from_terms(terms)
    primitive = (small_density * profile_poly).integral()
    return primitive(scalar(end)) - primitive(scalar(start))


def edge_form(start, end):
    """Return (slope, intercept) for z=slope*x+intercept."""
    slope = (end[1] - start[1]) / (end[0] - start[0])
    return slope, start[1] - slope * start[0]


def vertical_strips(polygon):
    x_values = sorted(set(point[0] for point in polygon))
    for start_x, end_x in zip(x_values, x_values[1:]):
        if start_x == end_x:
            continue
        middle = (start_x + end_x) / 2
        intersections = []
        for start, end in zip(polygon, polygon[1:] + polygon[:1]):
            if start[0] == end[0]:
                continue
            if min(start[0], end[0]) < middle < max(start[0], end[0]):
                form = edge_form(start, end)
                height = form[0] * middle + form[1]
                intersections.append((height, form))
        if len(intersections) != 2:
            raise ArithmeticError(
                f"expected two vertical intersections, got {len(intersections)}"
            )
        intersections.sort()
        yield start_x, end_x, intersections[0][1], intersections[1][1]


def group_by_z(polynomial):
    grouped = defaultdict(dict)
    for (x_power, z_power), coefficient in polynomial.items():
        grouped[z_power][x_power] = grouped[z_power].get(x_power, Fraction(0)) + coefficient
    return {
        z_power: interval_poly_from_terms(terms)
        for z_power, terms in grouped.items()
    }


def boundary_primitive(small_density, z_power, form, cache):
    key = (z_power, form)
    if key not in cache:
        shifted = make_poly(
            [scalar(0)] * z_power + list(small_density.coeffs())
        )
        primitive = shifted.integral()
        slope, intercept = form
        cache[key] = primitive(
            make_poly([scalar(intercept), scalar(slope)])
        )
    return cache[key]


def polygon_integral(
    large_density, small_density, polynomial, polygon, composition_cache
):
    grouped = group_by_z(polynomial)
    answer = scalar(0)
    for start, end, lower, upper in vertical_strips(list(polygon)):
        inner = make_poly([])
        for z_power, x_poly in grouped.items():
            boundary = (
                boundary_primitive(small_density, z_power, upper, composition_cache)
                - boundary_primitive(small_density, z_power, lower, composition_cache)
            )
            inner += x_poly * boundary
        primitive = (large_density * inner).integral()
        answer += primitive(scalar(end)) - primitive(scalar(start))
    return answer


def exact_entry(
    profiles, left_index, right_index, max_large=None, checkpoint: Path | None = None
):
    small_product = exact_i.multiply_power(
        profiles[left_index][0], profiles[right_index][0]
    )
    large_product = exact_i.multiply_power(
        profiles[left_index][1], profiles[right_index][1]
    )
    small_base = exact_i.small_laplace(small_product)
    large_base = exact_i.large_laplace(large_product)
    maximum_count = int(max(LOWER[-1], UPPER[-1]) / DELTA)
    if max_large is not None:
        maximum_count = min(maximum_count, max_large)
    result = scalar(0)
    for large_count in range(maximum_count + 1):
        max_shift = int((RADIUS - large_count * DELTA) / DELTA)
        small_terms = exact_i.bivariate_power(small_base, N - large_count, max_shift)
        large_laplace_power = large_base**large_count
        large_density_q = (
            fmpq_poly([1]) if large_count == 0
            else exact_i.large_density_polynomial(large_laplace_power)
        )
        large_density = convert_density(large_density_q)
        specs = component_specs(large_count)
        status_total = scalar(0)
        cell_total = 0
        for shifted_count, small_term in enumerate(small_terms):
            if not small_term:
                continue
            small_density = convert_density(exact_i.small_density_polynomial(small_term))
            total_offset = (large_count + shifted_count) * DELTA
            large_offset = large_count * DELTA
            kind, cells = verifier._slice_geometry(
                large_count > 0,
                N - large_count > 0,
                total_offset,
                large_offset,
                tuple(item[2] for item in specs),
            )
            iterable = cells if kind != "point" else (cells[0],)
            composition_cache = {}
            for cell in iterable:
                if kind == "polygons":
                    polygon, sample = cell
                elif kind in ("xintervals", "zintervals"):
                    start, end, sample = cell
                elif kind == "point":
                    sample = cell
                else:
                    continue
                left = marginal_polynomial(
                    profiles[left_index], specs, total_offset, large_offset, sample
                )
                right = marginal_polynomial(
                    profiles[right_index], specs, total_offset, large_offset, sample
                )
                polynomial = poly2_product(left, right)
                if not polynomial:
                    continue
                if kind == "polygons":
                    status_total += polygon_integral(
                        large_density, small_density, polynomial, polygon,
                        composition_cache,
                    )
                elif kind == "zintervals":
                    status_total += interval_integral(
                        small_density, polynomial, start, end
                    )
                elif kind == "xintervals":
                    raise NotImplementedError("the 47-coordinate problem always has small variables")
                elif kind == "point":
                    status_total += scalar(polynomial.get((0, 0), 0))
                cell_total += 1
        result += comb(N, large_count) * status_total
        print(
            f"pair={left_index},{right_index} large={large_count} "
            f"cells={cell_total} partial_scaled={result / scalar(RADIUS)**(N+2)}",
            flush=True,
        )
        if checkpoint is not None:
            scaled = result / scalar(RADIUS) ** (N + 2)
            state = {
                "schema": "small-gaps-exact-chebyshev-J-checkpoint-v1",
                "pair": [left_index, right_index],
                "backend": "arb" if BALL_BITS else "fmpq",
                "arb_bits": BALL_BITS or None,
                "completed_large_count": large_count,
                "physical_value": str(result),
                "u_scaled_value": str(scaled),
            }
            checkpoint.write_text(json.dumps(state, indent=2, sort_keys=True) + "\n")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate", type=Path)
    parser.add_argument("--pair", default="2,2")
    parser.add_argument("--max-large", type=int)
    parser.add_argument(
        "--arb-bits", type=int, default=0,
        help="use rigorous Arb ball contractions at this precision",
    )
    parser.add_argument("--output", type=Path)
    parser.add_argument("--checkpoint", type=Path)
    args = parser.parse_args()
    global BALL_BITS
    BALL_BITS = args.arb_bits
    if BALL_BITS:
        ctx.prec = BALL_BITS
    payload, profiles = exact_i.load_profiles(args.candidate)
    left, right = map(int, args.pair.split(","))
    value = exact_entry(
        profiles, left, right, max_large=args.max_large,
        checkpoint=args.checkpoint,
    )
    normalized_value = value / scalar(RADIUS) ** (N + 2)
    normalized = float(normalized_value.mid()) if BALL_BITS else float(normalized_value)
    print(f"RESULT pair={left},{right} u_scaled={normalized_value}")
    if args.output:
        record = {
            "schema": "small-gaps-exact-chebyshev-J-v1",
            "candidate_schema": payload["schema"],
            "candidate_degrees": payload["degrees"],
            "max_large": args.max_large,
            "backend": "arb" if BALL_BITS else "fmpq",
            "arb_bits": BALL_BITS or None,
            "record": {
                "pair": [left, right],
                "numerator": None if BALL_BITS else str(value.numerator),
                "denominator": None if BALL_BITS else str(value.denominator),
                "u_scaled_float": normalized,
                "u_scaled_ball": str(normalized_value) if BALL_BITS else None,
            },
        }
        args.output.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
