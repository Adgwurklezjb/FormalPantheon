#!/usr/bin/env python3
"""Direct QMC generalized-eigenvalue screen on the final two-band support."""

from __future__ import annotations

import argparse
import importlib.util
from pathlib import Path
import sys

import numpy as np
from scipy import linalg


HERE = Path(__file__).resolve().parent
REPO = HERE.parent / "tmp" / "primegaps_exact"
sys.path.insert(0, str(REPO / "src"))


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


g = load_module(
    "geometry_screen_direct",
    REPO / "reproduction" / "240" / "numerical" / "geometry_screen.py",
)
from primegaps.support import SupportParameters


K = 48
RADIUS = .258


def support_parameters():
    width = int(1 / .014)
    lower = tuple([.156, .156, .170, .184, .190] + [.202] * (width - 5))
    upper = tuple([.153, .153, .167, .181] + [.190] * (width - 4))
    result = SupportParameters(.014, 0., (0., .253, .258), (lower, upper))
    result.validate()
    return result


def matrices(degree, power, seed, batch_power):
    support = support_parameters()
    g.q.U = RADIUS
    g.q.R = RADIUS
    g.q.DELTA = .014
    basis = g.q.basis_indices(degree)
    parts = g.q.all_partitions(degree // 2)
    coordinate_scale = K / RADIUS**2
    size = len(basis)
    reference = g.q.full_simplex_reference_gram(K, degree)
    transform = g.q.whiten_transform(reference)
    imat = np.zeros((size, size))
    jmat = np.zeros((size, size))
    component_count = len(g.q.IMPORTANCE_COMPONENTS)
    component_bits = int(np.log2(component_count))
    if 1 << component_bits != component_count or power < component_bits:
        raise ValueError("importance component count must be a fitting power of two")
    component_power = power - component_bits
    batch = 1 << min(batch_power, component_power)
    for component_index, component in enumerate(g.q.IMPORTANCE_COMPONENTS):
        component_seed = seed + 10_007 * component_index
        ipoints = g.q.importance_simplex_points(
            K, RADIUS, component_power, component_seed, component
        )
        jpoints = g.q.importance_simplex_points(
            K - 1, RADIUS, component_power,
            component_seed + 1_000_003, component,
        )
        iweights = g.q.importance_weights(ipoints, RADIUS)
        jweights = g.q.importance_weights(jpoints, RADIUS)
        for start in range(0, len(ipoints), batch):
            end = min(start + batch, len(ipoints))
            x = ipoints[start:end]
            accepted = g.support_acceptance(x, support)
            if np.any(accepted):
                features = g.q.features(
                    x[accepted], basis, parts, degree, K, coordinate_scale
                ) @ transform
                imat += features.T @ (features * iweights[start:end][accepted, None])
            h = g.marginal_features(
                jpoints[start:end], basis, parts, degree, K,
                coordinate_scale, support,
            ) @ transform
            jmat += h.T @ (h * jweights[start:end, None])
    sample_count = 1 << power
    imat /= sample_count
    jmat *= K * K / RADIUS / sample_count
    return basis, imat, jmat, transform


def solve(imat, jmat, cutoff):
    diagonal = np.diag(imat)
    active = diagonal > diagonal.max() * 1e-28
    scale = np.zeros_like(diagonal)
    scale[active] = 1 / np.sqrt(diagonal[active])
    si = scale[:, None] * imat * scale[None, :]
    sj = scale[:, None] * jmat * scale[None, :]
    values, vectors = linalg.eigh(si[np.ix_(active, active)])
    keep = values > values[-1] * cutoff
    white_active = vectors[:, keep] / np.sqrt(values[keep])[None, :]
    reduced = white_active.T @ sj[np.ix_(active, active)] @ white_active
    qvalues, qvectors = linalg.eigh((reduced + reduced.T) / 2)
    active_vector = white_active @ qvectors[:, -1]
    vector = np.zeros(len(diagonal))
    vector[active] = scale[active] * active_vector
    vector /= np.max(np.abs(vector))
    quotient = qvalues[-1]
    residual = np.linalg.norm(
        jmat @ vector - quotient * imat @ vector
    ) / (np.linalg.norm(imat @ vector) * max(1., abs(quotient)))
    return quotient, vector, values, int(keep.sum()), residual


def evaluate(vector, imat, jmat):
    return (vector @ jmat @ vector) / (vector @ imat @ vector)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--degree", type=int, default=12)
    parser.add_argument("--power", type=int, default=16)
    parser.add_argument("--validation-power", type=int, default=17)
    parser.add_argument("--seed", type=int, default=8101)
    parser.add_argument("--batch-power", type=int, default=11)
    parser.add_argument("--cutoff", type=float, default=1e-6)
    parser.add_argument("--save")
    args = parser.parse_args()
    basis, imat, jmat, transform = matrices(
        args.degree, args.power, args.seed, args.batch_power
    )
    quotient, vector, eig_i, rank, residual = solve(imat, jmat, args.cutoff)
    print(
        f"discovery degree={args.degree} size={len(basis)} rank={rank} "
        f"q={quotient:.9f} Icond={eig_i[-1]/max(eig_i[0],1e-300):.3g} "
        f"residual={residual:.3g}", flush=True,
    )
    validation = []
    for offset in (101, 211, 307):
        _, vi, vj, _ = matrices(
            args.degree, args.validation_power, args.seed + offset,
            args.batch_power,
        )
        value = evaluate(vector, vi, vj)
        validation.append(value)
        print(f"validation offset={offset} q={value:.9f}", flush=True)
    if args.save:
        np.savez(
            args.save, degree=args.degree, basis=np.asarray(basis, dtype=object),
            vector=vector, discovery_q=quotient,
            validation_q=np.asarray(validation), imat=imat, jmat=jmat,
            transform=transform, raw_vector=transform @ vector, cutoff=args.cutoff,
        )


if __name__ == "__main__":
    main()
