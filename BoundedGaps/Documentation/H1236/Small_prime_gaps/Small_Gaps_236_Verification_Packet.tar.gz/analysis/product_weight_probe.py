#!/usr/bin/env python3
"""Numerical probe of Maynard product weights on a simplex.

For F(t)=1_{sum t_i <= A} prod_i g(k t_i/A), compute k J(F)/I(F)
by one-dimensional convolutions.  The reported ratio is for the unit simplex;
scaling the simplex by A multiplies it by A.
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.signal import fftconvolve


def ratio(k: int, alpha: float, cutoff: float, dx: float) -> tuple[float, float, float]:
    n = int(math.ceil(1.0 / dx)) + 1
    x = np.arange(n) * dx
    u = k * x
    g = np.where(u <= cutoff, 1.0 / (1.0 + alpha * u), 0.0)

    # Discrete measure approximating g(kx)^2 dx.  Endpoint corrections have a
    # negligible effect at the probing resolutions used here.
    mass = g * g * dx
    mass[0] *= 0.5
    z = float(mass.sum())
    p = mass / z

    distributions = [np.array([1.0])]
    cur = distributions[0]
    for _ in range(k):
        cur = fftconvolve(cur, p)[:n]
        distributions.append(cur)

    pk = float(distributions[k].sum())
    prev = distributions[k - 1]
    s = np.arange(len(prev)) * dx
    v = np.maximum(0.0, 1.0 - s)
    vmax = np.minimum(v, cutoff / k)
    if alpha == 0:
        h = vmax
    else:
        h = np.log1p(alpha * k * vmax) / (alpha * k)
    ej = float(np.dot(prev, h * h))
    return k * ej / (z * pk), pk, z


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--k", type=int, default=48)
    parser.add_argument("--dx", type=float, default=0.0002)
    parser.add_argument("--alpha-min", type=float, default=0.1)
    parser.add_argument("--alpha-max", type=float, default=4.0)
    parser.add_argument("--alpha-steps", type=int, default=25)
    parser.add_argument("--cutoff-min", type=float, default=1.0)
    parser.add_argument("--cutoff-max", type=float, default=15.0)
    parser.add_argument("--cutoff-steps", type=int, default=29)
    args = parser.parse_args()

    best = (-math.inf, 0.0, 0.0, 0.0, 0.0)
    for alpha in np.linspace(args.alpha_min, args.alpha_max, args.alpha_steps):
        for cutoff in np.linspace(args.cutoff_min, args.cutoff_max, args.cutoff_steps):
            value, pk, z = ratio(args.k, float(alpha), float(cutoff), args.dx)
            if value > best[0]:
                best = (value, float(alpha), float(cutoff), pk, z)
                print(
                    f"best M={value:.10f} alpha={alpha:.6f} "
                    f"T={cutoff:.6f} P={pk:.8f} Z={z:.8g}",
                    flush=True,
                )


if __name__ == "__main__":
    main()
