#!/usr/bin/env python3
"""Probe a product Maynard weight with a factorization-support cap.

After scaling the total simplex radius to one, the support is
    sum x_i <= 1,   sum_{x_i > delta/A} x_i <= B/A.
The I and J integrals are evaluated by a two-dimensional convolution that
tracks both total mass and the mass in coordinates above the cutoff.
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.signal import fftconvolve


def primitive(v: np.ndarray, k: int, alpha: float) -> np.ndarray:
    v = np.maximum(v, 0.0)
    if alpha == 0:
        return v
    return np.log1p(alpha * k * v) / (alpha * k)


def evaluate(
    k: int,
    radius: float,
    delta: float,
    cap: float,
    alpha: float,
    cutoff: float,
    dx: float,
) -> tuple[float, float, float]:
    nt = int(math.floor(1.0 / dx)) + 1
    scaled_cap = cap / radius
    nb = int(math.floor(scaled_cap / dx)) + 1
    x = np.arange(nt) * dx
    u = k * x
    g = np.where(u <= cutoff, 1.0 / (1.0 + alpha * u), 0.0)
    raw_mass = g * g * dx
    raw_mass[0] *= 0.5
    z = float(raw_mass.sum())
    p = raw_mass / z

    large_threshold = delta / radius
    kernel = np.zeros((nt, nb))
    for idx, probability in enumerate(p):
        if x[idx] > large_threshold:
            if idx < nb:
                kernel[idx, idx] += probability
        else:
            kernel[idx, 0] += probability

    state = np.zeros((1, 1))
    state[0, 0] = 1.0
    before_last = None
    for step in range(1, k + 1):
        state = fftconvolve(state, kernel)[:nt, :nb]
        state[state < 0] = 0.0
        if step == k - 1:
            before_last = state.copy()
    assert before_last is not None
    p_i = float(state.sum())

    total = np.arange(before_last.shape[0])[:, None] * dx
    big = np.arange(before_last.shape[1])[None, :] * dx
    remaining_total = np.maximum(0.0, 1.0 - total)
    max_coordinate = np.minimum(remaining_total, cutoff / k)

    small_hi = np.minimum(max_coordinate, large_threshold)
    h = np.broadcast_to(primitive(small_hi, k, alpha), before_last.shape).copy()
    large_hi = np.minimum(max_coordinate, np.maximum(0.0, scaled_cap - big))
    h += np.where(
        large_hi > large_threshold,
        primitive(large_hi, k, alpha) - primitive(np.full_like(large_hi, large_threshold), k, alpha),
        0.0,
    )
    e_j = float(np.sum(before_last * h * h))
    unit_m = k * e_j / (z * p_i)
    return unit_m, radius * unit_m, p_i


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--k", type=int, default=48)
    parser.add_argument("--radius", type=float, default=0.2567)
    parser.add_argument("--delta", type=float, default=0.018)
    parser.add_argument("--cap", type=float, default=0.17)
    parser.add_argument("--alpha", type=float, default=3.45)
    parser.add_argument("--cutoff", type=float, default=42.0)
    parser.add_argument("--dx", type=float, default=0.002)
    args = parser.parse_args()
    unit_m, criterion, probability = evaluate(
        args.k,
        args.radius,
        args.delta,
        args.cap,
        args.alpha,
        args.cutoff,
        args.dx,
    )
    print(f"unit_M={unit_m:.10f}")
    print(f"radius_times_M={criterion:.10f}")
    print(f"weighted_support_probability={probability:.10g}")


if __name__ == "__main__":
    main()
