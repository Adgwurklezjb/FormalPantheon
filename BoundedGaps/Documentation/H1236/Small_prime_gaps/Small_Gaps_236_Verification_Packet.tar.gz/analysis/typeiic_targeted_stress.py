#!/usr/bin/env python3
"""Targeted Type-IIc counterexample search for the two-slice candidate."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from partition_stress_test import packable  # noqa: E402


DELTA = 0.014
XI2 = 0.4021
CASES = {
    "mixed66": ((6, 0.212), (6, 0.198), 0.0055),
    "mixed44": ((4, 0.184), (4, 0.181), 0.0055),
    "upper66": ((6, 0.198), (6, 0.198), 0.008),
    "upper1010": ((10, 0.198), (10, 0.198), 0.008),
}


def group_sample(count: int, cap: float, rng: np.random.Generator) -> tuple[float, ...]:
    extra = cap - count * DELTA
    alpha = rng.choice([0.08, 0.2, 0.5, 1.0, 3.0, 10.0])
    weights = rng.dirichlet(np.full(count, alpha))
    total_fraction = 1.0 if rng.random() < 0.85 else rng.beta(4, 1)
    return tuple(DELTA + extra * total_fraction * weights)


def structured_groups(count: int, cap: float) -> list[tuple[float, ...]]:
    extra = cap - count * DELTA
    result = []
    for active in range(1, count + 1):
        value = DELTA + extra / active
        result.append(tuple(sorted([value] * active + [DELTA] * (count - active), reverse=True)))
    return result


def capacities(omega0: float, gamma: float) -> tuple[float, ...]:
    return (
        gamma - 2 * DELTA - 8 * omega0 - 1e-10,
        0.5 - gamma - 2 * omega0 - 1e-10,
        4 * omega0 + DELTA - 1e-10,
        8 * omega0,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", choices=CASES, default="mixed66")
    parser.add_argument("--random", type=int, default=200_000)
    args = parser.parse_args()
    (m1, b1), (m2, b2), omega = CASES[args.case]
    gamma_high = 1 / 3 + 8 * omega + 7 * DELTA / 3 + 3e-10
    tested = 0

    left_structured = structured_groups(m1, b1)
    right_structured = structured_groups(m2, b2)
    for left in left_structured:
        for right in right_structured:
            for w in np.linspace(0, omega, 65):
                for gamma in np.linspace(XI2 - 1e-10, gamma_high, 65):
                    tested += 1
                    if not packable(left + right, capacities(float(w), float(gamma))):
                        print("COUNTEREXAMPLE structured", args.case, left, right, w, gamma, capacities(w, gamma))
                        return

    rng = np.random.default_rng(20260902)
    for index in range(args.random):
        left = group_sample(m1, b1, rng)
        right = group_sample(m2, b2, rng)
        # Mix uniform parameters with endpoint-biased beta draws.
        if index % 3 == 0:
            w_fraction = rng.choice([0.0, 1.0, rng.beta(.3, .3)])
            g_fraction = rng.choice([0.0, 1.0, rng.beta(.3, .3)])
        else:
            w_fraction = rng.random()
            g_fraction = rng.random()
        w = omega * w_fraction
        gamma = XI2 - 1e-10 + (gamma_high - (XI2 - 1e-10)) * g_fraction
        tested += 1
        if not packable(left + right, capacities(w, gamma)):
            print("COUNTEREXAMPLE random", args.case, left, right, w, gamma, capacities(w, gamma))
            return
    print(f"No counterexample for {args.case} in {tested} targeted instances.")


if __name__ == "__main__":
    main()
