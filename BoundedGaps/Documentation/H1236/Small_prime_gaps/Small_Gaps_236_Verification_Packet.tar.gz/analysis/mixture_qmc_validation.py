#!/usr/bin/env python3
"""Independent importance-sampling check of a compact two-slice witness."""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.special import logsumexp
from scipy.stats import qmc


K = 48
RADIUS = 0.258
DELTA = 0.014 / RADIUS
SPLIT = 0.253 / RADIUS
LOWER = np.array([0, .156, .156, .170, .184, .198, .212]) / RADIUS
UPPER = np.array([0, .153, .153, .167, .181, .195, .198]) / RADIUS
PROFILES = np.array([[4.5, .8], [3.5, 1.0], [2.8, 1.25]])
COEFFICIENTS = np.array([.0006, -.1032, 1.0])
LOWER_ONLY = False
DROP_CROSS_BAND = False
PROFILE_STEP = None
STEP_PREFIXES = None
LINEAR_KNOTS = None
LINEAR_HEIGHTS = None
LINEAR_PREFIXES = None
CHEB_POLYS = None
CHEB_PRIMS = None
CHEB_MAX = None


def normalizer(alpha: float, power: float) -> float:
    exponent = 1 - 2 * power
    if abs(exponent) < 1e-14:
        return math.log1p(alpha * K) / (alpha * K)
    return ((1 + alpha * K) ** exponent - 1) / (alpha * K * exponent)


def inverse_squared_cdf(values: np.ndarray, alpha: float, power: float) -> np.ndarray:
    exponent = 1 - 2 * power
    endpoint = (1 + alpha * K) ** exponent
    return ((1 + values * (endpoint - 1)) ** (1 / exponent) - 1) / (alpha * K)


def primitive(values: np.ndarray, alpha: float, power: float) -> np.ndarray:
    values = np.maximum(values, 0)
    exponent = 1 - power
    if abs(exponent) < 1e-14:
        return np.log1p(alpha * K * values) / (alpha * K)
    return ((1 + alpha * K * values) ** exponent - 1) / (alpha * K * exponent)


def support_state(points: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    total = points.sum(axis=1)
    large = points > DELTA
    count = large.sum(axis=1)
    large_sum = np.where(large, points, 0).sum(axis=1)
    return total, count, large_sum


def support_mask(points: np.ndarray) -> np.ndarray:
    total, count, large_sum = support_state(points)
    lower_cap = LOWER[np.minimum(count, len(LOWER) - 1)]
    upper_cap = UPPER[np.minimum(count, len(UPPER) - 1)]
    lower = (total <= SPLIT) & (large_sum <= lower_cap)
    if LOWER_ONLY:
        return lower
    return lower | (
        (total > SPLIT) & (total <= 1) & (large_sum <= upper_cap)
    )


def log_profiles(points: np.ndarray) -> np.ndarray:
    return np.stack(
        [-power * np.log1p(alpha * K * points).sum(axis=1) for alpha, power in PROFILES],
        axis=1,
    )


def step_log_profiles(points: np.ndarray) -> np.ndarray:
    assert PROFILE_STEP is not None
    bins = np.floor(points / PROFILE_STEP).astype(int)
    midpoints = (bins + .5) * PROFILE_STEP
    return np.stack(
        [-power * np.log1p(alpha * K * midpoints).sum(axis=1)
         for alpha, power in PROFILES],
        axis=1,
    )


def step_primitive(values: np.ndarray, column: int) -> np.ndarray:
    assert PROFILE_STEP is not None and STEP_PREFIXES is not None
    bins = np.floor(values / PROFILE_STEP).astype(int)
    bins = np.minimum(bins, STEP_PREFIXES.shape[1] - 2)
    remainder = values - bins * PROFILE_STEP
    alpha, power = PROFILES[column]
    midpoint = (bins + .5) * PROFILE_STEP
    height = (1 + alpha * K * midpoint) ** (-power)
    return STEP_PREFIXES[column, bins] + remainder * height


def linear_log_profiles(points: np.ndarray) -> np.ndarray:
    assert LINEAR_KNOTS is not None and LINEAR_HEIGHTS is not None
    columns = []
    for column in range(len(PROFILES)):
        heights = np.interp(points, LINEAR_KNOTS, LINEAR_HEIGHTS[column])
        columns.append(np.log(heights).sum(axis=1))
    return np.stack(columns, axis=1)


def linear_primitive(values: np.ndarray, column: int) -> np.ndarray:
    assert LINEAR_KNOTS is not None and LINEAR_HEIGHTS is not None
    indices = np.searchsorted(LINEAR_KNOTS, values, side="right") - 1
    indices = np.clip(indices, 0, len(LINEAR_KNOTS) - 2)
    offset = values - LINEAR_KNOTS[indices]
    width = LINEAR_KNOTS[indices + 1] - LINEAR_KNOTS[indices]
    lo = LINEAR_HEIGHTS[column, indices]
    hi = LINEAR_HEIGHTS[column, indices + 1]
    slope = (hi - lo) / width
    return LINEAR_PREFIXES[column, indices] + lo * offset + .5 * slope * offset**2


def cheb_profile_products(points: np.ndarray) -> np.ndarray:
    assert CHEB_POLYS is not None and CHEB_MAX is not None
    result = []
    for small_poly, large_poly in CHEB_POLYS:
        values = np.where(
            points <= DELTA,
            small_poly(points),
            np.where(points <= CHEB_MAX, large_poly(points), 0.),
        )
        result.append(np.prod(values, axis=1))
    return np.stack(result, axis=1)


def cheb_primitive(values: np.ndarray, column: int) -> np.ndarray:
    assert CHEB_PRIMS is not None and CHEB_MAX is not None
    small_primitive, large_primitive, small_total = CHEB_PRIMS[column]
    clipped = np.minimum(values, CHEB_MAX)
    return np.where(
        clipped <= DELTA,
        small_primitive(clipped) - small_primitive(0.),
        small_total + large_primitive(clipped) - large_primitive(DELTA),
    )


def proposal_log_density(log_values: np.ndarray, dimension: int, norms: np.ndarray) -> np.ndarray:
    return logsumexp(-math.log(len(PROFILES)) + 2 * log_values - dimension * np.log(norms), axis=1)


def signed_profile_sum(log_values: np.ndarray) -> np.ndarray:
    scale = log_values.max(axis=1)
    return np.exp(scale) * (np.exp(log_values - scale[:, None]) @ COEFFICIENTS)


def last_integrals(points: np.ndarray, selected_slices=None) -> np.ndarray:
    total, count, large_sum = support_state(points)
    result = np.zeros((len(points), len(PROFILES)))
    slices = selected_slices if selected_slices is not None else (((0.0, SPLIT, LOWER),) if LOWER_ONLY else (
        (0.0, SPLIT, LOWER), (SPLIT, 1.0, UPPER)
    ))
    for slice_lo, slice_hi, caps in slices:
        x_lo = np.maximum(0.0, slice_lo - total)
        x_hi = np.maximum(0.0, slice_hi - total)
        cap_same = caps[np.minimum(count, len(caps) - 1)]
        small_lo = x_lo
        small_hi = np.minimum(x_hi, DELTA)
        small_allowed = large_sum <= cap_same
        cap_next = caps[np.minimum(count + 1, len(caps) - 1)]
        large_lo = np.maximum(x_lo, DELTA)
        large_hi = np.minimum(x_hi, np.maximum(0.0, cap_next - large_sum))
        for column, (alpha, power) in enumerate(PROFILES):
            if CHEB_POLYS is not None:
                primitive_function = lambda x, _a, _p, c=column: cheb_primitive(x, c)
            elif LINEAR_KNOTS is not None:
                primitive_function = lambda x, _a, _p, c=column: linear_primitive(x, c)
            elif PROFILE_STEP is not None:
                primitive_function = lambda x, _a, _p, c=column: step_primitive(x, c)
            else:
                primitive_function = primitive
            small = np.where(
                small_allowed & (small_hi > small_lo),
                primitive_function(small_hi, alpha, power)
                - primitive_function(small_lo, alpha, power),
                0.0,
            )
            large = np.where(
                large_hi > large_lo,
                primitive_function(large_hi, alpha, power)
                - primitive_function(large_lo, alpha, power),
                0.0,
            )
            result[:, column] += small + large
    return result


def summarize(values: np.ndarray) -> tuple[float, float, float, float]:
    mean = float(values.mean())
    se = float(values.std(ddof=1) / math.sqrt(len(values)))
    ess = float(values.sum() ** 2 / np.square(values).sum())
    max_ratio = float(values.max() / mean)
    return mean, se, ess, max_ratio


def estimate(dimension: int, power: int, seed: int, kind: str) -> tuple[float, float, float, float]:
    sampler = qmc.Sobol(d=dimension + 1, scramble=True, seed=seed)
    uniforms = sampler.random_base2(power)
    component = np.minimum((uniforms[:, 0] * len(PROFILES)).astype(int), len(PROFILES) - 1)
    points = np.empty((len(uniforms), dimension))
    for index, (alpha, profile_power) in enumerate(PROFILES):
        selected = component == index
        points[selected] = inverse_squared_cdf(uniforms[selected, 1:], alpha, profile_power)
    norms = np.array([normalizer(alpha, profile_power) for alpha, profile_power in PROFILES])
    logs = log_profiles(points)
    log_q = proposal_log_density(logs, dimension, norms)
    if CHEB_POLYS is not None:
        target_products = cheb_profile_products(points)
    elif LINEAR_KNOTS is not None:
        target_logs = linear_log_profiles(points)
        target_products = np.exp(target_logs)
    elif PROFILE_STEP is not None:
        target_logs = step_log_profiles(points)
        target_products = np.exp(target_logs)
    else:
        target_logs = logs
        target_products = np.exp(target_logs)
    if kind == "I":
        f = target_products @ COEFFICIENTS
        values = np.where(support_mask(points), np.square(f) * np.exp(-log_q), 0.0)
    else:
        if DROP_CROSS_BAND:
            squares = np.zeros(len(points))
            extrema = []
            profile_factors = COEFFICIENTS * target_products
            for one_slice in ((0.0, SPLIT, LOWER), (SPLIT, 1.0, UPPER)):
                h = np.sum(
                    profile_factors * last_integrals(points, (one_slice,)), axis=1
                )
                squares += np.square(h)
                extrema.append((float(h.min()), float(h.max())))
            values = squares * np.exp(-log_q)
        else:
            h = np.sum(COEFFICIENTS * target_products * last_integrals(points), axis=1)
            values = np.square(h) * np.exp(-log_q)
    return summarize(values)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--power", type=int, default=19, help="Sobol sample size is 2**power")
    parser.add_argument("--replicates", type=int, default=8)
    parser.add_argument("--seed-offset", type=int, default=0)
    parser.add_argument("--lower-m5", type=float, default=.198)
    parser.add_argument("--lower-m6", type=float, default=.212)
    parser.add_argument("--upper-m5", type=float, default=.195)
    parser.add_argument("--lower-only", action="store_true")
    parser.add_argument("--drop-cross-band", action="store_true")
    parser.add_argument("--profile-step-physical", type=float)
    parser.add_argument("--profile-linear-knots-physical")
    parser.add_argument("--profile-chebyshev-degrees")
    args = parser.parse_args()
    global LOWER_ONLY, DROP_CROSS_BAND, PROFILE_STEP, STEP_PREFIXES
    global LINEAR_KNOTS, LINEAR_HEIGHTS, LINEAR_PREFIXES
    global CHEB_POLYS, CHEB_PRIMS, CHEB_MAX
    LOWER_ONLY = args.lower_only
    DROP_CROSS_BAND = args.drop_cross_band
    if args.profile_step_physical is not None:
        PROFILE_STEP = args.profile_step_physical / RADIUS
        count = int(math.ceil(1 / PROFILE_STEP)) + 1
        midpoints = (np.arange(count) + .5) * PROFILE_STEP
        heights = np.vstack([
            (1 + alpha * K * midpoints) ** (-power)
            for alpha, power in PROFILES
        ])
        STEP_PREFIXES = np.concatenate(
            (np.zeros((len(PROFILES), 1)), np.cumsum(heights * PROFILE_STEP, axis=1)),
            axis=1,
        )
    if args.profile_linear_knots_physical:
        physical = np.asarray([
            float(value) for value in args.profile_linear_knots_physical.split(",")
        ])
        if physical[0] != 0 or abs(physical[-1] - RADIUS) > 1e-12:
            raise ValueError("linear knots must start at 0 and end at the radius")
        LINEAR_KNOTS = physical / RADIUS
        LINEAR_HEIGHTS = np.vstack([
            (1 + alpha * K * LINEAR_KNOTS) ** (-power)
            for alpha, power in PROFILES
        ])
        widths = np.diff(LINEAR_KNOTS)
        areas = (LINEAR_HEIGHTS[:, :-1] + LINEAR_HEIGHTS[:, 1:]) * widths / 2
        LINEAR_PREFIXES = np.concatenate(
            (np.zeros((len(PROFILES), 1)), np.cumsum(areas, axis=1)), axis=1
        )
    if args.profile_chebyshev_degrees:
        from numpy.polynomial import Chebyshev
        small_degree, large_degree = map(
            int, args.profile_chebyshev_degrees.split(",")
        )
        CHEB_MAX = .202 / RADIUS
        CHEB_POLYS = []
        CHEB_PRIMS = []
        for alpha, power in PROFILES:
            function = lambda x, a=alpha, p=power: (1 + a * K * x) ** (-p)
            small_poly = Chebyshev.interpolate(
                function, small_degree, domain=[0., DELTA]
            )
            large_poly = Chebyshev.interpolate(
                function, large_degree, domain=[DELTA, CHEB_MAX]
            )
            small_primitive = small_poly.integ()
            large_primitive = large_poly.integ()
            small_total = small_primitive(DELTA) - small_primitive(0.)
            CHEB_POLYS.append((small_poly, large_poly))
            CHEB_PRIMS.append((small_primitive, large_primitive, small_total))
    LOWER[5] = args.lower_m5 / RADIUS
    LOWER[6:] = args.lower_m6 / RADIUS
    UPPER[5:] = args.upper_m5 / RADIUS
    rows = []
    for replicate in range(args.replicates):
        seed_index = args.seed_offset + replicate
        i = estimate(K, args.power, 1000 + seed_index, "I")
        j = estimate(K - 1, args.power, 2000 + seed_index, "J")
        quotient = RADIUS * K * j[0] / i[0]
        rows.append((i[0], j[0], quotient))
        print(
            f"rep={replicate} I={i[0]:.8e} I_se={i[1]:.2e} I_ess={i[2]:.0f} I_max/mean={i[3]:.1f} "
            f"J={j[0]:.8e} J_se={j[1]:.2e} J_ess={j[2]:.0f} J_max/mean={j[3]:.1f} q={quotient:.9f}",
            flush=True,
        )
    array = np.asarray(rows)
    print(
        f"replicate_mean_q={array[:,2].mean():.9f} "
        f"replicate_se_q={array[:,2].std(ddof=1)/math.sqrt(len(array)):.3e}",
    )


if __name__ == "__main__":
    main()
