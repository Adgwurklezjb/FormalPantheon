#!/usr/bin/env python3
"""Exact-dual replay of the tightened mixed 6+6 coupled LP screen.

HiGHS discovers a rank allocation and LP dual.  Every accepted dual is then
rationalized and checked using Fraction arithmetic against the exact parameter
cell.  Thus floating point proposes certificates but never decides validity.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from fractions import Fraction as Q

import numpy as np
from scipy.optimize import linprog

from typeiic_coupled_rank_lp import (
    DELTA,
    PAPER_EPSILON,
    XI2,
    conditional_polytope,
    find_partition,
    load_margins,
)


D = Q(7, 500)
E = Q(1, 10**10)
XI = Q(4021, 10000)
DEFAULT_OMEGA = Q(11, 2000)
DEFAULT_TOTAL = Q(2, 5)


def exact_polytope(n: int, j: int, segments: int, iw: int, ig: int, total: Q, omega: Q):
    gamma_low = XI - E
    gamma_high = Q(1, 3) + 8 * omega + 7 * D / 3 + 3 * E
    w_lo, w_hi = omega * iw / segments, omega * (iw + 1) / segments
    g_lo = gamma_low + (gamma_high - gamma_low) * ig / segments
    g_hi = gamma_low + (gamma_high - gamma_low) * (ig + 1) / segments
    width = n + 2
    rows = []
    rhs = []
    for index in range(n - 1):
        row = [Q(0)] * width; row[index] = 1; row[index + 1] = -1
        rows.append(row); rhs.append(Q(0))
    row = [Q(0)] * width
    for index in range(n): row[index] = 1
    rows.append(row); rhs.append(total)
    row = [Q(0)] * width
    for index in range(j - 1, n): row[index] = -1
    row[n] = -8; row[n + 1] = 1
    rows.append(row); rhs.append(2 * D + E)
    row = [Q(0)] * width
    for index in range(j, n): row[index] = 1
    row[n] = 8; row[n + 1] = -1
    rows.append(row); rhs.append(-2 * D - E)
    lower = [D] * n + [w_lo, g_lo]
    upper = [None] * n + [w_hi, g_hi]
    return rows, rhs, lower, upper


def exact_feasible(n: int, j: int, segments: int, iw: int, ig: int, total: Q, omega: Q) -> bool:
    """Exact feasibility criterion for the sorted stopping-rank polytope."""
    _rows, _rhs, lower, upper = exact_polytope(n, j, segments, iw, ig, total, omega)
    w_lo, g_lo = lower[n], lower[n + 1]
    w_hi, g_hi = upper[n], upper[n + 1]
    c_min = g_lo - 2 * D - 8 * w_hi - E
    c_max = g_hi - 2 * D - 8 * w_lo - E
    # Sufficiency: choose the first j-1 masses equal to D and distribute a
    # crossing total C equally over the remaining n-j+1 ranks.
    return max(c_min, (n - j) * D) <= min(c_max, total - (j - 1) * D)


def objective(n: int, j: int, bin_index: int, mask: int) -> tuple[np.ndarray, Q]:
    """Return minimization f=-linear and the required lower bound."""
    linear = np.zeros(n + 2)
    selected = [index for index in range(j) if mask >> index & 1]
    linear[selected] = 1
    if bin_index == 0:
        linear[j:n] = 1; linear[n] = 8; linear[n + 1] = -1
        threshold = 2 * D + E
    elif bin_index == 1:
        linear[n] = 2; linear[n + 1] = 1
        threshold = -Q(1, 2) + E
    elif bin_index == 2:
        linear[n] = -4
        threshold = -D + E
    else:
        linear[n] = -8
        threshold = Q(0)
    return -linear, threshold


def rationalize(values: np.ndarray, denominator: int) -> list[Q]:
    return [Q(str(float(value))).limit_denominator(denominator) for value in values]


def certify_dual(
    f_float: np.ndarray,
    result,
    exact,
    threshold: Q,
    denominator: int,
) -> tuple[Q, dict[str, object]] | None:
    rows, rhs, lower, upper = exact
    f = [Q(str(float(value))).limit_denominator(10) for value in f_float]
    y = rationalize(result.ineqlin.marginals, denominator)
    lo = rationalize(result.lower.marginals, denominator)
    hi = rationalize(result.upper.marginals, denominator)
    if any(value > 0 for value in y) or any(value < 0 for value in lo) or any(value > 0 for value in hi):
        return None
    width = len(f)
    for column in range(width):
        stationarity = f[column] - sum(y[row] * rows[row][column] for row in range(len(rows))) - lo[column] - hi[column]
        if stationarity != 0:
            return None
    value = sum(y[index] * rhs[index] for index in range(len(rhs)))
    value += sum(lo[index] * lower[index] for index in range(width))
    value += sum(hi[index] * upper[index] for index in range(width) if upper[index] is not None)
    if value < threshold:
        return None
    sparse = {
        "y": [(i, str(v)) for i, v in enumerate(y) if v],
        "lo": [(i, str(v)) for i, v in enumerate(lo) if v],
        "hi": [(i, str(v)) for i, v in enumerate(hi) if v],
        "value": str(value),
        "threshold": str(threshold),
    }
    return value, sparse


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--segments", type=int, default=32)
    parser.add_argument("--n", type=int, default=12)
    parser.add_argument("--total", default=str(DEFAULT_TOTAL))
    parser.add_argument("--omega", default=str(DEFAULT_OMEGA))
    parser.add_argument("--max-denominator", type=int, default=1_000_000)
    parser.add_argument("--output")
    args = parser.parse_args()
    n = args.n
    total = Q(args.total)
    omega = Q(args.omega)
    c1_global_min = XI - 2 * D - 8 * omega - 2 * E
    stopping_bound = next(j for j in range(1, n + 1) if total - j * D < c1_global_min)
    records = []
    active = 0
    weakest = None
    for iw in range(args.segments):
        for ig in range(args.segments):
            gamma_low = XI2 - PAPER_EPSILON
            gamma_high = 1 / 3 + 8 * float(omega) + 7 * DELTA / 3 + 3 * PAPER_EPSILON
            float_poly_args = (
                n,
                None,
                float(total),
                (float(omega) * iw / args.segments, float(omega) * (iw + 1) / args.segments),
                (
                    gamma_low + (gamma_high - gamma_low) * ig / args.segments,
                    gamma_low + (gamma_high - gamma_low) * (ig + 1) / args.segments,
                ),
            )
            for j in range(1, stopping_bound + 1):
                poly = conditional_polytope(float_poly_args[0], j, *float_poly_args[2:])
                feasible_exactly = exact_feasible(n, j, args.segments, iw, ig, total, omega)
                if (poly is not None) != feasible_exactly:
                    raise RuntimeError(f"float/exact feasibility mismatch at {(iw, ig, j)}")
                if poly is None:
                    continue
                active += 1
                margins = load_margins(n, j, poly)
                # The exploratory screen tolerates 1e-9.  Exact replay uses a
                # much smaller discovery tolerance so an O(epsilon) violation
                # cannot be mistaken for a certifiable boundary equality.
                witness = find_partition(margins, tolerance=1e-12)
                if witness is None:
                    raise RuntimeError(f"no floating witness at {(iw, ig, j)}")
                exact = exact_polytope(n, j, args.segments, iw, ig, total, omega)
                cell_records = []
                for bin_index, mask in enumerate(witness):
                    f, threshold = objective(n, j, bin_index, mask)
                    a_float, b_float, bounds_float = poly
                    result = linprog(f, A_ub=a_float, b_ub=b_float, bounds=bounds_float, method="highs")
                    if not result.success:
                        raise RuntimeError(result.message)
                    certificate = certify_dual(f, result, exact, threshold, args.max_denominator)
                    if certificate is None:
                        raise RuntimeError(f"dual rationalization failed at {(iw, ig, j, bin_index, mask)}")
                    value, sparse = certificate
                    slack = value - threshold
                    if weakest is None or slack < weakest[0]:
                        weakest = (slack, iw, ig, j, bin_index, mask)
                    cell_records.append({"bin": bin_index, "mask": mask, **sparse})
                records.append({"iw": iw, "ig": ig, "j": j, "witness": list(witness), "duals": cell_records})
        print(f"completed omega row {iw + 1}/{args.segments}", flush=True)
    encoded = json.dumps(records, sort_keys=True, separators=(",", ":")).encode()
    digest = hashlib.sha256(encoded).hexdigest()
    if args.output:
        with open(args.output, "wb") as handle:
            handle.write(encoded)
    print("active_conditions", active, "exact_duals", 4 * active)
    print("parameters", {"n": n, "total": str(total), "omega": str(omega), "segments": args.segments})
    print("stopping_rank_bound", f"j<={stopping_bound} since total-j*D < min(C1)")
    print("weakest", weakest)
    print("sha256", digest)


if __name__ == "__main__":
    main()
