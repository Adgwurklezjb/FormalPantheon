#!/usr/bin/env python3
"""Greedily reduce a saved variational profile basis."""

from __future__ import annotations

import argparse

import numpy as np
from scipy.linalg import eigh


def solve(imat: np.ndarray, jmat: np.ndarray, k: int, radius: float, cutoff: float) -> tuple[float, float, int]:
    scale = 1 / np.sqrt(np.diag(imat))
    si = scale[:, None] * imat * scale[None, :]
    sj = scale[:, None] * jmat * scale[None, :]
    vals, vecs = eigh(si)
    keep = vals > cutoff
    whitening = vecs[:, keep] / np.sqrt(vals[keep])[None, :]
    quotient = radius * k * float(eigh(whitening.T @ sj @ whitening, eigvals_only=True)[-1])
    return quotient, float(vals[0]), int(keep.sum())


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("matrix_file")
    parser.add_argument("--cutoff", type=float, default=0.0)
    parser.add_argument("--minimum-size", type=int, default=8)
    args = parser.parse_args()
    data = np.load(args.matrix_file)
    full_i = data["imat"]
    full_j = data["jmat"]
    profiles = data["profiles"]
    radius = float(data["radius"])
    k = int(data["k"])
    indices = list(range(len(profiles)))
    while len(indices) >= args.minimum_size:
        current_i = full_i[np.ix_(indices, indices)]
        current_j = full_j[np.ix_(indices, indices)]
        quotient, smallest, rank = solve(current_i, current_j, k, radius, args.cutoff)
        print(
            f"size={len(indices):2d} rank={rank:2d} quotient={quotient:.12f} "
            f"min_corr={smallest:.3e} profiles={indices}",
            flush=True,
        )
        if len(indices) == args.minimum_size:
            break
        choices = []
        for removed in indices:
            trial = [index for index in indices if index != removed]
            trial_i = full_i[np.ix_(trial, trial)]
            trial_j = full_j[np.ix_(trial, trial)]
            trial_q, trial_smallest, trial_rank = solve(trial_i, trial_j, k, radius, args.cutoff)
            choices.append((trial_q, trial_smallest, trial_rank, removed, trial))
        choices.sort(reverse=True, key=lambda item: item[0])
        best = choices[0]
        print(
            f"  remove={best[3]} profile={profiles[best[3]].tolist()} "
            f"next_quotient={best[0]:.12f}",
            flush=True,
        )
        indices = best[4]


if __name__ == "__main__":
    main()
