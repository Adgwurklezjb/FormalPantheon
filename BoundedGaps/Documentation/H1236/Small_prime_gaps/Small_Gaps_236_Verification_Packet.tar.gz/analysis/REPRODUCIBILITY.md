# Small-gaps candidate: reproducibility notes

This directory records an exploratory, manuscript-conditional candidate for
`H_1 <= 236`. It is not an unconditional theorem. The support certificate is
exact within the stated Proposition 2/3 model. For the final degree-`(8,12)` rational
two-piece polynomial witness, all six `I` entries are exact rationals and all
six `J` entries have rigorous 1024-bit Arb enclosures. The saved certificate's
minorant-adjusted lower endpoint exceeds one. The implication remains
conditional on the unrefereed analytic framework and independent reproduction.

## Final parameters

- `k=48`, `delta=.014`, total slices `.253,.258`
- lower caps `0,.156,.156,.170,.184,.190,.202`
- upper caps `0,.153,.153,.167,.181,.190,.190`
- profiles `4.5:.8:48,3.5:1:48,2.8:1.25:48`
- rounded vector `(.0006,-.1032,1)`
- final polynomial vector `(571087/10^9,-12804621/125000000,1)`

## Principal files

- `final_support_dx001.npz`: final three-profile deterministic matrices.
- `final_support_dx00075.npz`: finer final-support diagnostic matrices.
- `qmc_final3_p21_r8.log`: eight final-support scrambled-Sobol replicates.
- `exact_step_i_h00025.json`: all six exact-rational I entries for the
  decimal-rational midpoint step witness with physical step `1/4000`.
- `exact_step_i.py`: FLINT truncated-power/incomplete-beta exact I evaluator.
- `step_profile_h00025_qmc.npz`: discovery matrices and independent validation
  values for the step witness.
- `qmc_linear15_p20_r8.log`: higher-sample validation of the frozen 15-segment
  piecewise-linear witness (`mean=1.001803565`, `SE=0.0004655`).
- `two_piece_chebyshev_8_12.json`: exact-decimal two-piece polynomial profiles
  and the final rational mixture vector.
- `exact_chebyshev_i_8_12.json`: all six exact-rational `I` entries.
- `arb_chebyshev_j*_8_12.json`: all six exact-geometry, 1024-bit Arb `J`
  enclosures.
- `chebyshev_8_12_certificate.json`: saved passing contraction, including input
  hashes and the elementary rational Harman-loss upper bound.
- `exact_chebyshev_i.py`, `exact_chebyshev_j.py`, and
  `check_chebyshev_certificate.py`: construction and cheap replay.
- `qmc_chebyshev_8_12_p19_r8.log` and `qmc_chebyshev_8_12_p21_r4.log`:
  independent fixed-vector checks.
- `inner_outer_i_probe.py`, `step_function_probe.py`, and
  `step_j_cell_bounds.py`: negative certification gates showing why uniform
  boxes, contained cells, and endpoint-only J bounds were abandoned.
- `two_slice_mixture_probe.py`: deterministic convolution constructor.
- `mixture_qmc_validation.py`: independent importance-sampling calculation.
- `typeiic_exact_dual_replay.py`: floating discovery followed by exact-rational
  feasibility, stationarity, sign, dual-objective, and threshold checks.
- `verify_adaptive_hand_lemmas.py`: exact-fraction checks for the eight adaptive
  hand-lemma exceptions.
- `typeiic_exact_dual_N32.log`, `exact_u45_N32.log`, `exact_*_N8.log`,
  `exact_surgery2_*_N16.log`, and `exact_surgery3_*_N16.log`: successful exact
  replay logs. Together they contain 11,359 conditional polytopes and 45,436
  exactly checked bin inequalities.

## Key replay commands

```bash
python audit_bundle.py

python two_slice_mixture_probe.py \
  --dx .001 \
  --profiles '4.5:.8:48,3.5:1:48,2.8:1.25:48' \
  --lower-caps '0,.156,.156,.170,.184,.190,.202' \
  --upper-caps '0,.153,.153,.167,.181,.190,.190' \
  --save-matrices final_support_dx001.npz

python mixture_qmc_validation.py \
  --lower-m5 .190 --lower-m6 .202 --upper-m5 .190 \
  --power 21 --replicates 8 --seed-offset 400

python freeze_chebyshev_candidate.py \
  --degrees 8,12 --vector .000571087,-.102436968,1 \
  --output two_piece_chebyshev_8_12.json

python exact_chebyshev_i.py two_piece_chebyshev_8_12.json \
  --all --output exact_chebyshev_i_8_12.json

for pair in 0,0 1,0 1,1 2,0 2,1 2,2; do
  compact=${pair/,/}
  python exact_chebyshev_j.py two_piece_chebyshev_8_12.json \
    --pair "$pair" --arb-bits 1024 \
    --checkpoint "arb_chebyshev_j${compact}_checkpoint.json" \
    --output "arb_chebyshev_j${compact}_8_12.json"
done

python check_chebyshev_certificate.py \
  --output chebyshev_8_12_certificate.json

python verify_adaptive_hand_lemmas.py

python typeiic_exact_dual_replay.py \
  --segments 32 --n 12 --total .400 --omega .0055
```

The last command is the principal mixed-`6+6` replay. The other replay logs
record their exact `n`, total, omega, subdivision, counts, and canonical hash.
The replayer accepts a certificate only after rationalizing the proposed dual
and checking every dual identity with Python `Fraction` arithmetic.

The final certificate uses the exact upper bound
`1291475390625/14389093733134384 < 8.976e-5` for the two discarded Harman
regions, rather than their nonrigorous quadrature estimate. The raw quotient is
enclosed by `1.0016199680 +/- 8.30e-11`; the conservative adjusted lower
endpoint is `1.001530068839...`.
