#!/usr/bin/env python3
"""Search continuously for a Type-IIc rank-3 counterexample by MILP.

The binaries encode that every one of the 4^3 assignments violates at least
one bin capacity.  This is a discovery/diagnostic calculation: a negative
floating MILP result needs an exact infeasibility certificate before use in a
proof.
"""

from __future__ import annotations

import argparse
import itertools

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp

from typeiic_coupled_rank_lp import (
    CASES,
    DELTA,
    PAPER_EPSILON,
    XI2,
    conditional_polytope,
)


def violation(n: int, assignment: tuple[int, int, int], bin_index: int) -> tuple[np.ndarray, float]:
    """Return l,c such that l.x+c is load minus capacity for one bin."""
    vector = np.zeros(n + 2)
    selected = [index for index, target in enumerate(assignment) if target == bin_index]
    vector[selected] = 1
    if bin_index == 0:
        vector[3:n] = 1
        vector[n] = 8
        vector[n + 1] = -1
        constant = 2 * DELTA + PAPER_EPSILON
    elif bin_index == 1:
        vector[n] = 2
        vector[n + 1] = 1
        constant = -0.5 + PAPER_EPSILON
    elif bin_index == 2:
        vector[n] = -4
        constant = -DELTA + PAPER_EPSILON
    else:
        vector[n] = -8
        constant = 0.0
    return vector, constant


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", choices=CASES, default="mixed66")
    parser.add_argument("--epsilon", type=float, default=1e-9)
    parser.add_argument("--m-value", type=float, default=1.0)
    parser.add_argument(
        "--groups",
        action="store_true",
        help="enforce the two six-element slice totals in the mixed66 case",
    )
    args = parser.parse_args()

    n, total_bound, omega = CASES[args.case]
    gamma_low = XI2 - PAPER_EPSILON
    gamma_high = 1 / 3 + 8 * omega + 7 * DELTA / 3 + 3 * PAPER_EPSILON
    polytope = conditional_polytope(
        n, 3, total_bound, (0.0, omega), (gamma_low, gamma_high)
    )
    if polytope is None:
        raise RuntimeError("rank-3 conditional polytope is empty")
    base_a, base_b, base_bounds = polytope

    if args.groups and args.case != "mixed66":
        raise ValueError("the group-label MILP is currently parameterized for mixed66")
    assignments = list(itertools.product(range(4), repeat=3))
    binary_count = 4 * len(assignments)
    group_width = 2 * n if args.groups else 0
    packing_start = n + 2 + group_width
    width = packing_start + binary_count
    rows = []
    lower = []
    upper = []

    for row, rhs in zip(base_a, base_b):
        extended = np.zeros(width)
        extended[: n + 2] = row
        rows.append(extended)
        lower.append(-np.inf)
        upper.append(rhs)

    if args.groups:
        # z_i labels six ranks as lower-slice items and s_i=y_i z_i.  Standard
        # bounded McCormick inequalities are exact because z_i is binary.
        label_start = n + 2
        product_start = label_start + n
        upper_mass = total_bound
        row = np.zeros(width)
        row[label_start : label_start + n] = 1
        rows.append(row)
        lower.append(6)
        upper.append(6)
        for index in range(n):
            yi = index
            zi = label_start + index
            si = product_start + index
            # s >= delta*z
            row = np.zeros(width); row[si] = -1; row[zi] = DELTA
            rows.append(row); lower.append(-np.inf); upper.append(0)
            # s <= U*z
            row = np.zeros(width); row[si] = 1; row[zi] = -upper_mass
            rows.append(row); lower.append(-np.inf); upper.append(0)
            # s <= y-delta*(1-z)
            row = np.zeros(width); row[si] = 1; row[yi] = -1; row[zi] = -DELTA
            rows.append(row); lower.append(-np.inf); upper.append(-DELTA)
            # s >= y-U*(1-z)
            row = np.zeros(width); row[si] = -1; row[yi] = 1; row[zi] = upper_mass
            rows.append(row); lower.append(-np.inf); upper.append(upper_mass)
        row = np.zeros(width)
        row[product_start : product_start + n] = 1
        rows.append(row); lower.append(-np.inf); upper.append(0.212)
        row = np.zeros(width)
        row[:n] = 1
        row[product_start : product_start + n] = -1
        rows.append(row); lower.append(-np.inf); upper.append(0.198)

    big_m = args.m_value
    for assignment_index, assignment in enumerate(assignments):
        # At least one bin must violate for this assignment to fail.
        row = np.zeros(width)
        start = packing_start + 4 * assignment_index
        row[start : start + 4] = -1
        rows.append(row)
        lower.append(-np.inf)
        upper.append(-1)

        for bin_index in range(4):
            linear, constant = violation(n, assignment, bin_index)
            row = np.zeros(width)
            row[: n + 2] = -linear
            row[start + bin_index] = big_m
            # v >= eta-M(1-z), equivalently -l.x+Mz <= c+M-eta.
            rows.append(row)
            lower.append(-np.inf)
            upper.append(constant + big_m - args.epsilon)

    base_lb = [bound[0] if bound[0] is not None else -np.inf for bound in base_bounds]
    base_ub = [bound[1] if bound[1] is not None else np.inf for bound in base_bounds]
    if args.groups:
        lb = np.array(base_lb + [0] * n + [0] * n + [0] * binary_count)
        ub = np.array(base_ub + [1] * n + [total_bound] * n + [1] * binary_count)
        integrality = np.array([0] * (n + 2) + [1] * n + [0] * n + [1] * binary_count)
    else:
        lb = np.array(base_lb + [0] * binary_count)
        ub = np.array(base_ub + [1] * binary_count)
        integrality = np.array([0] * (n + 2) + [1] * binary_count)
    result = milp(
        np.zeros(width),
        integrality=integrality,
        bounds=Bounds(lb, ub),
        constraints=LinearConstraint(np.asarray(rows), np.asarray(lower), np.asarray(upper)),
        options={"time_limit": 300.0, "mip_rel_gap": 0.0},
    )
    print("status", result.status, result.message)
    if result.x is not None:
        values = result.x[: n + 2]
        print("masses", values[:n].tolist())
        print("omega0", values[n], "gamma", values[n + 1], "total", values[:n].sum())
        if args.groups:
            labels = result.x[n + 2 : n + 2 + n]
            print("group_one_ranks", np.flatnonzero(labels > 0.5).tolist())
        best = None
        for assignment in assignments:
            violations = [
                float(linear @ values + constant)
                for linear, constant in (violation(n, assignment, b) for b in range(4))
            ]
            score = max(violations)
            if best is None or score < best[0]:
                best = (score, assignment, violations)
        print("best_assignment", best)


if __name__ == "__main__":
    main()
