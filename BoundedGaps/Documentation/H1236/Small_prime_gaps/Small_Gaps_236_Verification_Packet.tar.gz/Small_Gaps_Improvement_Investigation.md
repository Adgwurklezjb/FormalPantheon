# Serious attempt to improve the small-prime-gap bound

**Status date:** 3 September 2026  
**Bottom line:** a computer-assisted, manuscript-conditional route to $H_1\le236$ has now been completed at the variational and support-certificate levels. The new ingredient is a two-slice, count-capped support combined with a rational two-piece polynomial product weight. Three targeted “cap surgeries” spend little variational mass but simplify every formerly unresolved Type-IIc count pair. Across the difficult pairs, the coupled LP proofs have been replayed by 45,436 exact rational dual checks, and eight more oracle exceptions have direct hand proofs. For the final degree-$(8,12)$ polynomial witness, all six $I$ entries are exact rationals and all six $J$ entries have 1024-bit Arb enclosures. Even after replacing the numerically estimated Harman-minorant loss by a much looser elementary rational upper bound, the rigorous lower endpoint is $1.0015300688>1$. This is **not presented as an unconditional theorem**: it still depends on the unrefereed Stadlmann analytic framework, on the report's extension of its support certification, and on independent reproduction of the new computation.

## 1. What would improve

Write

\[
H_1=\liminf_{n\to\infty}(p_{n+1}-p_n).
\]

The peer-reviewed Polymath8b result is $H_1\le246$. Julia Stadlmann's 2026 manuscript claims $H_1\le240$ by making the Maynard sieve work with $k=49$. The natural next rate-like improvement is to reduce the required sieve dimension to $k=48$.

The finite tuple endpoint must be handled carefully. An exact mixed-integer optimization gives:

| Diameter | Maximum admissible cardinality |
|---:|---:|
| 234 | 47 |
| 236 | 48 |

Thus $k=48$ would imply

\[
\boxed{H_1\le236},
\]

not 234. The same exact optimization gives 46 offsets in diameter 224 and 47 in diameter 226, so a future $k=47$ argument would imply $H_1\le226$.

An explicit admissible 48-tuple of width 236 found and replayed by the optimizer is

\[
\begin{aligned}
\{&0,6,8,14,18,24,26,48,50,54,56,60,66,68,74,78,80,84,90,96,98,104,\\
&110,116,120,126,134,138,144,150,158,164,168,176,180,186,188,194,200,\\
&204,206,210,216,224,228,230,234,236\}.
\end{aligned}
\]

### 1.1 Ideas collected before committing to the candidate

Several ideas from large-gap work have useful small-gap analogues, but only after translation. The most productive transfer was to treat scarce analytic “capacity” as something to allocate nonuniformly rather than fixing one symmetric cutoff everywhere.

| Large-gap motif | Small-gap translation tried here | Outcome |
|---|---|---|
| Allocate prime ranges to different jobs | Allocate support mass to lower/upper slices and to large-coordinate-count strata | **Productive:** generated the two-slice support. |
| Nibble/cover locally rather than use one global residue rule | Use cell-specific, parameter-coupled Type-IIc packings | **Productive:** removes artificial corner losses and underlies the exact finite certificates. |
| Sacrifice a thin exceptional set to simplify cleanup | Tighten only the rare $m\ge5$ strata | **Most productive new step:** total cap surgery costs $2.75\times10^{-4}$ at the coarse deterministic mesh and makes every Type-IIc cell exactly certifiable. |
| Lossless final transfer | Optimize the admissible tuple exactly after fixing $k$ | **Closed:** $H(48)=236$ in the relevant search, while diameter 234 supports at most 47 offsets. |
| Hypergraph matching/absorption | Couple many support-cell partition choices globally | **Not useful here:** the distribution theorem requires a uniform local factorization, not merely average global coverage. |

The parts usually treated as immovable were precisely the high-leverage ones: the support/distribution interface, componentwise minimization over analytic parameters, rare high-count strata, the $K(F)$ penalty, and the final admissible-tuple endpoint. The first three produced progress; the $K(F)$ penalty and tuple endpoint behaved as hard barriers.

## 2. Most promising construction

### 2.1 Analytic parameters

The candidate uses

\[
k=48,\qquad \delta=0.014,\qquad
(\xi_1,\xi_2,\xi_3)=(0.3795,0.4021,0.4021).
\]

The two total-mass slices end at $0.253$ and $0.258$. If

\[
m=\#\{i:t_i>\delta\},\qquad L(t)=\sum_{t_i>\delta}t_i,
\]

the lower-slice and upper-slice caps are

| $m$ | 0 | 1 | 2 | 3 | 4 | 5 | $6+$ |
|---:|---:|---:|---:|---:|---:|---:|---:|
| $B^{(1)}_m$, total mass $\le0.253$ | 0 | .156 | .156 | .170 | .184 | .190 | .202 |
| $B^{(2)}_m$, total mass $0.253<S\le0.258$ | 0 | .153 | .153 | .167 | .181 | .190 | .190 |

The increments obey $B_{m+1}\le B_m+\delta$. These are proof-oriented revisions of the initially optimized plateaux $(0.198,0.212)$ and $(0.195,0.198)$. The lower $m\ge6$ change reduces the troublesome mixed $6+6$ total from $0.410$ to $0.400$; the upper $m\ge5$ plateau and lower $m=5$ cap eliminate the six residual high-count exceptions.

All global inequalities in Propositions 2 and 3 of the Stadlmann manuscript pass. The exact slack after moving the required right-hand side to zero is:

| Condition | Slack |
|---|---:|
| Proposition 2: $2\xi_1+3\xi_2<2$ | $0.0347$ |
| Proposition 2: $\xi_1+9\xi_2<4$ | $0.0016$ |
| Proposition 2: $2\xi_1+\xi_2>1$ | $0.1611$ |
| Proposition 2: $17\xi_2<7$ | $0.1643$ |
| Proposition 3 Type I, binding branch | $1.6666647\times10^{-4}$ |
| Proposition 3 Type II range | $0.03000001$ |
| Proposition 3 Type II, first delta branch | $6.099998\times10^{-4}$ |
| Proposition 3 Type II, second delta branch | $2.49998\times10^{-5}$ |
| Proposition 3 Type III | $5.6374998\times10^{-3}$ |

The second Type-II branch is the tight analytic inequality. A proof version should preserve exact rational arithmetic and avoid moving the parameters closer to this boundary.

### 2.2 Compact trial function

Put $u_i=t_i/0.258$. On the capped two-slice support, consider

\[
F(u)=\mathbf 1_T(u)\sum_{\ell=1}^3c_\ell\prod_{i=1}^{48}
(1+48\alpha_\ell u_i)^{-p_\ell},
\]

with

\[
(\alpha_\ell,p_\ell)=
\left(\frac92,\frac45\right),
\left(\frac72,1\right),
\left(\frac{14}{5},\frac54\right)
\]

and the rounded coefficient vector

\[
\boxed{(c_1,c_2,c_3)=(0.0006,-0.1032,1)}.
\]

This smooth function was the search witness; the final certificate below uses a finite rational polynomial approximation. The manuscript's numerical quadrature at $\xi_2=0.4021$ gives the minorant mass loss

\[
c_{\rm min}\approx3.2984237457\times10^{-7}.
\]

This numerical value is not used in the final proof replay. Section 3.4 replaces it by an elementary exact upper bound. Also, $\beta=1-2\xi_2=0.1958$ exceeds the two one-large-coordinate caps $0.156$ and $0.153$, as required by Proposition 1. In the limiting $\varepsilon=0$ support, the strict region defining $K(F)$ is empty: the common-coordinate sum is at most the upper endpoint of either total-mass slice. The target inequality therefore becomes

\[
48(1-c_{\rm min})\frac{J(F)}{I(F)}>1.
\]

## 3. Numerical evidence

### 3.1 Deterministic convolution grids

The integrals were reduced to capped convolutions tracking total small-coordinate mass, total large-coordinate mass, and the number of coordinates above $\delta$. A direct comparison of the original and proof-oriented supports gives:

| Mesh $dx$ | Original optimized support | Final proof-oriented support | Cost |
|---:|---:|---:|---:|
| .002 | 0.997709865941 | 0.997434859180 | $2.75\times10^{-4}$ |
| .001 | 1.000441703447 | 1.000226712638 | $2.15\times10^{-4}$ |
| .00075 | — | 1.001075061217 | — |

At $dx=.001$, the fixed rounded vector $(0.0006,-0.1032,1)$ on the final support gives raw quotient $1.000203663062$, or $1.000203333152$ after the minorant factor. The mesh is still not a rigorous enclosure.

A final refinement at $dx=.00075$ gives $1.001042205895$ for that same predeclared rounded vector, or $1.001041875709$ after the minorant factor. Its newly optimized vector is $(0.0005687,-0.1031694,1)$, essentially unchanged from the coarser-grid choice. This third mesh point moves toward the independent QMC estimate rather than back below one, but it remains diagnostic rather than rigorous evidence.

For the original support, at $dx=.00075$ the rounded vector above gives

\[
48J/I=1.001254020447,
\]

and after the minorant factor,

\[
48(1-c_{\rm min})J/I=1.001253690191.
\]

The correlation-normalized $I$-matrix for the final support at $dx=.001$ has smallest eigenvalue $0.03604$, so the three-dimensional problem is well conditioned. The measured surgery cost is about one eighth of the independent QMC point-estimate surplus.

On the original support, a ten-profile reserve calculation at $dx=.001$ gives the larger raw value

\[
1.002342107234
\]

with correlation eigenvalue floor $9.62\times10^{-4}$. The three-profile witness is preferable for certification; the ten-profile calculation shows that additional variational margin exists.

### 3.2 Independent scrambled-Sobol calculation

To test the convolution grid and the previously reported heavy-tail danger at $\delta=.014$, the rounded three-profile witness on the tightened support was re-evaluated by an independent importance-sampling construction:

- $I$ was sampled directly in 48 dimensions;
- $J$ was sampled in 47 dimensions, with the last-coordinate integral evaluated analytically;
- the proposal was an equal mixture of the three squared product profiles;
- 8 independent scrambles, each with $2^{21}$ points, were used.

The final-support pooled result was

\[
48J/I=1.001771092\pm0.0003025
\]

(empirical standard error across scrambles). Multiplying by $1-c_{\rm min}$, the nominal 95% lower value is

\[
1.001177862.
\]

The importance weights were tame: max/mean was about 5.6 for $I$ and 5.9 for $J$, with effective sample sizes around $5.45\times10^5$ and $6.16\times10^5$ out of $2^{21}$. This is not the rare-large-weight pathology that invalidated an earlier, different $\delta=.014$ search.

These computations are mutually consistent, but neither is an interval proof.

### 3.3 Explicit interval-error budget

For the fixed rounded vector and the $dx=.001$ matrices, define

\[
S=0.258\cdot48\,v^TJv-(1-c_{\rm min})^{-1}v^TIv.
\]

The computed values are $v^TIv=2.3934194754\times10^{-110}$ and $S=4.8666168662\times10^{-114}$. Propagating independent entrywise relative errors through the signed quadratic form shows that a common relative enclosure radius below

\[
9.6\times10^{-6}
\]

for each of the twelve independent matrix entries spends at most half of this conservative grid-level slack. The dominant entries are $I_{22}$ and $J_{22}$ (about 51% of the error budget together), followed by $I_{12},J_{12}$ (about 24%). This gives the rigorous integration stage a concrete precision target; effort should be concentrated on those four entries.

At the final $dx=.00075$ diagnostic matrix the analogous half-slack radius is $4.93\times10^{-5}$. The report retains the stricter $9.6\times10^{-6}$ target above because it was fixed from the less favorable crossing and therefore gives a safer certification specification.

### 3.4 Continuation: finite proof-oriented witnesses

The first interval-certification attempt revealed that arithmetic precision was not the immediate obstacle. Uniform inner/outer boxes lose too much at the sloping support boundary: at physical mesh $h=.00025$, the six individual $I$-entry gaps range from $1.15\%$ to $26.0\%$. Defining the trial function itself to be constant only on wholly contained boxes removes the enclosure ambiguity but gives optimized quotient $0.9795243$ at $h=.00025$ (and $0.9053754$ at $h=.001$). Extrapolation would require an impractically fine state array, so this route was abandoned.

A better finite construction keeps the exact sloping support and replaces each one-dimensional profile by its midpoint step function on physical intervals of width $1/4000$. With the frozen rational vector $(0.0006,-0.1032,1)$, eight $2^{19}$-point scrambled-Sobol replicates give

\[
48J/I=1.001744943\pm0.0003202.
\]

A three-by-three matrix calculation followed by eight independent validation matrices selects $(0.0005913,-0.1031906,1)$ and gives validation mean $1.002667416\pm0.0005867$; all eight validation values exceed one. The simpler rounded vector remains preferable for an exact certificate.

Every step height was then rounded to 17 significant decimal digits and interpreted as an exact rational number. A new FLINT calculation uses the identity

\[
\int_0^\infty g(t)e^{-st}\,dt=\frac{P(e^{-hs})}{s}
\]

for a step function $g$, exact truncated powers of $P$, and the integer incomplete-beta polynomial for the two group sums. This produces all six $I$-matrix entries as exact rationals. In normalized coordinates they are

\[
\begin{pmatrix}
9.6784702276\!\times\!10^{-105}&1.7721725876\!\times\!10^{-106}&1.9775564262\!\times\!10^{-108}\\
1.7721725876\!\times\!10^{-106}&4.2826509719\!\times\!10^{-108}&7.0251913058\!\times\!10^{-110}\\
1.9775564262\!\times\!10^{-108}&7.0251913058\!\times\!10^{-110}&1.8834764888\!\times\!10^{-111}
\end{pmatrix}.
\]

For the rounded vector, the exact denominator is $1.6905473989443323\times10^{-110}$ after normalization. The independent QMC entries differ from these exact values by at most $7.96\times10^{-4}$, consistent with their sampling error.

The uniform step grid is exact but creates 1,032 last-coordinate pieces. A more efficient witness linearly interpolates the same three profiles at the 16 rational knots

\[
0,.00025,.0005,.001,.002,.004,.007,.010,.014,.020,.030,.050,.080,.120,.180,.258.
\]

Thus it has only 15 linear segments. With the rounded vector, eight independent $2^{20}$-point replicates give

\[
48J/I=1.001803565\pm0.0004655,
\]

with tame max/mean weights between $12.5$ and $14.7$. The nominal 95% lower value is about $1.00089$ before the $3.30\times10^{-7}$ minorant loss. Pruning to 9 or 11 segments fell below one, so the 15-segment version is frozen.

The successful simplification was instead to use only two polynomial pieces per profile. For each of the three smooth one-coordinate profiles, take its Chebyshev interpolant of degree 8 on the physical interval $[0,.014]$ and degree 12 on $[.014,.202]$, and set it to zero beyond $.202$. Every binary64 Chebyshev coefficient was printed to 17 significant digits and then interpreted as an exact decimal rational. The frozen rational mixture vector is

\[
\boxed{(c_1,c_2,c_3)=
\left(\frac{571087}{10^9},-\frac{12804621}{125000000},1\right)}.
\]

Eight independent $2^{19}$-point validation matrices give $1.000773844\pm0.0002337$, with every replicate above one. A separate four-replicate $2^{21}$ replay gives $1.001470208\pm0.0005935$. The latter agrees with the rigorous value below to $0.25$ reported standard errors.

For $I$, the Laplace transform of each small-interval product is represented as a polynomial in $s^{-1}$ and $e^{-\delta s}$. After taking the 48th power, each capped two-group convolution reduces to an exact univariate polynomial composition. FLINT rational arithmetic gives the normalized matrix

\[
I=\begin{pmatrix}
1.134324924922\!\times\!10^{-104}&2.074872619046\!\times\!10^{-106}&2.327878927497\!\times\!10^{-108}\\
2.074872619046\!\times\!10^{-106}&5.010082774703\!\times\!10^{-108}&8.266631294112\!\times\!10^{-110}\\
2.327878927497\!\times\!10^{-108}&8.266631294112\!\times\!10^{-110}&2.230081305677\!\times\!10^{-111}
\end{pmatrix}.
\]

For $J$, the 47 common coordinates are compressed into residual small and large sums. Combining the four possible last-coordinate components (two bands times small/large status) before multiplying reduces 21,559 pairwise cells to 2,655 global rational cells, with at most 37 in one status. Exact rational geometry determines the cells; 1024-bit Arb arithmetic encloses the polynomial contractions. The normalized matrix is

\[
J=\begin{pmatrix}
8.62740627938\!\times\!10^{-106}&1.65374676917\!\times\!10^{-107}&1.9406722244\!\times\!10^{-109}\\
1.65374676917\!\times\!10^{-107}&4.01956058425\!\times\!10^{-109}&6.4891996669\!\times\!10^{-111}\\
1.9406722244\!\times\!10^{-109}&6.4891996669\!\times\!10^{-111}&1.569136856\!\times\!10^{-112}
\end{pmatrix},
\]

where the entrywise relative ball radii are at most about $2.2\times10^{-10}$. Contracting with the frozen vector gives

\[
I(F)=1.99485223272594845\times10^{-110},\qquad
J(F)\in1.6134397849\times10^{-111}\pm8.12\times10^{-122},
\]

and hence

\[
48(0.258)\frac{J(F)}{I(F)}
\in1.0016199680\pm8.30\times10^{-11}.
\]

The manuscript's displayed exceptional-region mass is numerical, so the final replay uses a direct rational majorant. Put $t=4021/10000$ and $\beta=1-2t=979/5000$. In exceptional region A the four integration widths are at most $5t-2,(5t/2-1),(5t/2-1),(5t/2-1)$; in B they are at most $10t-4,(5t/2-1),5t-2,10t-4$. All five reciprocal factors are at most $\beta^{-1}$. Therefore

\[
c_1=L_A+L_B\le
\frac{1291475390625}{14389093733134384}
<8.976\times10^{-5}.
\]

This is roughly 272 times the numerical estimate, but the standalone ball replay still gives

\[
\boxed{48(0.258)(1-c_1)\frac{J(F)}{I(F)}
\ge1.001530068839\ldots>1.}
\]

The $24K(F)$ term is zero in the limiting support, as explained in Section 2.2. Thus the finite variational inequality is closed within Proposition 1's framework.

Several apparent shortcuts were conclusively rejected along the way. The lower band alone gives $0.983183\pm0.000530$; retaining both bands but dropping their $J$ cross term gives $0.958983\pm0.000656$. The band interaction is therefore essential. A monotone endpoint enclosure for the step $J_{11}$ entry has a $1.34\%$ geometric gap and was stopped after that first entry. Direct polynomial eigensearches also produced seed-unstable near-null directions, while a fixed published polynomial had prohibitive QMC variance. The successful two-piece construction avoided both the excessive step-function geometry and the unstable high-dimensional polynomial eigensearch.

## 4. Support certification audit

An independent exact-rational implementation of Stadlmann's Proposition 2/3 oracle was applied to the candidate cells.

### What is closed

- Every global Proposition 2/3 inequality passes exactly.
- Among 1,984 non-Type-IIc local cell checks, the oracle supplies universal continuous order-statistic witnesses for all but three cases.
- The three exceptions are lower/lower Type IIb at $(m,m')=(6,6),(6,7),(7,7)$. They admit a short hand proof:

  Let the total mass be $S\le0.424$, and let $r=\max(0,S-0.39)\le0.034$. Order the at least 12 items increasingly and stop at the first partial sum reaching $r$. The preceding partial sum is below $0.034<0.038857142$. Because every item is at least $0.014$, the new item is among the first three; the total and item-count bounds give it size at most $0.0396<0.06$. Put the preceding partial sum in the $0.038857142$ bin, the new item in the $0.06$ bin, and everything else in the $0.39$ bin.

- The manuscript's printed Type-IIc range includes negative $\omega_0$ while demanding an $8\omega_0$ bin; literally this is impossible. The proof's intended repair is to use Bombieri–Vinogradov for $\omega_0\le0$ and Proposition 3 only for $0\le\omega_0\le\omega$. The independent oracle makes this split explicit.

- The upper-slice Type-IIc pairs $a+m$ with $a\in\{1,2\}$ and $m\in\{3,4,5\}$, which fail the oracle's fixed consecutive-block template, have a direct adaptive proof. (The $a=1$ and $a=2$ blocks have the same total cap $0.153$.) Let $b_1\le\cdots\le b_m$ be the items in the $m$-block and let $r=\max(0,T-C_1)$ be the mass that must leave the primary bin. Here

  \[
  C_2=0.472-10\omega_0-2\varepsilon-C_1,
  \qquad
  C_3=0.014+4\omega_0-\varepsilon,
  \qquad C_4=8\omega_0.
  \]

  For $m=3$, $r<0.009901<\delta$, so remove $b_1$ to $C_2$; the conditional bound $C_2>0.072$ and $b_1\le0.167/3$ suffice. For $m=4$, $r<0.023901<2\delta$. If $b_1\ge r$, remove $b_1$ to $C_2$. Otherwise $b_1+b_2\ge2\delta>r$, so remove both: $b_2\le(0.181-0.014)/3<0.056<C_2$, while $r>b_1\ge\delta$ forces $\omega_0>0.0067624$, hence $b_1<r<C_3$. For $m=5$, first remove $b_1$ if $b_1\ge r$, or $b_1,b_2$ if $b_1<r\le b_1+b_2$; in the second case put $b_2$ in $C_2$ and $b_1$ in $C_4$, since $r>\delta$ forces $C_4>0.040>b_1$. In the last case $b_1+b_2<r<0.037901$, remove $b_1,b_2,b_3$, put $b_3$ in $C_2$ using $C_2>0.044+r>0.072$ and $b_3\le(0.195-2\delta)/3<0.056$, and put $b_1,b_2$ in $C_3,C_4$. Here $b_2<r-b_1<0.023901$, while $r>2\delta$ forces $C_3>0.041$ and $C_4>0.054$. All displayed margins dominate the manuscript's $10^{-10}$ padding.

- The mixed lower-$3$/upper-$4$ and lower-$4$/upper-$3$ exceptions have the same two-item proof. Their total mass is at most $0.351$, hence $r<0.020901<2\delta$. Choose the smaller block items $b_1\le b_2\le\cdots$ from the upper side. If $b_1\ge r$, put it in $C_2$, whose conditional lower bound is $0.066+r$. Otherwise remove $b_1,b_2$; the larger is at most $0.0765<C_2$ because now $C_2>0.080$, and $r>\delta$ forces $\omega_0>0.0046374$, so $b_1<r<C_3$. The other items remain in the primary bin.

### Coupled LP and cap surgery

The original oracle takes componentwise minima of the four Type-IIc capacities over the entire $(\omega_0,\gamma)$ rectangle. This combines incompatible parameter corners. A new discovery screen instead keeps the masses, $\omega_0$, and $\gamma$ in one linear program. Conditional on the stopping rank, it searches all fixed allocations of the selected ranks and bounds each bin load over the coupled polytope.

For the original mixed $6+6$ total $0.410$, a $64\times64$ parameter subdivision still leaves 1,064 of 4,096 rank-3 rectangles without a fixed witness. With the lower $m\ge6$ cap reduced from $0.212$ to $0.202$, the total is $0.400$ and **all 1,024 rectangles, across every feasible stopping rank, pass at $32\times32$ resolution**. The full replay uses floating point only to propose an allocation and LP dual, then checks multiplier signs, stationarity, the dual objective, and the desired bin inequality with exact fractions. It verifies 3,776 nonempty conditional polytopes and 15,104 dual inequalities. Exact interval intersection checks decide which stopping cells are empty, and $0.400-5\delta=0.330<\min C_1$ proves no stopping rank above five occurs. The canonical digest is `2de69b2c3b4f7988124513ec38da9902986b8c292454cc20de7e7964e6730b2c`.

On the reduced frontier $0\le m,m'\le6$, the exact rational oracle checks 105 non-BV slice pairs. Seventy pass its existing witness and 35 initially fail only Type IIc; on the final cap table the original template itself passes 73 and leaves 32. The hand lemmas above close eight exceptions. Exact coupled-LP replay covers the other former exceptions (including three now redundant replays after cap surgery). In total, 11,359 conditional polytopes and 45,436 bin inequalities were checked by exact rational duality. The exploratory $10^{-9}$ allocation tolerance was not trusted: exact replay exposed one $O(10^{-10})$ violation, the discovery tolerance was tightened to $10^{-12}$, an alternative allocation was found, and the rational checks then passed. Thus **no Type-IIc pair remains open for the final support**. Counts above six reduce to this frontier by merging surplus items within a plateau block; a packing of the merged item expands back into a packing of its constituents.

### What remains open

The support side is closed within the manuscript's Proposition 2/3 model, and the degree-$(8,12)$ witness closes the finite variational inequality. The original smooth, step, and 15-segment witnesses can now be treated as discarded cross-checks rather than unfinished proof obligations.

Three validation tasks remain before this should be presented as a theorem. First, the new exact-$I$/Arb-$J$ implementation should be reproduced independently, ideally with a different density representation. Second, the exact dual certificates and the eight hand packings should be rewritten as a single human-checkable extension of the manuscript's support proposition. Third, the underlying 2026 equidistribution manuscript itself is unrefereed; this report has checked its stated inequalities and exposed one intended Bombieri--Vinogradov branch repair, but it has not independently reproved the manuscript's analytic estimates. The appropriate current label is therefore **computer-assisted and manuscript-conditional**.

Before the exact certificates were constructed, counterexample searches found none:

| Target Type-IIc case | Targeted instances |
|---|---:|
| mixed $4+4$ | 217,600 |
| mixed $6+6$ | 352,100 |
| upper $6+6$ | 352,100 |
| upper $10+10$ | 522,500 |

These tests included a $65\times65$ parameter grid for balanced-to-spiky structured mass patterns, plus endpoint-biased random samples. An earlier broad test also covered all nonempty count pairs. They were useful diagnostics but were never treated as proof; the exact dual and hand certificates above supersede them.

The cap-surgery progression is itself useful: rather than prove an unnecessarily general packing theorem, remove a very thin, high-count part of support until a finite exact certificate exists, measuring the variational price at every step.

## 5. Approaches tried and deliberately abandoned

| Approach | Finding | Decision |
|---|---|---|
| Single product profile | Best value near the needed range but below threshold. | Abandon as too rigid. |
| Simple symmetric polynomial basis | Reproduced known low-dimensional behavior but reached only about 3.63 in the corresponding unscaled $M_{48}$. | Abandon for this support. |
| Uniformly enlarge every cap | Produced explicit balanced Type-IIc packing counterexamples. | Rejected. |
| Optimize raw coefficient magnitude | Small raw coefficients can be important because profile $I$-norms differ; crude pruning fell below one. | Use correlation-normalized reduction instead. |
| Asymmetric weights | Symmetrization preserves the symmetric support and objective; no gain without tuple-dependent distribution input. | Low priority. |
| Prime-pair upper bounds | They control nuisance terms but do not supply the lower mass needed to cross the sieve threshold. | Rejected absent new signed input. |
| Permit $K(F)>0$ | The coefficient of $K$ is 24, overwhelming the observed $10^{-3}$-scale surplus. | Keep $K=0$. |
| Naive finite grid of all $\Xi$ tuples | At $c=.001$, worst integer-partition counts reach hundreds of millions. | Replace by structural/ordered witnesses. |
| Keep enlarging the numerical basis | Ten profiles already show reserve margin; more profiles increase runtime and proof difficulty. | Freeze the three-profile witness. |
| Continue random Type-IIc search | More than 1.4 million targeted cases found no failure, but can never prove universality. | Stop; prove the lemma instead. |
| Uniform fixed-rank subdivision on the original support | Small upper cells still fail at $128\times128$. | Combine adaptive hand lemmas with proof-oriented cap surgery and exact dual replay. |
| Evaluate all $J$ contractions as exact reduced fractions | The all-small stratum agrees with QMC, but positive-large strata suffer prohibitive numerator/denominator swell. | Keep the geometry exact and use 1024-bit Arb balls for the contractions. |

## 6. Ranked avenues from here

The percentages are subjective research probabilities, not statistical claims. “Payoff” is relative to the manuscript's 240.

| Rank | Avenue | Chance of a valid improvement | Potential payoff | Why it ranks here |
|---:|---|---:|---:|---|
| 1 | Independent reimplementation and formal write-up of the completed certificate | 65–80% | validate $240\to236$ | Every finite inequality now crosses with slack; the main risk is a shared convention or support-translation error. |
| 2 | Recheck or reprove the manuscript's analytic equidistribution layer | 35–55% | make the 236 argument substantially firmer | The new computation uses the manuscript exactly where it is currently unrefereed; this is now the largest non-computational dependency. |
| 3 | Optimize a slightly richer low-degree two-piece basis using the exact engine | 15–30% for more $k=48$ margin; 5–10% for $k=47$ | robustness, remotely $236\to226$ | The exact machinery can now price candidates, but $k=47$ needs a far larger gain than the present $0.153\%$ certified surplus. |
| 4 | Promote the incomplete-rectangle Type-IIc theorem at $A=2029/8000$ and combine it with the two-piece basis | 15–25% | robustness or $\to226$ | It attacks the binding support constraint, but still needs a full human proof rather than computational screens alone. |
| 5 | Add a narrowly targeted third slice around the balanced Type-IIc obstruction | 8–15% | possibly $\to226$ | It may recover support mass, but multiplies local distribution cases; use the exact oracle as an early gate. |
| 6 | Jointly optimize $\delta$, cap schedules, minorant parameters, and profiles with exact feasibility in the loop | 5–12% for $k=47$ | $236\to226$ | This is the most plausible next finite-bound improvement after validation of 236. |
| 7 | Improve the Harman minorant so positive $K$-leakage becomes affordable | 3–8% | potentially $\to226$ or better | High leverage, but requires a new signed decomposition; constant tuning is insufficient. |
| 8 | Prove a materially stronger prime-distribution theorem for the relevant incomplete rectangles | 1–5% | potentially several sieve dimensions | Largest upside, lowest near-term probability; this is a genuine analytic breakthrough. |
| 9 | Search for a narrower 48-tuple | 0% below 236 | none | Exact MILP proves diameter 234 has at most 47 elements; 236 is optimal for $k=48$. |

## 7. Recommended proof program

1. **Freeze the completed witness.** Preserve the degree-$(8,12)$ exact-decimal polynomial file, rational vector, cap table, six exact $I$ entries, six Arb $J$ entries, and rational mass-loss majorant. Do not reoptimize during verification.
2. **Independently replay the integrals.** Prefer a different representation, such as Bernstein pieces plus interval convolution, and check all six entries rather than only the final quadratic form.
3. **Formalize the support extension.** Turn the 45,436 rational dual inequalities, plateau reduction, and eight hand cases into a concise proposition whose hypotheses visibly match Stadlmann's Proposition 3.
4. **Audit the analytic layer.** Verify the manuscript's equidistribution estimates and the $\omega_0\le0$ Bombieri--Vinogradov branch repair independently of the optimization code.
5. **Only then promote the conclusion.** State $H_1\le236$ as a computer-assisted conditional result until the underlying analytic framework and the new support extension have received external review.

## 8. Reproducibility record

The active investigation ran from 11:08:46 UTC on 2 September through at least 00:25 UTC on 3 September 2026, more than thirteen hours. The work included source reconstruction, analytic-inequality audits, variational searches, counterexample searches, cap-schedule revisions, exact rational certificate replay, independent QMC, deterministic mesh refinement, failed interval and projection approaches, and the final exact-$I$/Arb-$J$ construction.

The accompanying bundle contains the deterministic matrices, QMC logs, exact-dual replayer, exact replay logs, adaptive hand-lemma verifier, exact step-$I$ output, and all exploratory scripts. Its `analysis/REPRODUCIBILITY.md` gives the parameters and replay commands; `analysis/audit_bundle.py` performs the principal consistency checks. The central exact-support totals are 11,359 conditional polytopes and 45,436 rational dual inequalities. The final variational files are `two_piece_chebyshev_8_12.json`, `exact_chebyshev_i_8_12.json`, the six `arb_chebyshev_j*_8_12.json` files, and `chebyshev_8_12_certificate.json`; `check_chebyshev_certificate.py` replays the decisive inequality in under a second.

The numerical discovery stage uses NumPy/SciPy. Exact acceptance of the support certificates uses Python `Fraction` arithmetic after floating discovery; changing an LP allocation, parameter cell, or proposed dual forces a fresh exact check. The final $I$ matrix uses FLINT `fmpq`; the $J$ geometry is rational and its contractions use 1024-bit Arb balls. A 256-bit trial was deliberately rejected because physical-power-basis cancellation produced a useless enclosure.

## 9. Sources and verification status

- James Maynard, [*Small gaps between primes*](https://annals.math.princeton.edu/2015/181-1/p07), Annals of Mathematics 181 (2015): the multidimensional sieve and variational framework.
- D. H. J. Polymath, [*Variants of the Selberg sieve, and bounded intervals containing many primes*](https://arxiv.org/abs/1407.4897): the peer-reviewed 246 benchmark and enlarged-support optimization.
- Julia Stadlmann, [*Bounded gaps between primes*](https://arxiv.org/abs/2608.31126): the 2026 manuscript claiming 240, its generalized support, Harman minorant, and Proposition 2/3 criteria.
- [Independent exact reconstruction and research audit](https://github.com/royvanrijn/primegaps): exact replay of the manuscript's $k=49$ certificate, exact distribution oracle, source errata, and negative $k=48$ experiments used as cross-checks here.
- [MIT narrow admissible tuple database](https://math.mit.edu/~primegaps/): maintained endpoint data. The 234/236 and 224/226 claims above were additionally replayed by exact-integrality MILP with matching primal and dual cardinality bounds.

The Stadlmann manuscript and the new incomplete-rectangle work are not peer-reviewed as of the status date. The finite support and variational certificates in this report are complete, but the claimed implication $H_1\le236$ remains conditional on that analytic framework and on independent verification of the new computer-assisted extension.
