#!/usr/bin/env python3
"""Diagnostic inner/outer cell bounds for the six positive I entries.

This is not yet a rigorous arithmetic certificate: Gauss--Legendre weights and
FFT convolutions are used in double precision.  The support classification is
exact when every physical threshold is a multiple of ``h``.  Its purpose is to
decide whether a uniform-cell certificate can possibly fit inside the final
quadratic-form margin before implementing directed rounding.
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.signal import fftconvolve


K = 48
RADIUS = .258
DELTA = .014
SPLIT = .253
LOWER = [0, .156, .156, .170, .184, .190, .202]
UPPER = [0, .153, .153, .167, .181, .190, .190]
PROFILES = [(4.5, .8), (3.5, 1.), (2.8, 1.25)]


def checked_index(value: float, h: float) -> int:
    index = round(value / h)
    if abs(index * h - value) > 1e-12:
        raise ValueError(f"threshold {value} is not aligned to h={h}")
    return index


def bin_integrals(profile_a, profile_b, edges, order=16):
    nodes, weights = np.polynomial.legendre.leggauss(order)
    lo, hi = edges[:-1], edges[1:]
    points = (lo[:, None] + hi[:, None]) / 2 + (hi - lo)[:, None] * nodes / 2
    values = np.ones_like(points)
    for alpha, power in (profile_a, profile_b):
        values *= (1 + alpha * K * points / RADIUS) ** (-power)
    return (hi - lo) / 2 * (values @ weights)


def positive_convolve(left, right):
    result = fftconvolve(left, right)
    result[result < 0] = 0
    return result


def powers(base, maximum):
    answer = [np.ones(1)]
    for _ in range(maximum):
        answer.append(positive_convolve(answer[-1], base))
    return answer


def interval_sum(prefix, lo, hi):
    lo = max(0, lo)
    hi = min(len(prefix) - 2, hi)
    if hi < lo:
        return 0.0
    return prefix[hi + 1] - prefix[lo]


def union_sum(prefix, first, second):
    intervals = []
    for lo, hi in (first, second):
        lo, hi = max(0, lo), min(len(prefix) - 2, hi)
        if lo <= hi:
            intervals.append((lo, hi))
    if not intervals:
        return 0.0
    intervals.sort()
    total = 0.0
    lo, hi = intervals[0]
    for new_lo, new_hi in intervals[1:]:
        if new_lo <= hi + 1:
            hi = max(hi, new_hi)
        else:
            total += interval_sum(prefix, lo, hi)
            lo, hi = new_lo, new_hi
    return total + interval_sum(prefix, lo, hi)


def i_bounds(profile_a, profile_b, h):
    delta_i = checked_index(DELTA, h)
    split_i = checked_index(SPLIT, h)
    radius_i = checked_index(RADIUS, h)
    lower_i = [checked_index(x, h) for x in LOWER]
    upper_i = [checked_index(x, h) for x in UPPER]
    max_cap_i = max(lower_i[-1], upper_i[-1])

    small_edges = np.arange(delta_i + 1) * h
    big_edges = np.arange(delta_i, max_cap_i + 1) * h
    small = bin_integrals(profile_a, profile_b, small_edges)
    big = bin_integrals(profile_a, profile_b, big_edges)
    small_powers = powers(small, K)
    big_powers = powers(big, max_cap_i // delta_i)

    inner = outer = 0.0
    for m in range(len(big_powers)):
        cap_l = lower_i[min(m, len(lower_i) - 1)]
        cap_u = upper_i[min(m, len(upper_i) - 1)]
        small_count = K - m
        if small_count < 0:
            break
        sp = small_powers[small_count]
        prefix = np.concatenate(([0.0], np.cumsum(sp)))
        bp = big_powers[m]
        choose = math.comb(K, m)
        subtotal_inner = subtotal_outer = 0.0
        for shifted_big_i, big_mass in enumerate(bp):
            if big_mass == 0:
                continue
            big_lo = m * delta_i + shifted_big_i
            big_hi = big_lo + m

            lower_outer_ok = m == 0 or big_lo < cap_l
            upper_outer_ok = m == 0 or big_lo < cap_u
            first = (0, split_i - big_lo - 1) if lower_outer_ok else (1, 0)
            second = (
                split_i - big_lo - K + 1,
                radius_i - big_lo - 1,
            ) if upper_outer_ok else (1, 0)
            subtotal_outer += big_mass * union_sum(prefix, first, second)

            lower_inner_ok = m == 0 or big_hi <= cap_l
            upper_inner_ok = m == 0 or big_hi <= cap_u
            lower_range = (0, split_i - big_lo - K) if lower_inner_ok else (1, 0)
            upper_range = (
                split_i - big_lo,
                radius_i - big_lo - K,
            ) if upper_inner_ok else (1, 0)
            crossing_ok = lower_inner_ok and upper_inner_ok
            crossing_range = (
                split_i - big_lo - K + 1,
                min(split_i - big_lo - 1, radius_i - big_lo - K),
            ) if crossing_ok else (1, 0)
            subtotal_inner += big_mass * (
                interval_sum(prefix, *lower_range)
                + interval_sum(prefix, *crossing_range)
                + interval_sum(prefix, *upper_range)
            )
        inner += choose * subtotal_inner
        outer += choose * subtotal_outer
    return inner, outer


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--h", type=float, default=.00025)
    args = parser.parse_args()
    inner = np.empty((3, 3))
    outer = np.empty((3, 3))
    for row, left in enumerate(PROFILES):
        for col in range(row + 1):
            lo, hi = i_bounds(left, PROFILES[col], args.h)
            inner[row, col] = inner[col, row] = lo
            outer[row, col] = outer[col, row] = hi
            print(
                row, col,
                f"inner={lo:.12e}", f"outer={hi:.12e}",
                f"relative_gap={(hi-lo)/((hi+lo)/2):.6g}",
                flush=True,
            )
    np.savez(
        f"inner_outer_i_h{args.h:.8f}.npz",
        inner=inner, outer=outer, h=args.h,
    )


if __name__ == "__main__":
    main()
