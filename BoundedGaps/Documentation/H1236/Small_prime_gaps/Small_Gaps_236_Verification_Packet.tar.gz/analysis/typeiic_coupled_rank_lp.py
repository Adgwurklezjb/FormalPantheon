#!/usr/bin/env python3
"""Parameter-coupled rank certificates for the Type-IIc packing condition.

This is a floating-point discovery screen.  Unlike the first rectangle screen,
it keeps omega_0 and gamma as LP variables, so the four affine capacities are
never minimized at mutually incompatible corners.  A successful screen must
still be replayed with exact rational LP dual certificates.
"""

from __future__ import annotations

import argparse
import itertools

import numpy as np
from scipy.optimize import linprog


DELTA = 0.014
XI2 = 0.4021
PAPER_EPSILON = 1e-10
CASES = {
    "mixed66": (12, 0.410, 0.0055),
    "mixed44": (8, 0.365, 0.0055),
    "upper66": (12, 0.396, 0.008),
    "upper1010": (20, 0.396, 0.008),
}


def conditional_polytope(
    n: int,
    j: int,
    total_bound: float,
    w_bounds: tuple[float, float],
    g_bounds: tuple[float, float],
) -> tuple[np.ndarray, np.ndarray, list[tuple[float | None, float | None]]] | None:
    """Return Ax<=b for a stopping rank j, with variables (y_1,...,y_n,w,g)."""
    rows: list[np.ndarray] = []
    rhs: list[float] = []
    width = n + 2

    # Globally sorted masses y_1 <= ... <= y_n.
    for index in range(n - 1):
        row = np.zeros(width)
        row[index] = 1
        row[index + 1] = -1
        rows.append(row)
        rhs.append(0.0)
    row = np.zeros(width)
    row[:n] = 1
    rows.append(row)
    rhs.append(total_bound)

    # Previous prefix fails: sum_{i=j-1}^{n-1} y_i >= gamma-2delta-8w-epsilon.
    row = np.zeros(width)
    row[j - 1 : n] = -1
    row[n] = -8
    row[n + 1] = 1
    rows.append(row)
    rhs.append(2 * DELTA + PAPER_EPSILON)

    # Current prefix succeeds: sum_{i=j}^{n-1} y_i <= gamma-2delta-8w-epsilon.
    row = np.zeros(width)
    row[j:n] = 1
    row[n] = 8
    row[n + 1] = -1
    rows.append(row)
    rhs.append(-2 * DELTA - PAPER_EPSILON)

    bounds = [(DELTA, None)] * n + [w_bounds, g_bounds]
    a_ub = np.asarray(rows)
    b_ub = np.asarray(rhs)
    feasibility = linprog(
        np.zeros(width), A_ub=a_ub, b_ub=b_ub, bounds=bounds, method="highs"
    )
    if not feasibility.success:
        return None
    return a_ub, b_ub, bounds


def add_group_bounds(
    polytope: tuple[np.ndarray, np.ndarray, list[tuple[float | None, float | None]]],
    n: int,
    group_one: tuple[int, ...],
    bound_one: float,
    bound_two: float,
) -> tuple[np.ndarray, np.ndarray, list[tuple[float | None, float | None]]]:
    """Intersect a rank polytope with the two originating slice totals."""
    a_ub, b_ub, bounds = polytope
    row_one = np.zeros(n + 2)
    row_one[list(group_one)] = 1
    row_two = np.zeros(n + 2)
    group_two = sorted(set(range(n)) - set(group_one))
    row_two[group_two] = 1
    return (
        np.vstack((a_ub, row_one, row_two)),
        np.concatenate((b_ub, [bound_one, bound_two])),
        bounds,
    )


def maximum(
    objective: np.ndarray,
    a_ub: np.ndarray,
    b_ub: np.ndarray,
    bounds: list[tuple[float | None, float | None]],
) -> float:
    result = linprog(-objective, A_ub=a_ub, b_ub=b_ub, bounds=bounds, method="highs")
    if not result.success:
        raise RuntimeError(result.message)
    return -float(result.fun)


def load_margins(
    n: int,
    j: int,
    polytope: tuple[np.ndarray, np.ndarray, list[tuple[float | None, float | None]]],
) -> np.ndarray:
    """Worst load-minus-capacity for each bin and rank subset.

    Bin zero includes the post-prefix tail; bins one through three contain
    only the selected prefix ranks.  Nonpositive entries certify the load.
    """
    a_ub, b_ub, bounds = polytope
    width = n + 2
    margins = np.empty((4, 1 << j))
    for mask in range(1 << j):
        selected = [index for index in range(j) if mask >> index & 1]

        objective = np.zeros(width)
        objective[j:n] = 1
        objective[selected] = 1
        objective[n] = 8
        objective[n + 1] = -1
        margins[0, mask] = maximum(objective, a_ub, b_ub, bounds) + 2 * DELTA + PAPER_EPSILON

        objective = np.zeros(width)
        objective[selected] = 1
        objective[n] = 2
        objective[n + 1] = 1
        margins[1, mask] = maximum(objective, a_ub, b_ub, bounds) - 0.5 + PAPER_EPSILON

        objective = np.zeros(width)
        objective[selected] = 1
        objective[n] = -4
        margins[2, mask] = maximum(objective, a_ub, b_ub, bounds) - DELTA + PAPER_EPSILON

        objective = np.zeros(width)
        objective[selected] = 1
        objective[n] = -8
        margins[3, mask] = maximum(objective, a_ub, b_ub, bounds)
    return margins


def find_partition(margins: np.ndarray, tolerance: float = 1e-9) -> tuple[int, int, int, int] | None:
    """Find a fixed four-bin partition of every point in one conditional cell."""
    full = margins.shape[1] - 1
    for primary in range(full + 1):
        if margins[0, primary] > tolerance:
            continue
        remaining = full ^ primary
        second = remaining
        while True:
            if margins[1, second] <= tolerance:
                rest = remaining ^ second
                third = rest
                while True:
                    fourth = rest ^ third
                    if margins[2, third] <= tolerance and margins[3, fourth] <= tolerance:
                        return primary, second, third, fourth
                    if third == 0:
                        break
                    third = (third - 1) & rest
            if second == 0:
                break
            second = (second - 1) & remaining
    return None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", choices=CASES, default="mixed66")
    parser.add_argument("--segments", type=int, default=8)
    parser.add_argument("--n", type=int)
    parser.add_argument("--omega", type=float)
    parser.add_argument("--total-bound", type=float)
    parser.add_argument("--min-j", type=int, default=1)
    parser.add_argument("--max-j", type=int, default=8)
    args = parser.parse_args()

    n, total_bound, omega = CASES[args.case]
    if args.n is not None:
        n = args.n
    if args.omega is not None:
        omega = args.omega
    if args.total_bound is not None:
        total_bound = args.total_bound
    gamma_low = XI2 - PAPER_EPSILON
    gamma_high = 1 / 3 + 8 * omega + 7 * DELTA / 3 + 3 * PAPER_EPSILON
    failures = []
    certificates = 0
    active_conditions = 0
    weakest_margin = -np.inf
    weakest_witness = None

    for iw, ig in itertools.product(range(args.segments), repeat=2):
        w_bounds = (omega * iw / args.segments, omega * (iw + 1) / args.segments)
        g_bounds = (
            gamma_low + (gamma_high - gamma_low) * ig / args.segments,
            gamma_low + (gamma_high - gamma_low) * (ig + 1) / args.segments,
        )
        cell_ok = True
        for j in range(max(1, args.min_j), min(n, args.max_j) + 1):
            polytope = conditional_polytope(n, j, total_bound, w_bounds, g_bounds)
            if polytope is None:
                continue
            active_conditions += 1
            margins = load_margins(n, j, polytope)
            witness = find_partition(margins)
            if witness is None:
                cell_ok = False
                failures.append((iw, ig, j, w_bounds, g_bounds))
                break
            witness_margin = max(margins[bin_index, mask] for bin_index, mask in enumerate(witness))
            if witness_margin > weakest_margin:
                weakest_margin = witness_margin
                weakest_witness = (iw, ig, j, witness, witness_margin)
        if cell_ok:
            certificates += 1

    print(
        f"case={args.case} segments={args.segments} certified_cells={certificates} "
        f"failed_cells={args.segments**2-certificates} active_conditions={active_conditions}"
    )
    print("weakest_witness", weakest_witness)
    for failure in failures[:20]:
        print("FAIL", failure)


if __name__ == "__main__":
    main()
