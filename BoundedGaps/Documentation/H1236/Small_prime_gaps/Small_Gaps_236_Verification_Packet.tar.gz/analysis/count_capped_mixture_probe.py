#!/usr/bin/env python3
"""Mixture probe with Stadlmann-style count-dependent large-coordinate caps."""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.linalg import eigh
from scipy.signal import fftconvolve


Profile = tuple[float, float, float]


def primitive(v: np.ndarray, k: int, profile: Profile) -> np.ndarray:
    alpha, power, cutoff = profile
    v = np.minimum(np.maximum(v, 0.0), cutoff / k)
    if alpha == 0:
        return v
    if power == 1:
        return np.log1p(alpha * k * v) / (alpha * k)
    return ((1 + alpha * k * v) ** (1 - power) - 1) / (alpha * k * (1 - power))


def cross_entry(
    k: int,
    radius: float,
    delta: float,
    caps: list[float],
    left_profile: Profile,
    right_profile: Profile,
    dx: float,
) -> tuple[float, float]:
    scaled_delta = delta / radius
    scaled_caps = np.array(caps) / radius
    max_count = min(k, int(math.floor(scaled_caps[-1] / scaled_delta)))
    nr = int(math.floor(1 / dx)) + 1
    nb = int(math.floor(scaled_caps[-1] / dx)) + 1
    x = np.arange(nr) * dx
    a1, p1, t1 = left_profile
    a2, p2, t2 = right_profile
    left = np.where(k * x <= t1, (1 + a1 * k * x) ** (-p1), 0.0)
    right = np.where(k * x <= t2, (1 + a2 * k * x) ** (-p2), 0.0)
    raw = left * right * dx
    raw[0] *= 0.5
    z = float(raw.sum())
    p = raw / z
    cutoff_index = int(math.floor(scaled_delta / dx))
    small = p.copy()
    small[cutoff_index + 1 :] = 0
    big = p[:nb].copy()
    big[: cutoff_index + 1] = 0

    state = np.zeros((nr, nb, max_count + 1))
    state[0, 0, 0] = 1.0
    before_last = None
    r_grid = np.arange(nr)[:, None]
    b_grid = np.arange(nb)[None, :]
    total_ok = (r_grid + b_grid) * dx <= 1 + 1e-12
    for step in range(1, k + 1):
        small_part = fftconvolve(state, small[:, None, None], mode="full", axes=0)[:nr]
        big_part = fftconvolve(state, big[None, :, None], mode="full", axes=1)[:, :nb]
        new = small_part
        new[:, :, 1:] += big_part[:, :, :-1]
        new[new < 0] = 0
        new *= total_ok[:, :, None]
        for count in range(max_count + 1):
            cap = scaled_caps[min(count, len(scaled_caps) - 1)]
            new[:, :, count] *= b_grid * dx <= cap + 1e-12
        state = new
        if step == k - 1:
            before_last = state.copy()
    assert before_last is not None
    p_i = float(state.sum())

    total = (r_grid + b_grid) * dx
    remaining = np.maximum(0.0, 1.0 - total)
    e_j = 0.0
    for count in range(max_count + 1):
        outer = before_last[:, :, count]
        small_hi = np.minimum(remaining, scaled_delta)
        next_cap = scaled_caps[min(count + 1, len(scaled_caps) - 1)]
        large_hi = np.minimum(remaining, np.maximum(0.0, next_cap - b_grid * dx))

        def inner(profile: Profile) -> np.ndarray:
            h = primitive(small_hi, k, profile)
            h += np.where(
                large_hi > scaled_delta,
                primitive(large_hi, k, profile)
                - primitive(np.full_like(large_hi, scaled_delta), k, profile),
                0.0,
            )
            return h

        e_j += float(np.sum(outer * inner(left_profile) * inner(right_profile)))
    return math.exp(k * math.log(z)) * p_i, math.exp((k - 1) * math.log(z)) * e_j


def solve(k: int, radius: float, delta: float, caps: list[float], profiles: list[Profile], dx: float) -> None:
    n = len(profiles)
    imat = np.empty((n, n))
    jmat = np.empty((n, n))
    for row, left in enumerate(profiles):
        for col in range(row + 1):
            i_entry, j_entry = cross_entry(k, radius, delta, caps, left, profiles[col], dx)
            imat[row, col] = imat[col, row] = i_entry
            jmat[row, col] = jmat[col, row] = j_entry
        print(f"completed row {row + 1}/{n}", flush=True)
    scale = 1 / np.sqrt(np.diag(imat))
    si = scale[:, None] * imat * scale[None, :]
    sj = scale[:, None] * jmat * scale[None, :]
    vals, vecs = eigh(si)
    keep = vals > max(vals[-1] * 1e-10, 1e-12)
    whitening = vecs[:, keep] / np.sqrt(vals[keep])[None, :]
    reduced = whitening.T @ sj @ whitening
    reduced_values, reduced_vectors = eigh(reduced)
    unit_m = k * float(reduced_values[-1])
    scaled_vector = whitening @ reduced_vectors[:, -1]
    coefficients = scale * scaled_vector
    coefficients /= np.max(np.abs(coefficients))
    print(f"basis_size={n} effective_rank={int(keep.sum())}")
    print(f"unit_M={unit_m:.12f}")
    print(f"radius_times_M={radius * unit_m:.12f}")
    print(f"normalized_coefficients={coefficients}")
    print(f"I_correlation_eigenvalues={vals}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--k", type=int, default=48)
    parser.add_argument("--radius", type=float, default=0.2580238)
    parser.add_argument("--delta", type=float, default=0.014)
    parser.add_argument("--caps", default="0,0.15,0.15,0.174")
    parser.add_argument("--profiles", default="4:.5:48,6:.5:48,8:.5:48,3:.75:48,4.67:.75:48,6:.75:48,2.5:1:48,3.5:1:48,4.5:1:48,2:1.5:48,2.33:1.5:48,3:1.5:48,1.75:2:48")
    parser.add_argument("--dx", type=float, default=0.004)
    args = parser.parse_args()
    caps = [float(value) for value in args.caps.split(",")]
    profiles = [tuple(float(part) for part in value.split(":")) for value in args.profiles.split(",")]
    solve(args.k, args.radius, args.delta, caps, profiles, args.dx)


if __name__ == "__main__":
    main()
