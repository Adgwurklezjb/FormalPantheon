#!/usr/bin/env python3
"""Run lightweight consistency checks on the archived final candidate."""

from pathlib import Path
from fractions import Fraction
import json
import math
import re
import sys

import numpy as np
from flint import arb


sys.set_int_max_str_digits(20_000)


HERE = Path(__file__).resolve().parent


def primes_through(n: int):
    for candidate in range(2, n + 1):
        if all(candidate % p for p in range(2, math.isqrt(candidate) + 1)):
            yield candidate


def audit_exact_logs():
    paths = [HERE / "typeiic_exact_dual_N32.log"]
    paths += sorted(HERE.glob("exact*.log"))
    conditions = duals = 0
    for path in paths:
        text = path.read_text()
        totals = re.search(
            r"active_conditions\s+(\d+)\s+exact_duals\s+(\d+)", text
        )
        digest = re.search(r"sha256\s+([0-9a-f]{64})", text)
        assert totals and digest, f"incomplete exact replay: {path.name}"
        conditions += int(totals.group(1))
        duals += int(totals.group(2))
    assert len(paths) == 27
    assert (conditions, duals) == (11_359, 45_436)
    return len(paths), conditions, duals


def audit_matrix(path="final_support_dx001.npz", expected_dx=0.001):
    expected = {
        "k": 48,
        "dx": expected_dx,
        "delta": 0.014,
        "radius": 0.258,
        "split_radius": 0.253,
    }
    with np.load(HERE / path) as data:
        for key, value in expected.items():
            assert float(data[key]) == value, (key, data[key], value)
        for key in ("imat", "jmat"):
            matrix = data[key]
            assert matrix.shape == (3, 3)
            assert np.array_equal(matrix, matrix.T)
            assert np.all(np.linalg.eigvalsh(matrix) > 0)
        assert np.array_equal(
            data["lower_caps"], [0, .156, .156, .170, .184, .190, .202]
        )
        assert np.array_equal(
            data["upper_caps"], [0, .153, .153, .167, .181, .190, .190]
        )


def audit_qmc_log():
    text = (HERE / "qmc_final3_p21_r8.log").read_text()
    assert len(re.findall(r"^rep=", text, flags=re.MULTILINE)) == 8
    match = re.search(
        r"replicate_mean_q=([0-9.]+)\s+replicate_se_q=([0-9.eE+-]+)", text
    )
    assert match
    mean, se = map(float, match.groups())
    assert abs(mean - 1.001771092) < 5e-10
    assert abs(se - 3.025e-4) < 5e-8
    return mean, se


def audit_continuation():
    payload = json.loads((HERE / "exact_step_i_h00025.json").read_text())
    assert payload["schema"] == "small-gaps-exact-step-I-v1"
    assert payload["physical_step"] == [1, 4000]
    expected_pairs = {(row, col) for row in range(3) for col in range(row + 1)}
    records = payload["records"]
    assert {tuple(record["pair"]) for record in records} == expected_pairs
    matrix = [[Fraction(0) for _ in range(3)] for _ in range(3)]
    for record in records:
        row, col = record["pair"]
        value = Fraction(int(record["numerator"]), int(record["denominator"]))
        assert value > 0
        matrix[row][col] = matrix[col][row] = value
    vector = [Fraction(3, 5000), -Fraction(129, 1250), Fraction(1)]
    denominator = sum(
        vector[row] * matrix[row][col] * vector[col]
        for row in range(3) for col in range(3)
    )
    normalized = float(denominator / Fraction(129, 500) ** 48)
    assert abs(normalized / 1.6905473989443323e-110 - 1) < 1e-14

    with np.load(HERE / "step_profile_h00025_qmc.npz") as data:
        assert float(data["step"]) == .00025
        validation = data["validation_q"]
        assert len(validation) == 8 and np.all(validation > 1)
        step_mean = float(validation.mean())
    assert abs(step_mean - 1.0026674160975) < 1e-10

    text = (HERE / "qmc_linear15_p20_r8.log").read_text()
    assert len(re.findall(r"^rep=", text, flags=re.MULTILINE)) == 8
    match = re.search(
        r"replicate_mean_q=([0-9.]+)\s+replicate_se_q=([0-9.eE+-]+)", text
    )
    assert match
    linear_mean, linear_se = map(float, match.groups())
    assert abs(linear_mean - 1.001803565) < 5e-10
    assert abs(linear_se - 4.655e-4) < 5e-8
    candidate = json.loads((HERE / "two_piece_chebyshev_8_12.json").read_text())
    assert candidate["schema"] == "small-gaps-two-piece-chebyshev-v1"
    assert candidate["degrees"] == [8, 12]
    cheb_vector = [
        Fraction(int(numerator), int(denominator))
        for numerator, denominator in candidate["mixture_coefficients"]
    ]
    assert cheb_vector == [
        Fraction(571087, 10**9), -Fraction(12804621, 125000000), Fraction(1)
    ]
    cheb_i = json.loads((HERE / "exact_chebyshev_i_8_12.json").read_text())
    assert cheb_i["schema"] == "small-gaps-exact-chebyshev-I-v1"
    assert cheb_i["candidate_degrees"] == [8, 12]
    cheb_matrix = [[Fraction(0) for _ in range(3)] for _ in range(3)]
    assert {tuple(record["pair"]) for record in cheb_i["records"]} == expected_pairs
    for record in cheb_i["records"]:
        row, col = record["pair"]
        value = Fraction(int(record["numerator"]), int(record["denominator"]))
        cheb_matrix[row][col] = cheb_matrix[col][row] = value
    cheb_denominator = sum(
        cheb_vector[row] * cheb_matrix[row][col] * cheb_vector[col]
        for row in range(3) for col in range(3)
    )
    cheb_i_normalized = float(cheb_denominator / Fraction(129, 500) ** 48)
    assert abs(cheb_i_normalized / 1.9948522327259486e-110 - 1) < 1e-14

    cheb_text = (HERE / "qmc_chebyshev_8_12_p19_r8.log").read_text()
    assert len(re.findall(r"^validation rep=", cheb_text, flags=re.MULTILINE)) == 8
    cheb_match = re.search(
        r"validation_mean=([0-9.]+)\s+se=([0-9.eE+-]+)", cheb_text
    )
    assert cheb_match
    cheb_mean, cheb_se = map(float, cheb_match.groups())
    assert abs(cheb_mean - 1.000773843542) < 5e-12
    assert abs(cheb_se - 2.337e-4) < 5e-8
    high_text = (HERE / "qmc_chebyshev_8_12_p21_r4.log").read_text()
    assert len(re.findall(r"^validation rep=", high_text, flags=re.MULTILINE)) == 4
    high_match = re.search(
        r"validation_mean=([0-9.]+)\s+se=([0-9.eE+-]+)", high_text
    )
    assert high_match
    high_mean, high_se = map(float, high_match.groups())
    assert abs(high_mean - 1.001470208082) < 5e-12
    assert abs(high_se - 5.935e-4) < 5e-8

    certificate = json.loads((HERE / "chebyshev_8_12_certificate.json").read_text())
    assert certificate["schema"] == "small-gaps-chebyshev-variational-certificate-v1"
    assert certificate["status"] == "pass"
    assert Fraction(*certificate["minorant_loss_upper"]) == Fraction(
        1291475390625, 14389093733134384
    )
    assert arb(certificate["adjusted_quotient_ball"]).lower() > 1
    return (
        normalized, step_mean, linear_mean, linear_se,
        cheb_i_normalized, cheb_mean, cheb_se, high_mean, high_se,
    )


def audit_tuple():
    offsets = [
        0, 6, 8, 14, 18, 24, 26, 48, 50, 54, 56, 60, 66, 68, 74, 78,
        80, 84, 90, 96, 98, 104, 110, 116, 120, 126, 134, 138, 144, 150,
        158, 164, 168, 176, 180, 186, 188, 194, 200, 204, 206, 210, 216,
        224, 228, 230, 234, 236,
    ]
    assert len(offsets) == 48 and offsets[-1] - offsets[0] == 236
    for prime in primes_through(len(offsets)):
        assert len({offset % prime for offset in offsets}) < prime


if __name__ == "__main__":
    replay_count, conditions, duals = audit_exact_logs()
    audit_matrix()
    audit_matrix("final_support_dx00075.npz", 0.00075)
    qmc_mean, qmc_se = audit_qmc_log()
    (
        exact_i, step_mean, linear_mean, linear_se,
        cheb_i, cheb_mean, cheb_se, high_mean, high_se,
    ) = audit_continuation()
    audit_tuple()
    print(
        f"PASS: {replay_count} exact replays, {conditions:,} conditional polytopes, "
        f"{duals:,} rational inequalities"
    )
    print(f"PASS: final matrices at dx=.001 and .00075, QMC mean={qmc_mean:.9f} se={qmc_se:.4g}")
    print(
        f"PASS: six exact step-I entries, fixed I={exact_i:.12e}; "
        f"step validation={step_mean:.9f}"
    )
    print(f"PASS: linear-15 QMC mean={linear_mean:.9f} se={linear_se:.4g}")
    print(
        f"PASS: six exact Chebyshev-I entries, fixed I={cheb_i:.12e}; "
        f"QMC quotient={cheb_mean:.9f} se={cheb_se:.4g}"
    )
    print(
        f"PASS: six Arb-J entries and adjusted lower endpoint > 1; "
        f"high-sample QMC={high_mean:.9f} se={high_se:.4g}"
    )
    print("PASS: explicit 48-tuple is admissible and has diameter 236")
