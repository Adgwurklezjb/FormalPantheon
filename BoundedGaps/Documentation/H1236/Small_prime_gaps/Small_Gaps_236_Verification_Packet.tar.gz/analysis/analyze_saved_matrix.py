#!/usr/bin/env python3
"""Inspect generalized eigenvalues of a saved variational matrix pair."""

from __future__ import annotations

import argparse

import numpy as np
from scipy.linalg import eigh


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("matrix_file")
    args = parser.parse_args()
    data = np.load(args.matrix_file)
    imat = data["imat"]
    jmat = data["jmat"]
    radius = float(data["radius"])
    k = int(data["k"])
    scale = 1 / np.sqrt(np.diag(imat))
    si = scale[:, None] * imat * scale[None, :]
    sj = scale[:, None] * jmat * scale[None, :]
    vals, vecs = eigh(si)
    print(f"I eigenvalue range: {vals[0]:.6e} .. {vals[-1]:.6e}")
    for threshold in [0, 1e-8, 1e-7, 3e-7, 1e-6, 3e-6, 1e-5, 3e-5, 1e-4, 3e-4, 1e-3]:
        keep = vals > threshold
        whitening = vecs[:, keep] / np.sqrt(vals[keep])[None, :]
        quotient = radius * k * float(eigh(whitening.T @ sj @ whitening, eigvals_only=True)[-1])
        print(f"threshold={threshold:.1e} rank={int(keep.sum()):2d} quotient={quotient:.12f}")


if __name__ == "__main__":
    main()
