#!/usr/bin/env python3
"""Exact rational I entries for a frozen two-piece polynomial witness.

Each one-coordinate product is polynomial on [0,delta] and [delta,L].  Its
Laplace transform is a bivariate polynomial in s^{-1} and exp(-delta*s).
After taking the 48th product, the cap constraint is evaluated by composing a
small-group CDF polynomial with H-x and integrating it against the large-group
density polynomial.  All accepted arithmetic is FLINT fmpq exact.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
from functools import cache
import json
from math import comb, factorial
from pathlib import Path

from flint import fmpq, fmpq_poly


K = 48
DELTA = Fraction(14, 1000)
SPLIT = Fraction(253, 1000)
RADIUS = Fraction(258, 1000)
LOWER = tuple(map(Fraction, ("0", ".156", ".156", ".170", ".184", ".190", ".202")))
UPPER = tuple(map(Fraction, ("0", ".153", ".153", ".167", ".181", ".190", ".190")))


def fq(value) -> fmpq:
    if isinstance(value, fmpq):
        return value
    if isinstance(value, Fraction):
        return fmpq(value.numerator, value.denominator)
    if isinstance(value, (list, tuple)) and len(value) == 2:
        return fmpq(int(value[0]), int(value[1]))
    value = Fraction(str(value))
    return fmpq(value.numerator, value.denominator)


def multiply_power(left, right):
    answer = [fmpq(0)] * (len(left) + len(right) - 1)
    for i, a in enumerate(left):
        if not a:
            continue
        for j, b in enumerate(right):
            if b:
                answer[i + j] += a * b
    return answer


def shift_power(poly, offset: Fraction):
    """Return coefficients of p(offset+y) in powers of y."""
    answer = [fmpq(0)] * len(poly)
    offset_q = fq(offset)
    for exponent, coefficient in enumerate(poly):
        if not coefficient:
            continue
        for power in range(exponent + 1):
            answer[power] += coefficient * comb(exponent, power) * offset_q ** (exponent - power)
    return answer


def small_laplace(poly):
    """Two numerator polynomials: unshifted and exp(-delta*s)-shifted."""
    maximum = len(poly)
    unshifted = [fmpq(0)] * (maximum + 1)
    shifted = [fmpq(0)] * (maximum + 1)
    delta_q = fq(DELTA)
    for exponent, coefficient in enumerate(poly):
        if not coefficient:
            continue
        leading = coefficient * factorial(exponent)
        unshifted[exponent + 1] += leading
        for q in range(exponent + 1):
            shifted[exponent - q + 1] -= leading * delta_q**q / factorial(q)
    return fmpq_poly(unshifted), fmpq_poly(shifted)


def large_laplace(poly):
    shifted = shift_power(poly, DELTA)
    coefficients = [fmpq(0)] * (len(shifted) + 1)
    for exponent, coefficient in enumerate(shifted):
        coefficients[exponent + 1] = coefficient * factorial(exponent)
    return fmpq_poly(coefficients)


def bivariate_multiply(left, right, max_shift):
    answer = [fmpq_poly()] * (max_shift + 1)
    for i, a in enumerate(left):
        if not a:
            continue
        for j, b in enumerate(right[: max_shift + 1 - i]):
            if b:
                answer[i + j] = answer[i + j] + a * b
    return answer


def bivariate_power(base, exponent, max_shift):
    answer = [fmpq_poly([1])] + [fmpq_poly()] * max_shift
    active = list(base) + [fmpq_poly()] * (max_shift + 1 - len(base))
    while exponent:
        if exponent & 1:
            answer = bivariate_multiply(answer, active, max_shift)
        exponent //= 2
        if exponent:
            active = bivariate_multiply(active, active, max_shift)
    return answer


@cache
def factorial_q(n):
    return fq(factorial(n))


def small_cdf_polynomial(laplace_poly):
    """If L(s)=sum a_p/s^p, return A(y)=sum a_p*y^p/p!."""
    coefficients = [fmpq(0)] * max(1, len(laplace_poly))
    for power, coefficient in enumerate(laplace_poly.coeffs()):
        if coefficient:
            coefficients[power] = coefficient / factorial_q(power)
    return fmpq_poly(coefficients)


def large_density_polynomial(laplace_poly):
    """If L(s)=sum a_q/s^q, return D(x)=sum a_q*x^(q-1)/(q-1)! ."""
    coefficients = [fmpq(0)] * max(1, len(laplace_poly) - 1)
    for power, coefficient in enumerate(laplace_poly.coeffs()):
        if power and coefficient:
            coefficients[power - 1] = coefficient / factorial_q(power - 1)
    return fmpq_poly(coefficients)


def small_density_polynomial(laplace_poly):
    """If L(s)=sum a_p/s^p, return D(z)=sum a_p*z^(p-1)/(p-1)! ."""
    coefficients = [fmpq(0)] * max(1, len(laplace_poly) - 1)
    for power, coefficient in enumerate(laplace_poly.coeffs()):
        if power and coefficient:
            coefficients[power - 1] = coefficient / factorial_q(power - 1)
    return fmpq_poly(coefficients)


def capped_convolution(small_laplace_poly, large_density, height, cap, large_count):
    if height <= 0 or cap < 0:
        return fmpq(0)
    cdf = small_cdf_polynomial(small_laplace_poly)
    height_q = fq(height)
    if large_count == 0:
        return cdf(height_q)
    maximum = min(height, cap)
    if maximum <= 0:
        return fmpq(0)
    integrand = cdf(fmpq_poly([height_q, -1])) * large_density
    return integrand.integral()(fq(maximum))


def cap(table, count):
    return table[min(count, len(table) - 1)]


def load_profiles(path: Path):
    payload = json.loads(path.read_text())
    if payload.get("schema") != "small-gaps-two-piece-chebyshev-v1":
        raise ValueError("unsupported candidate schema")
    profiles = []
    for record in payload["profiles"]:
        small, large = record["pieces"]
        profiles.append((
            [fq(value) for value in small["physical_power_coefficients"]],
            [fq(value) for value in large["physical_power_coefficients"]],
        ))
    return payload, profiles


def exact_entry(profiles, left_index, right_index):
    small_poly = multiply_power(profiles[left_index][0], profiles[right_index][0])
    large_poly = multiply_power(profiles[left_index][1], profiles[right_index][1])
    small_base = small_laplace(small_poly)
    large_base = large_laplace(large_poly)
    maximum_count = int(max(LOWER[-1], UPPER[-1]) / DELTA)
    result = fmpq(0)
    for count in range(maximum_count + 1):
        lower_cap = cap(LOWER, count)
        upper_cap = cap(UPPER, count)
        if count and count * DELTA >= max(lower_cap, upper_cap):
            continue
        max_shift = int((RADIUS - count * DELTA) / DELTA)
        small_terms = bivariate_power(small_base, K - count, max_shift)
        large_laplace_power = large_base**count
        large_density = (
            fmpq_poly([1]) if count == 0
            else large_density_polynomial(large_laplace_power)
        )
        subtotal = fmpq(0)
        for shifted_count, small_term in enumerate(small_terms):
            if not small_term:
                continue
            total_offset = (count + shifted_count) * DELTA
            large_offset = count * DELTA
            subtotal += capped_convolution(
                small_term, large_density,
                SPLIT - total_offset, lower_cap - large_offset, count,
            )
            subtotal += capped_convolution(
                small_term, large_density,
                RADIUS - total_offset, upper_cap - large_offset, count,
            )
            subtotal -= capped_convolution(
                small_term, large_density,
                SPLIT - total_offset, upper_cap - large_offset, count,
            )
        result += comb(K, count) * subtotal
        print(
            f"pair={left_index},{right_index} count={count} "
            f"small_terms={sum(bool(p) for p in small_terms)} "
            f"small_degree={max((p.degree() for p in small_terms if p), default=-1)} "
            f"large_degree={large_laplace_power.degree()}",
            flush=True,
        )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate", type=Path)
    parser.add_argument("--pair", default="2,2")
    parser.add_argument("--all", action="store_true")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    payload, profiles = load_profiles(args.candidate)
    pairs = (
        [(row, col) for row in range(3) for col in range(row + 1)]
        if args.all else [tuple(map(int, args.pair.split(",")))]
    )
    records = []
    for left, right in pairs:
        value = exact_entry(profiles, left, right)
        normalized = float(value / fq(RADIUS) ** K)
        print(f"RESULT pair={left},{right} u_scaled={normalized:.16e}", flush=True)
        records.append({
            "pair": [left, right],
            "numerator": str(value.numerator),
            "denominator": str(value.denominator),
            "u_scaled_float": normalized,
        })
    if args.output:
        answer = {
            "schema": "small-gaps-exact-chebyshev-I-v1",
            "candidate_schema": payload["schema"],
            "candidate_degrees": payload["degrees"],
            "records": records,
        }
        args.output.write_text(json.dumps(answer, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
