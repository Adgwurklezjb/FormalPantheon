#!/usr/bin/env python3
"""Generalized eigenvalue probe for mixtures of capped product profiles.

The trial space is spanned by
    F_a(x_1,...,x_k) = 1_T prod_i (1 + a k x_i)^(-1),
where T imposes both the simplex and the large-coordinate cap.  Every matrix
entry reduces to the same two-dimensional convolution as in
capped_product_probe.py.
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.linalg import eigh
from scipy.signal import fftconvolve


def primitive(v: np.ndarray, k: int, profile: tuple[float, float, float]) -> np.ndarray:
    alpha, power, cutoff = profile
    v = np.minimum(np.maximum(v, 0.0), cutoff / k)
    if alpha == 0:
        return v
    if power == 1:
        return np.log1p(alpha * k * v) / (alpha * k)
    return ((1.0 + alpha * k * v) ** (1.0 - power) - 1.0) / (alpha * k * (1.0 - power))


def cross_entry(
    k: int,
    scaled_delta: float,
    scaled_cap: float,
    profile_left: tuple[float, float, float],
    profile_right: tuple[float, float, float],
    dx: float,
) -> tuple[float, float]:
    nt = int(math.floor(1.0 / dx)) + 1
    nb = int(math.floor(scaled_cap / dx)) + 1
    x = np.arange(nt) * dx
    alpha_left, power_left, cutoff_left = profile_left
    alpha_right, power_right, cutoff_right = profile_right
    left = np.where(k * x <= cutoff_left, (1.0 + alpha_left * k * x) ** (-power_left), 0.0)
    right = np.where(k * x <= cutoff_right, (1.0 + alpha_right * k * x) ** (-power_right), 0.0)
    raw = left * right * dx
    raw[0] *= 0.5
    z = float(raw.sum())
    p = raw / z

    kernel = np.zeros((nt, nb))
    for idx, probability in enumerate(p):
        if x[idx] > scaled_delta:
            if idx < nb:
                kernel[idx, idx] += probability
        else:
            kernel[idx, 0] += probability

    state = np.zeros((1, 1))
    state[0, 0] = 1.0
    before_last = None
    for step in range(1, k + 1):
        state = fftconvolve(state, kernel)[:nt, :nb]
        state[state < 0] = 0.0
        if step == k - 1:
            before_last = state.copy()
    assert before_last is not None

    p_i = float(state.sum())
    total = np.arange(before_last.shape[0])[:, None] * dx
    big = np.arange(before_last.shape[1])[None, :] * dx
    max_coordinate = np.maximum(0.0, 1.0 - total)
    small_hi = np.minimum(max_coordinate, scaled_delta)
    large_hi = np.minimum(max_coordinate, np.maximum(0.0, scaled_cap - big))

    def inner(profile: tuple[float, float, float]) -> np.ndarray:
        h = np.broadcast_to(primitive(small_hi, k, profile), before_last.shape).copy()
        h += np.where(
            large_hi > scaled_delta,
            primitive(large_hi, k, profile)
            - primitive(np.full_like(large_hi, scaled_delta), k, profile),
            0.0,
        )
        return h

    e_j = float(np.sum(before_last * inner(profile_left) * inner(profile_right)))
    return math.exp(k * math.log(z)) * p_i, math.exp((k - 1) * math.log(z)) * e_j


def solve(
    k: int,
    radius: float,
    delta: float,
    cap: float,
    profiles: list[tuple[float, float, float]],
    dx: float,
) -> None:
    n = len(profiles)
    imat = np.empty((n, n))
    jmat = np.empty((n, n))
    for row, profile_left in enumerate(profiles):
        for col in range(row + 1):
            profile_right = profiles[col]
            i_entry, j_entry = cross_entry(
                k,
                delta / radius,
                cap / radius,
                profile_left,
                profile_right,
                dx,
            )
            imat[row, col] = imat[col, row] = i_entry
            jmat[row, col] = jmat[col, row] = j_entry
        print(f"completed row {row + 1}/{n}", flush=True)

    scale = 1.0 / np.sqrt(np.diag(imat))
    si = scale[:, None] * imat * scale[None, :]
    sj = scale[:, None] * jmat * scale[None, :]
    evals_i, evecs_i = eigh(si)
    cutoff = max(evals_i[-1] * 1e-11, 1e-13)
    keep = evals_i > cutoff
    whitening = evecs_i[:, keep] / np.sqrt(evals_i[keep])[None, :]
    reduced = whitening.T @ sj @ whitening
    reduced_values, reduced_vectors = eigh(reduced)
    unit_m = k * float(reduced_values[-1])
    scaled_vector = whitening @ reduced_vectors[:, -1]
    coefficients = scale * scaled_vector
    coefficients /= np.max(np.abs(coefficients))
    print(f"basis_size={n} effective_rank={int(keep.sum())}")
    print(f"unit_M={unit_m:.12f}")
    print(f"radius_times_M={radius * unit_m:.12f}")
    print(f"normalized_coefficients={coefficients}")
    print(f"I_correlation_eigenvalues={evals_i}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--k", type=int, default=48)
    parser.add_argument("--radius", type=float, default=0.2567)
    parser.add_argument("--delta", type=float, default=0.018)
    parser.add_argument("--cap", type=float, default=0.17)
    parser.add_argument(
        "--profiles",
        default="1.5:1:48,2:1:48,2.5:1:48,3:1:48,3.5:1:48,4:1:48,4.5:1:48,5:1:48,6:1:48",
        help="comma-separated alpha:power:cutoff triples in the scaled variable u=kx",
    )
    parser.add_argument("--dx", type=float, default=0.002)
    args = parser.parse_args()
    profiles = [tuple(float(part) for part in value.split(":")) for value in args.profiles.split(",")]
    solve(args.k, args.radius, args.delta, args.cap, profiles, args.dx)


if __name__ == "__main__":
    main()
