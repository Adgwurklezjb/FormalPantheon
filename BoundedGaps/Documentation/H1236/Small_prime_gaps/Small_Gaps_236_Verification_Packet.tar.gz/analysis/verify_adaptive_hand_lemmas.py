#!/usr/bin/env python3
"""Exact-rational margin checks for the adaptive Type-IIc hand lemmas."""

from fractions import Fraction as Q


D = Q(14, 1000)
E = Q(1, 10**10)
XI2 = Q(4021, 10000)


def bounds(total: Q, omega: Q) -> tuple[Q, Q]:
    c1_min = XI2 - 2 * D - 8 * omega - 2 * E
    r_max = total - c1_min
    c2_base = Q(1, 2) - 2 * D - 10 * omega - 2 * E - total
    return r_max, c2_base


def omega_for_deficit(total: Q, deficit: Q) -> Q:
    """Smallest omega allowed by r>deficit, ignoring the strict endpoint."""
    return (deficit - total + XI2 - 2 * D - 2 * E) / 8


def upper_lemmas() -> None:
    omega = Q(8, 1000)
    first = Q(153, 1000)
    for count, block in ((3, Q(167, 1000)), (4, Q(181, 1000)), (5, Q(195, 1000))):
        total = first + block
        r_max, c2_base = bounds(total, omega)
        assert r_max < (count - 2) * D
        assert block / count < c2_base
        if count >= 4:
            b2 = (block - D) / (count - 1)
            assert b2 < c2_base + D
        if count == 4:
            w_min = omega_for_deficit(total, D)
            assert r_max < D + 4 * w_min - E
        if count == 5:
            w_min_one = omega_for_deficit(total, D)
            assert r_max < 8 * w_min_one
            b3 = (block - 2 * D) / 3
            assert b3 < c2_base + 2 * D
            w_min_two = omega_for_deficit(total, 2 * D)
            assert r_max - D < D + 4 * w_min_two - E
            assert r_max - D < 8 * w_min_two
        print("upper", count, "r_max", r_max, "c2_base", c2_base)


def mixed_lemmas() -> None:
    omega = Q(55, 10000)
    total = Q(351, 1000)
    r_max, c2_base = bounds(total, omega)
    assert r_max < 2 * D
    assert Q(181, 1000) / 4 < c2_base
    assert Q(167, 1000) / 3 < c2_base
    assert (Q(181, 1000) - D) / 3 < c2_base + D
    assert (Q(167, 1000) - D) / 2 < c2_base + D
    w_min = omega_for_deficit(total, D)
    assert r_max < D + 4 * w_min - E
    print("mixed34 r_max", r_max, "c2_base", c2_base)


if __name__ == "__main__":
    upper_lemmas()
    mixed_lemmas()
    print("all exact margin checks passed")
