#!/usr/bin/env python3
"""Replay the finite two-piece Chebyshev variational certificate.

I is read as six exact rationals.  J is read as six rigorous 1024-bit Arb
balls.  The script contracts both matrices against the frozen rational vector
and checks the minorant-adjusted inequality using the lower endpoint only.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys

from flint import arb, ctx, fmpq


RADIUS = Fraction(129, 500)
K = 48
XI2 = Fraction(4021, 10_000)
BETA = 1 - 2 * XI2
ONE_COORDINATE_CAP_MAX = Fraction(156, 1000)
# Rigorous rectangular majorants for Stadlmann's exceptional regions A and B.
# Every Buchstab integration variable is at least BETA, so the five reciprocal
# factors contribute at most BETA^-5.  The four interval-width bounds are read
# directly from the displayed inequalities defining A and B.
LOSS_A_UPPER = (5 * XI2 - 2) * (Fraction(5, 2) * XI2 - 1) ** 3 / BETA**5
LOSS_B_UPPER = (
    (10 * XI2 - 4) ** 2
    * (Fraction(5, 2) * XI2 - 1)
    * (5 * XI2 - 2)
    / BETA**5
)
MINORANT_UPPER = LOSS_A_UPPER + LOSS_B_UPPER
PAIRS = ("00", "10", "11", "20", "21", "33")


def aq(value):
    value = Fraction(value)
    return arb(fmpq(value.numerator, value.denominator))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--directory", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    sys.set_int_max_str_digits(20_000)
    ctx.prec = 1024
    assert BETA > ONE_COORDINATE_CAP_MAX
    root = args.directory

    candidate_path = root / "two_piece_chebyshev_8_12.json"
    exact_i_path = root / "exact_chebyshev_i_8_12.json"
    candidate = json.loads(candidate_path.read_text())
    exact_i = json.loads(exact_i_path.read_text())
    assert candidate["schema"] == "small-gaps-two-piece-chebyshev-v1"
    assert candidate["degrees"] == [8, 12]
    assert exact_i["schema"] == "small-gaps-exact-chebyshev-I-v1"
    assert exact_i["candidate_degrees"] == [8, 12]

    vector = [
        aq(Fraction(int(numerator), int(denominator)))
        for numerator, denominator in candidate["mixture_coefficients"]
    ]
    imat = [[arb(0) for _ in range(3)] for _ in range(3)]
    for record in exact_i["records"]:
        row, col = record["pair"]
        physical = Fraction(int(record["numerator"]), int(record["denominator"]))
        value = aq(physical) / aq(RADIUS) ** K
        imat[row][col] = imat[col][row] = value

    jmat = [[arb(0) for _ in range(3)] for _ in range(3)]
    j_paths = []
    for pair in PAIRS:
        path = root / f"arb_chebyshev_j{pair}_8_12.json"
        payload = json.loads(path.read_text())
        assert payload["schema"] == "small-gaps-exact-chebyshev-J-v1"
        assert payload["candidate_degrees"] == [8, 12]
        assert payload["backend"] == "arb" and payload["arb_bits"] == 1024
        record = payload["record"]
        row, col = record["pair"]
        value = arb(record["u_scaled_ball"])
        jmat[row][col] = jmat[col][row] = value
        j_paths.append(path)

    iquad = sum(
        (vector[row] * imat[row][col] * vector[col]
         for row in range(3) for col in range(3)),
        arb(0),
    )
    jquad = sum(
        (vector[row] * jmat[row][col] * vector[col]
         for row in range(3) for col in range(3)),
        arb(0),
    )
    raw = aq(RADIUS) * K * jquad / iquad
    adjusted = raw * (1 - aq(MINORANT_UPPER))
    if not adjusted.lower() > 1:
        raise ArithmeticError(f"certificate does not cross: {adjusted}")

    print(f"I={iquad}")
    print(f"J={jquad}")
    print(f"raw_quotient={raw}")
    print(f"minorant_upper={MINORANT_UPPER}")
    print(f"loss_A_upper={LOSS_A_UPPER}")
    print(f"loss_B_upper={LOSS_B_UPPER}")
    print(f"beta_minus_max_Bj1={BETA - ONE_COORDINATE_CAP_MAX}")
    print("K_limit=0 (strict common-sum region is empty at epsilon=0)")
    print(f"adjusted_quotient={adjusted}")
    print(f"adjusted_lower={adjusted.lower()}")
    print("PASS: rigorous lower endpoint exceeds one")

    if args.output:
        payload = {
            "schema": "small-gaps-chebyshev-variational-certificate-v1",
            "status": "pass",
            "k": K,
            "degrees": candidate["degrees"],
            "physical_radius": [RADIUS.numerator, RADIUS.denominator],
            "minorant_loss_upper": [
                MINORANT_UPPER.numerator, MINORANT_UPPER.denominator
            ],
            "xi2": [XI2.numerator, XI2.denominator],
            "beta": [BETA.numerator, BETA.denominator],
            "max_Bj1": [
                ONE_COORDINATE_CAP_MAX.numerator,
                ONE_COORDINATE_CAP_MAX.denominator,
            ],
            "K_limit": [0, 1],
            "loss_A_upper": [LOSS_A_UPPER.numerator, LOSS_A_UPPER.denominator],
            "loss_B_upper": [LOSS_B_UPPER.numerator, LOSS_B_UPPER.denominator],
            "I_ball": str(iquad),
            "J_ball": str(jquad),
            "raw_quotient_ball": str(raw),
            "adjusted_quotient_ball": str(adjusted),
            "adjusted_lower": str(adjusted.lower()),
            "input_sha256": {
                candidate_path.name: digest(candidate_path),
                exact_i_path.name: digest(exact_i_path),
                **{path.name: digest(path) for path in j_paths},
            },
        }
        args.output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
