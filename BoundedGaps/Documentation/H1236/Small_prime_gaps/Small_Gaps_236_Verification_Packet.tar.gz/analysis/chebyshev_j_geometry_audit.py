#!/usr/bin/env python3
"""Count the exact rational cells in the two-piece polynomial J contraction.

This is a complexity gate, not an integral evaluator.  It enumerates every
common-coordinate status and every cross-band/small-large marginal pair using
the same rational line arrangement that an exact J proof must integrate.
"""

from __future__ import annotations

from collections import Counter
from fractions import Fraction
import importlib.util
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
VERIFIER = (
    HERE.parent / "tmp/primegaps_exact/reproduction/240/independent-reproducer/"
    "exact_symmetric_verifier.py"
)
sys.path.insert(0, str(HERE.parent / "tmp/primegaps_exact/src"))
spec = importlib.util.spec_from_file_location("exact_verifier", VERIFIER)
verifier = importlib.util.module_from_spec(spec)
assert spec.loader is not None
sys.modules[spec.name] = verifier
spec.loader.exec_module(verifier)


N = 47
DELTA = Fraction(14, 1000)
SPLIT = Fraction(253, 1000)
RADIUS = Fraction(258, 1000)
LOWER = tuple(map(Fraction, ("0", ".156", ".156", ".170", ".184", ".190", ".202")))
UPPER = tuple(map(Fraction, ("0", ".153", ".153", ".167", ".181", ".190", ".190")))
BANDS = ((Fraction(0), SPLIT, LOWER), (SPLIT, RADIUS, UPPER))


def cap(table, count):
    return table[min(count, len(table) - 1)]


def marginal_specs(count):
    answer = []
    for band_index, (lower, upper, caps) in enumerate(BANDS):
        for large in (False, True):
            status_count = count + int(large)
            support_limit = cap(caps, status_count)
            answer.append((
                band_index,
                large,
                verifier.RadialSlice(
                    power=0,
                    slack=0,
                    large=large,
                    lower=lower,
                    upper=upper,
                    support_limit=support_limit,
                ),
            ))
    return answer


def main():
    verifier.R = RADIUS
    verifier.DELTA = DELTA
    counts = Counter()
    maximum = (0, None)
    nonempty_statuses = 0
    global_cells = 0
    global_maximum = (0, None)
    for large_count in range(int(max(LOWER[-1], UPPER[-1]) / DELTA) + 1):
        maximum_shift = int((RADIUS - large_count * DELTA) / DELTA)
        specs = marginal_specs(large_count)
        for shifted_count in range(maximum_shift + 1):
            total_offset = (large_count + shifted_count) * DELTA
            large_offset = large_count * DELTA
            global_kind, global_partition = verifier._slice_geometry(
                large_count > 0,
                N - large_count > 0,
                total_offset,
                large_offset,
                tuple(item[2] for item in specs),
            )
            global_number = (
                0 if global_kind == "empty"
                else (1 if global_kind == "point" else len(global_partition))
            )
            global_cells += global_number
            if global_number > global_maximum[0]:
                global_maximum = (
                    global_number,
                    (large_count, shifted_count, global_kind),
                )
            status_cells = 0
            for left_band, left_large, left in specs:
                for right_band, right_large, right in specs:
                    kind, cells = verifier._slice_geometry(
                        large_count > 0,
                        N - large_count > 0,
                        total_offset,
                        large_offset,
                        (left, right),
                    )
                    number = 0 if kind == "empty" else (1 if kind == "point" else len(cells))
                    if number:
                        counts[(kind, left_band, left_large, right_band, right_large)] += number
                        status_cells += number
                        if number > maximum[0]:
                            maximum = (
                                number,
                                (large_count, shifted_count, left_band, left_large,
                                 right_band, right_large, kind),
                            )
            if status_cells:
                nonempty_statuses += 1
                print(
                    f"large={large_count} shifted={shifted_count} "
                    f"pairwise_cells={status_cells} global_cells={global_number}",
                    flush=True,
                )
    print(f"nonempty_statuses={nonempty_statuses}")
    print(f"total_cells={sum(counts.values())}")
    print(f"maximum_one_spec_pair={maximum}")
    print(f"total_global_cells={global_cells}")
    print(f"maximum_global_partition={global_maximum}")
    for key, value in sorted(counts.items()):
        print(f"class={key} cells={value}")


if __name__ == "__main__":
    main()
