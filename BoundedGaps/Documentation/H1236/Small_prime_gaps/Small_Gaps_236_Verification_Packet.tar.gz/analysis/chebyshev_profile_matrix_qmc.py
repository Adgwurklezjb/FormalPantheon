#!/usr/bin/env python3
"""QMC matrix search/validation for two-piece Chebyshev product profiles."""

from __future__ import annotations

import argparse
import importlib.util
import math
from pathlib import Path

import numpy as np
from numpy.polynomial import Chebyshev
from scipy import linalg
from scipy.special import logsumexp
from scipy.stats import qmc


HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("mix", HERE / "mixture_qmc_validation.py")
mix = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(mix)


def configure(degrees):
    small_degree, large_degree = degrees
    mix.LOWER[5] = .190 / mix.RADIUS
    mix.LOWER[6:] = .202 / mix.RADIUS
    mix.UPPER[5:] = .190 / mix.RADIUS
    mix.CHEB_MAX = .202 / mix.RADIUS
    mix.CHEB_POLYS = []
    mix.CHEB_PRIMS = []
    for alpha, power in mix.PROFILES:
        function = lambda x, a=alpha, p=power: (1 + a * mix.K * x) ** (-p)
        small = Chebyshev.interpolate(function, small_degree, domain=[0., mix.DELTA])
        large = Chebyshev.interpolate(
            function, large_degree, domain=[mix.DELTA, mix.CHEB_MAX]
        )
        small_i, large_i = small.integ(), large.integ()
        mix.CHEB_POLYS.append((small, large))
        mix.CHEB_PRIMS.append((
            small_i, large_i, small_i(mix.DELTA) - small_i(0.)
        ))


def sample(dimension, power, seed):
    sampler = qmc.Sobol(d=dimension + 1, scramble=True, seed=seed)
    uniforms = sampler.random_base2(power)
    component = np.minimum((uniforms[:, 0] * 3).astype(int), 2)
    points = np.empty((len(uniforms), dimension))
    for index, (alpha, profile_power) in enumerate(mix.PROFILES):
        selected = component == index
        points[selected] = mix.inverse_squared_cdf(
            uniforms[selected, 1:], alpha, profile_power
        )
    logs = mix.log_profiles(points)
    norms = np.array([mix.normalizer(a, p) for a, p in mix.PROFILES])
    log_density = logsumexp(
        -math.log(3) + 2 * logs - dimension * np.log(norms), axis=1
    )
    return points, log_density


def one_matrix(power, seed):
    x, log_i = sample(mix.K, power, 1000 + seed)
    u, log_j = sample(mix.K - 1, power, 2000 + seed)
    fi = mix.cheb_profile_products(x)
    fi *= mix.support_mask(x)[:, None]
    hi = mix.cheb_profile_products(u) * mix.last_integrals(u)
    wi, wj = np.exp(-log_i), np.exp(-log_j)
    return (
        fi.T @ (fi * wi[:, None]) / len(x),
        hi.T @ (hi * wj[:, None]) / len(u),
    )


def solve(imat, jmat):
    scale = 1 / np.sqrt(np.diag(imat))
    si = scale[:, None] * imat * scale[None, :]
    sj = scale[:, None] * jmat * scale[None, :]
    vals, vecs = linalg.eigh(si)
    white = vecs / np.sqrt(vals)[None, :]
    qvals, qvecs = linalg.eigh(white.T @ sj @ white)
    vector = scale * (white @ qvecs[:, -1])
    vector /= np.max(np.abs(vector))
    return mix.RADIUS * mix.K * qvals[-1], vector, vals


def evaluate(vector, imat, jmat):
    return mix.RADIUS * mix.K * (vector @ jmat @ vector) / (vector @ imat @ vector)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--degrees", default="8,12")
    parser.add_argument("--power", type=int, default=18)
    parser.add_argument("--replicates", type=int, default=4)
    parser.add_argument("--seed", type=int, default=2200)
    parser.add_argument("--validation-seed", type=int, default=2400)
    parser.add_argument(
        "--fixed-vector",
        help="comma-separated vector; skip discovery and only validate it",
    )
    parser.add_argument("--save")
    args = parser.parse_args()
    degrees = tuple(map(int, args.degrees.split(",")))
    configure(degrees)
    if args.fixed_vector:
        vector = np.asarray([float(value) for value in args.fixed_vector.split(",")])
        if vector.shape != (3,):
            raise ValueError("fixed vector must have three entries")
        imat = jmat = None
        quotient = float("nan")
        print(f"degrees={degrees} fixed_vector={vector}")
    else:
        discovery = [
            one_matrix(args.power, args.seed + i) for i in range(args.replicates)
        ]
        imat = np.mean([pair[0] for pair in discovery], axis=0)
        jmat = np.mean([pair[1] for pair in discovery], axis=0)
        quotient, vector, eigs = solve(imat, jmat)
        print(f"degrees={degrees} discovery_q={quotient:.12f}")
        print(f"vector={vector}")
        print(f"I_correlation_eigenvalues={eigs}")
    validation = []
    for i in range(args.replicates):
        vi, vj = one_matrix(args.power, args.validation_seed + i)
        value = evaluate(vector, vi, vj)
        validation.append(value)
        print(f"validation rep={i} q={value:.12f}", flush=True)
    array = np.asarray(validation)
    print(
        f"validation_mean={array.mean():.12f} "
        f"se={array.std(ddof=1)/np.sqrt(len(array)):.3e}"
    )
    if args.save:
        payload = dict(
            degrees=degrees, vector=vector, discovery_q=quotient,
            validation_q=array,
        )
        if imat is not None:
            payload.update(imat=imat, jmat=jmat)
        np.savez(args.save, **payload)


if __name__ == "__main__":
    main()
