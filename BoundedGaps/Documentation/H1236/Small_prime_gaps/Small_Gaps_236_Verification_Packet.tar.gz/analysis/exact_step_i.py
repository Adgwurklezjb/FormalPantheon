#!/usr/bin/env python3
"""Exact rational I matrix for the h=1/4000 step-profile witness.

For a piecewise-constant one-coordinate weight g, write its Laplace transform
as P(exp(-h*s))/s.  Powers of P give the exact truncated-power density of the
coordinate sum.  The remaining two-group simplex integral is evaluated by an
integer incomplete-beta polynomial.  All accepted arithmetic is fmpq exact.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
import json
from math import comb, factorial
from pathlib import Path

import numpy as np
from flint import fmpq, fmpq_poly


K = 48
H = Fraction(1, 4000)
RADIUS = Fraction(258, 1000)
DELTA = Fraction(14, 1000)
SPLIT = Fraction(253, 1000)
LOWER = [0, .156, .156, .170, .184, .190, .202]
UPPER = [0, .153, .153, .167, .181, .190, .190]
PROFILES = [(4.5, .8), (3.5, 1.), (2.8, 1.25)]


def fq(value):
    if isinstance(value, Fraction):
        return fmpq(value.numerator, value.denominator)
    value = Fraction(str(value))
    return fmpq(value.numerator, value.denominator)


def rational_heights(profile):
    count = int(RADIUS / H)
    alpha, power = profile
    values = []
    for j in range(count):
        midpoint = (j + .5) * float(H / RADIUS)
        value = (1 + alpha * K * midpoint) ** (-power)
        values.append(fq(format(value, ".17g")))
    return values


def numerator_polynomial(values, start, end):
    coefficients = [fmpq(0)] * (end + 1)
    coefficients[start] = values[start]
    for j in range(start + 1, end):
        coefficients[j] = values[j] - values[j - 1]
    coefficients[end] = -values[end - 1]
    return fmpq_poly(coefficients)


def truncated_power(poly, exponent, length):
    answer = fmpq_poly([1])
    base = poly.truncate(length)
    while exponent:
        if exponent & 1:
            answer = (answer * base).truncate(length)
        exponent //= 2
        if exponent:
            base = (base * base).truncate(length)
    return answer


def cdf_one_group(poly, count, total_index):
    denominator = fq(factorial(count))
    answer = fmpq(0)
    for shift, coefficient in enumerate(poly.coeffs()[:total_index]):
        if coefficient:
            answer += coefficient * (total_index - shift) ** count / denominator
    return answer


def full_simplex_tail(a_poly, b_poly, first_i, total_index):
    a_coefficients = [fmpq(0)] * first_i + a_poly.coeffs()[first_i:]
    product = (fmpq_poly(a_coefficients) * b_poly).truncate(total_index)
    denominator = fq(factorial(K))
    return sum(
        (coefficient * (total_index - shift) ** K / denominator
         for shift, coefficient in enumerate(product.coeffs()) if coefficient),
        fmpq(0),
    )


def prefix_moments(poly, cap_index):
    coefficients = poly.coeffs()
    moments = [fmpq(0)] * (K + 1)
    for shift in range(min(cap_index, len(coefficients))):
        coefficient = coefficients[shift]
        if not coefficient:
            continue
        power = 1
        for degree in range(K + 1):
            moments[degree] += coefficient * power
            power *= shift
    return moments


def incomplete_kernel(n_small, n_big, total_index, cap_index, small_shift):
    x = fmpq_poly([0, 1])
    left = fq(total_index - small_shift) - x
    cap = fq(cap_index) - x
    left_powers = [fmpq_poly([1])]
    cap_powers = [fmpq_poly([1])]
    for _ in range(n_small):
        left_powers.append(left_powers[-1] * left)
    for _ in range(K):
        cap_powers.append(cap_powers[-1] * cap)
    answer = fmpq_poly()
    big_factorial = factorial(n_big - 1)
    for a in range(n_small + 1):
        denominator = (
            factorial(n_small - a) * factorial(a) * big_factorial * (n_big + a)
        )
        term = left_powers[n_small - a] * cap_powers[n_big + a]
        answer += term * fq(Fraction((-1) ** a, denominator))
    return answer


def two_group_cdf(a_poly, b_poly, n_small, n_big, total_index, cap_index):
    if n_big == 0:
        return cdf_one_group(a_poly, n_small, total_index)
    first_inactive = max(0, total_index - cap_index)
    answer = full_simplex_tail(a_poly, b_poly, first_inactive, total_index)
    moments = prefix_moments(b_poly, cap_index)
    a_coefficients = a_poly.coeffs()
    for small_shift in range(min(first_inactive, len(a_coefficients))):
        coefficient = a_coefficients[small_shift]
        if not coefficient:
            continue
        kernel = incomplete_kernel(
            n_small, n_big, total_index, cap_index, small_shift
        )
        contraction = sum(
            (value * moments[degree]
             for degree, value in enumerate(kernel.coeffs()) if value),
            fmpq(0),
        )
        answer += coefficient * contraction
    return answer


def cap(values, count):
    return values[min(count, len(values) - 1)]


def exact_entry(left_index, right_index):
    left = rational_heights(PROFILES[left_index])
    right = rational_heights(PROFILES[right_index])
    values = [a * b for a, b in zip(left, right)]
    radius_index = int(RADIUS / H)
    delta_index = int(DELTA / H)
    split_index = int(SPLIT / H)
    small_base = numerator_polynomial(values, 0, delta_index)
    big_base = numerator_polynomial(values, delta_index, radius_index)
    result = fmpq(0)
    for count in range(int(max(LOWER[-1], UPPER[-1]) / float(DELTA)) + 1):
        maximum_cap = max(
            Fraction(str(cap(LOWER, count))),
            Fraction(str(cap(UPPER, count))),
        )
        if count and count * DELTA >= maximum_cap:
            continue
        n_small = K - count
        small_power = truncated_power(small_base, n_small, radius_index + 1)
        big_power = (
            fmpq_poly([1]) if count == 0
            else truncated_power(big_base, count, radius_index + 1)
        )
        lower_cap = int(Fraction(str(cap(LOWER, count))) / H)
        upper_cap = int(Fraction(str(cap(UPPER, count))) / H)
        lower_value = two_group_cdf(
            small_power, big_power, n_small, count, split_index, lower_cap
        )
        outer_value = two_group_cdf(
            small_power, big_power, n_small, count, radius_index, upper_cap
        )
        overlap_value = two_group_cdf(
            small_power, big_power, n_small, count, split_index, upper_cap
        )
        result += comb(K, count) * (lower_value + outer_value - overlap_value)
        print(f"pair={left_index},{right_index} count={count}", flush=True)
    result *= fq(H) ** K
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pair", default="2,2")
    parser.add_argument("--all", action="store_true")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    pairs = (
        [(row, col) for row in range(3) for col in range(row + 1)]
        if args.all else [tuple(map(int, args.pair.split(",")))]
    )
    records = []
    for left, right in pairs:
        value = exact_entry(left, right)
        scaled = float(value) / float(RADIUS) ** K
        print(f"RESULT pair={left},{right} u_scaled={scaled:.16e}", flush=True)
        records.append({
            "pair": [left, right],
            "numerator": str(value.numerator),
            "denominator": str(value.denominator),
            "u_scaled_float": scaled,
        })
    if args.output:
        payload = {
            "schema": "small-gaps-exact-step-I-v1",
            "k": K,
            "physical_step": [H.numerator, H.denominator],
            "profile_height_rounding": ".17g interpreted as an exact decimal rational",
            "records": records,
        }
        args.output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
