#!/usr/bin/env python3
"""Exact-integral generalized eigenvalue probe for Maynard simplex weights.

The basis is (1-P_1)^b P_2^c with b+2c <= degree, as in Lemma 8.2 of
Maynard's 2015 Annals paper.  The largest generalized eigenvalue is a rigorous
lower bound for M_k up to ordinary floating-point eigenvalue error.
"""

from __future__ import annotations

import argparse
import functools
import math

import numpy as np
from scipy.linalg import eigh


@functools.cache
def g_poly(power: int, j: int, k: int) -> int:
    if power == 0:
        return 1
    # coeff[r][n] = [z^n] (sum_{m>=1} (jm)!/m! z^m)^r.
    atom = [0] + [math.factorial(j * m) // math.factorial(m) for m in range(1, power + 1)]
    coeff = [[0] * (power + 1) for _ in range(power + 1)]
    coeff[0][0] = 1
    for r in range(1, power + 1):
        for n in range(1, power + 1):
            coeff[r][n] = sum(coeff[r - 1][n - m] * atom[m] for m in range(1, n + 1))
    total = sum(math.comb(k, r) * coeff[r][power] for r in range(1, min(power, k) + 1))
    return math.factorial(power) * total


def positive_ratio(numer: int, denom_factorial: int) -> float:
    if numer == 0:
        return 0.0
    return math.exp(math.log(numer) - math.lgamma(denom_factorial + 1))


def i_entry(k: int, left: tuple[int, int], right: tuple[int, int]) -> float:
    b1, c1 = left
    b2, c2 = right
    numerator = math.factorial(b1 + b2) * g_poly(c1 + c2, 2, k)
    denominator = k + b1 + b2 + 2 * c1 + 2 * c2
    return positive_ratio(numerator, denominator)


def j_entry(k: int, left: tuple[int, int], right: tuple[int, int]) -> float:
    b1, c1 = left
    b2, c2 = right
    denominator = k + b1 + b2 + 2 * c1 + 2 * c2 + 1
    terms = 0
    for c01 in range(c1 + 1):
        for c02 in range(c2 + 1):
            gamma_num = (
                math.factorial(b1)
                * math.factorial(b2)
                * math.factorial(2 * c1 - 2 * c01)
                * math.factorial(2 * c2 - 2 * c02)
                * math.factorial(b1 + b2 + 2 * c1 + 2 * c2 - 2 * c01 - 2 * c02 + 2)
            )
            gamma_den = (
                math.factorial(b1 + 2 * c1 - 2 * c01 + 1)
                * math.factorial(b2 + 2 * c2 - 2 * c02 + 1)
            )
            # This quotient is rational; combine before converting to float.
            numerator = (
                math.comb(c1, c01)
                * math.comb(c2, c02)
                * gamma_num
                * g_poly(c01 + c02, 2, k - 1)
            )
            terms += positive_ratio(numerator, denominator) / gamma_den
    return terms


def solve(k: int, degree: int) -> tuple[float, float, int]:
    basis = [(b, c) for c in range(degree // 2 + 1) for b in range(degree - 2 * c + 1)]
    n = len(basis)
    imat = np.empty((n, n))
    jmat = np.empty((n, n))
    for row, left in enumerate(basis):
        for col in range(row + 1):
            right = basis[col]
            imat[row, col] = imat[col, row] = i_entry(k, left, right)
            jmat[row, col] = jmat[col, row] = j_entry(k, left, right)

    scale = 1.0 / np.sqrt(np.diag(imat))
    scaled_i = (scale[:, None] * imat) * scale[None, :]
    scaled_j = (scale[:, None] * jmat) * scale[None, :]
    evals_i, evecs_i = eigh(scaled_i)
    cutoff = max(evals_i[-1] * 1e-12, 1e-14)
    keep = evals_i > cutoff
    whitening = evecs_i[:, keep] / np.sqrt(evals_i[keep])[None, :]
    reduced_j = whitening.T @ scaled_j @ whitening
    eigenvalue = float(eigh(reduced_j, eigvals_only=True)[-1])
    return k * eigenvalue, float(evals_i[0]), int(keep.sum())


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--k", type=int, default=48)
    parser.add_argument("--degree-min", type=int, default=2)
    parser.add_argument("--degree-max", type=int, default=14)
    args = parser.parse_args()
    for degree in range(args.degree_min, args.degree_max + 1):
        value, smallest, rank = solve(args.k, degree)
        print(
            f"degree={degree:2d} basis_rank={rank:3d} "
            f"M_lower={value:.12f} lambda_min(Icorr)={smallest:.3e}",
            flush=True,
        )


if __name__ == "__main__":
    main()
